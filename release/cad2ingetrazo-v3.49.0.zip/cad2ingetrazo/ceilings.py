# SPDX-License-Identifier: GPL-3.0-or-later
"""False ceilings: a ceiling in every room of a level (or the rooms
picked), hung at a height over the floor (8'-0" by default), of a type —
gypsum board, acoustic tiles on a grid, POP, timber, PVC, metal strips.

``doc["ceilings"]`` = {level id: {"type", "h", "rooms": {room key:
{"type", "h"} | {"off": True}}}} — a level's ceiling and the rooms that
differ (another type or height, or none).
"""
from __future__ import annotations

import math
import re

#: key → (label, thickness m, colour rgba, grid m (0 = plain), grid colour)
TYPES = [
    ("gypsum", "Gypsum false ceiling (plain board)", 0.0125,
     (0.96, 0.96, 0.95, 1.0), 0.0, None),
    ("pop", "POP false ceiling (tray, cornice, cove light)", 0.020,
     (0.98, 0.97, 0.94, 1.0), 0.0, None),
    ("wood", "Wooden false ceiling (planks)", 0.018, (0.62, 0.45, 0.30, 1.0),
     0.1524, (0.48, 0.34, 0.22, 1.0)),
    ("pvc", "PVC false ceiling (panels)", 0.010, (0.95, 0.95, 0.97, 1.0),
     0.2032, (0.82, 0.83, 0.85, 1.0)),
    ("metal", "Metal false ceiling (600×600 tiles)", 0.012,
     (0.84, 0.85, 0.86, 1.0), 0.6, (0.62, 0.63, 0.65, 1.0)),
    ("glass", "Glass false ceiling (back-lit panels)", 0.010,
     (0.93, 0.96, 1.0, 1.0), 0.6, (0.40, 0.42, 0.45, 1.0)),
    ("fabric", "Fabric / cloth false ceiling (draped)", 0.004,
     (0.86, 0.70, 0.48, 1.0), 0.3, (0.78, 0.62, 0.40, 1.0)),
    ("mineral", "Mineral fibre false ceiling (600×600, light panels)", 0.016,
     (0.97, 0.97, 0.96, 1.0), 0.6, (0.80, 0.80, 0.80, 1.0)),
    ("combo", "Combination ceiling (gypsum border, wooden centre)", 0.0125,
     (0.97, 0.97, 0.96, 1.0), 0.1524, (0.62, 0.45, 0.30, 1.0)),
    ("tiles", "Acoustic tiles 2'×2' on a T-grid", 0.016,
     (0.93, 0.93, 0.91, 1.0), 0.6096, (0.70, 0.71, 0.72, 1.0)),
    ("grid24", "Lay-in tiles 2'×4' on a T-grid", 0.016,
     (0.95, 0.95, 0.94, 1.0), 0.6096, (0.72, 0.73, 0.74, 1.0)),
    ("cove", "Gypsum with cove / bulkhead (hidden light)", 0.0125,
     (0.97, 0.97, 0.96, 1.0), 0.0, None),
    ("coffered", "Coffered gypsum", 0.0125, (0.97, 0.96, 0.94, 1.0), 1.2,
     (0.93, 0.92, 0.90, 1.0)),
    ("baffle", "Aluminium baffles", 0.0, (0.82, 0.83, 0.85, 1.0), 0.15,
     (0.78, 0.79, 0.81, 1.0)),
    ("slats", "Timber slats (open)", 0.0, (0.66, 0.48, 0.31, 1.0), 0.1,
     (0.60, 0.43, 0.27, 1.0)),
    ("opencell", "Open-cell metal grid", 0.0, (0.75, 0.76, 0.78, 1.0), 0.1,
     (0.70, 0.71, 0.73, 1.0)),
    ("stretch", "Stretch ceiling (glossy)", 0.005, (0.99, 0.99, 1.0, 1.0),
     0.0, None),
    ("acp", "Aluminium composite panels", 0.006, (0.86, 0.87, 0.88, 1.0),
     1.2192, (0.60, 0.61, 0.63, 1.0)),
    ("metal_linear", "Metal linear strips", 0.015, (0.80, 0.81, 0.83, 1.0),
     0.1016, (0.55, 0.56, 0.58, 1.0)),
    ("cove_track", "Luxury cove ceiling: LED cove, magnetic track lights, "
     "downlights", 0.0125, (0.96, 0.95, 0.93, 1.0), 0.0, None),
    ("cove_slot", "Luxury cove ceiling: LED cove, linear slot lights, "
     "downlights", 0.0125, (0.96, 0.95, 0.93, 1.0), 0.0, None),
]
TRACK = (0.08, 0.08, 0.09, 1.0)       # black magnetic track, spot heads
WARM = (1.0, 0.84, 0.55, 1.0)         # warm-white LED cove
LIGHT = (1.0, 0.93, 0.72, 1.0)        # the cove's glow, a lit panel
WOOD = (0.62, 0.45, 0.30, 1.0)
#: types with no board: strips hung in rows (depth m, width m)
OPEN_KINDS = {"baffle": (0.10, 0.02), "slats": (0.05, 0.04),
              "opencell": (0.05, 0.012)}
BY = {t[0]: t for t in TYPES}
DEFAULT_H = 2.4384          # 8'-0" over the floor


def label(kind: str) -> str:
    return BY.get(kind, BY["gypsum"])[1]


def set_level(doc, lid, kind="gypsum", h=DEFAULT_H) -> None:
    doc.setdefault("ceilings", {})[lid] = {
        "type": kind if kind in BY else "gypsum",
        "h": round(min(max(float(h), 2.0), 8.0), 4),
        "rooms": (doc.get("ceilings", {}).get(lid) or {}).get("rooms", {})}


def remove_level(doc, lid) -> None:
    (doc.get("ceilings") or {}).pop(lid, None)


def at_room(doc, lid, poly) -> dict:
    """The false ceiling set for one room by name (8A ▸ Room ▸ Ceiling
    here / Face colour): {"type", "h", "off", "color", "led"} of the
    entries of ``doc["ceil_at"]`` whose point lies in ``poly``."""
    out = {}
    try:
        from shapely.geometry import Point
        pb = poly.buffer(0.01)
        for e in doc.get("ceil_at") or []:
            if e[0] == lid and pb.contains(Point(e[1], e[2])):
                out.update(e[3] or {})
    except Exception:  # noqa: BLE001
        pass
    return out


def with_face(rec, ov) -> dict:
    """The room record with the face colour / LED picked by room."""
    r = dict(rec or {})
    if ov.get("color"):
        r["ceil_color"] = ov["color"]
    if ov.get("led"):
        r["ceil_led"] = ov["led"]
    return r


def room_ceiling(doc, lid, rkey) -> dict | None:
    """{"type", "h"} of a room's ceiling, or None (no ceiling there)."""
    c = (doc.get("ceilings") or {}).get(lid)
    r = ((c or {}).get("rooms") or {}).get(rkey)
    if r is not None:
        if r.get("off"):
            return None
        return {"type": r.get("type") or (c or {}).get("type", "gypsum"),
                "h": float(r.get("h") or (c or {}).get("h", DEFAULT_H))}
    if c is None:
        return None
    return {"type": c.get("type", "gypsum"), "h": float(c.get("h",
                                                              DEFAULT_H))}


def faces(poly, z, kind) -> list:
    """[(faces, colour)] of a ceiling of ``kind`` over ``poly`` (shapely),
    its underside at ``z``: the board, and the grid / joints seen under
    it as thin strips."""
    from .engine import walls as W
    _k, _lab, t, col, grid, gcol = BY.get(kind, BY["gypsum"])
    out = []
    g = poly.buffer(-0.005, join_style=2)
    if kind in OPEN_KINDS:
        dep, wid = OPEN_KINDS[kind]
        for p in getattr(g, "geoms", [g]):
            if p.is_empty or p.area < 0.2:
                continue
            out.append((_strips(p, z, grid, wid, dep,
                                both=(kind == "opencell")), col))
        return out
    for p in getattr(g, "geoms", [g]):
        if p.is_empty or p.area < 0.2:
            continue
        if kind == "cove":             # a bulkhead band round the room,
            band = p.difference(p.buffer(-0.45, join_style=2))  # lower
            mid = p.buffer(-0.45, join_style=2)
            for q in getattr(band, "geoms", [band]):
                if q.geom_type == "Polygon" and q.area > 0.01:
                    out.append((_slab(q, z - 0.15, z + t), col))
            for q in getattr(mid, "geoms", [mid]):
                if q.geom_type == "Polygon" and q.area > 0.05:
                    out.append((_slab(q, z, z + t), col))
            continue
        if kind in ("cove_track", "cove_slot"):
            out += _luxury(p, z, t, col, tracks=(kind == "cove_track"))
            continue
        if kind in ("pop", "combo", "glass"):
            # a tray: a band round the room, the middle raised (POP: its
            # cornice and the cove light; glass: lit panels in a frame;
            # combination: wooden planks in the middle)
            bw = 0.6 if kind != "glass" else 0.5
            mid = p.buffer(-bw, join_style=2)
            band = p.difference(mid) if not mid.is_empty else p
            for q in getattr(band, "geoms", [band]):
                if q.geom_type == "Polygon" and q.area > 0.01:
                    out.append((_slab(q, z, z + t), BY["gypsum"][3]))
            up = 0.10 if kind != "glass" else 0.06
            for q in getattr(mid, "geoms", [mid]):
                if q.geom_type != "Polygon" or q.area < 0.05:
                    continue
                cc = WOOD if kind == "combo" else col
                out.append((_slab(q, z + up, z + up + t), cc))
                ring = q.buffer(0.02, join_style=2).difference(q)  # fascia
                out.append((_slab(ring, z, z + up), BY["gypsum"][3]))
                if kind == "pop":
                    glow = q.difference(q.buffer(-0.05, join_style=2))
                    out.append((_slab(glow, z + up - 0.012, z + up - 0.002),
                                LIGHT))
                    corn = p.difference(p.buffer(-0.06, join_style=2))
                    out.append((_slab(corn, z - 0.05, z), col))   # cornice
                if kind == "combo":
                    out.append((_grid(q, z + up, grid), gcol))
                if kind == "glass":
                    out.append((_grid(q, z + up, grid), gcol))
            continue
        if kind == "fabric":
            # cloth drawn into folds: strips hanging low and high by turns
            # in the middle, a plain band round it
            mid = p.buffer(-0.45, join_style=2)
            band = p.difference(mid) if not mid.is_empty else p
            for q in getattr(band, "geoms", [band]):
                if q.geom_type == "Polygon" and q.area > 0.01:
                    out.append((_slab(q, z, z + 0.0125), BY["gypsum"][3]))
            from shapely.geometry import box as _bx
            for q in getattr(mid, "geoms", [mid]):
                if q.geom_type != "Polygon" or q.area < 0.05:
                    continue
                x0, y0, x1, y1 = q.bounds
                x, k = x0, 0
                while x < x1:
                    st = q.intersection(_bx(x, y0, x + 0.15, y1))
                    sag = 0.07 if k % 2 == 0 else 0.03
                    for s_ in getattr(st, "geoms", [st]):
                        if s_.geom_type == "Polygon" and s_.area > 1e-4:
                            out.append((_slab(s_, z + 0.08 - sag,
                                              z + 0.08 - sag + t),
                                        col if k % 2 == 0 else gcol))
                    x += 0.15
                    k += 1
                out.append((_slab(q, z + 0.09, z + 0.10), gcol))  # behind
            continue
        if kind == "mineral":          # tiles on a grid, some lit panels
            out.append((_slab(p, z, z + t), col))
            out.append((_grid(p, z, grid), gcol))
            from shapely.geometry import box as _bx
            x0, y0, x1, y1 = p.bounds
            yy = y0 + 1.2
            while yy < y1 - 0.6:
                xx = x0 + 1.2
                while xx < x1 - 0.6:
                    lp = _bx(xx + 0.02, yy + 0.02, xx + 0.58, yy + 0.58)
                    if p.buffer(-0.05).contains(lp):
                        out.append((_slab(lp, z - 0.006, z - 0.001), LIGHT))
                    xx += 1.8
                yy += 1.8
            continue
        if kind == "coffered":         # a board with ribs hung under it
            out.append((_slab(p, z, z + t), col))
            out.append((_strips(p, z, grid, 0.10, 0.12, both=True), gcol))
            continue
        outer = [tuple(c) for c in list(p.exterior.coords)[:-1]]
        holes = [[tuple(c) for c in list(h.coords)[:-1]]
                 for h in p.interiors]
        out.append((W.solid({"outer": _ccw(outer),
                             "holes": [list(reversed(_ccw(h)))
                                       for h in holes]}, z, z + t), col))
        if grid > 0 and gcol is not None:
            out.append((_grid(p, z, grid), gcol))
    return out


def _luxury(p, z, t, col, tracks=True) -> list:
    """The designer bedroom ceiling: a gypsum bulkhead round the room
    (15 cm lower, 60 cm wide) with recessed downlights, a warm LED cove
    washing the raised middle from its inner edge, and in the middle black
    magnetic tracks along the room with spot heads and linear lights
    (``tracks``) or recessed linear slot lights."""
    import math as _m

    from shapely import affinity
    from shapely.geometry import LineString, Point
    out = []
    drop, bw, up = 0.15, 0.60, 0.05
    mid = p.buffer(-bw, join_style=2)
    if mid.is_empty or mid.area < 1.0:          # small room: plain cove
        mid = p.buffer(-0.30, join_style=2)
        bw = 0.30
    band = p.difference(mid) if not mid.is_empty else p
    for q in getattr(band, "geoms", [band]):
        if q.geom_type == "Polygon" and q.area > 0.01:
            out.append((_slabs(q, z - drop, z + t), col))
    if mid.is_empty:
        return out
    for q in getattr(mid, "geoms", [mid]):
        if q.geom_type != "Polygon" or q.area < 0.3:
            continue
        out.append((_slabs(q, z + up, z + up + t), col))
        # the cove: the fascia's inner face lit, a glow on the soffit
        lip = q.buffer(0.012, join_style=2).difference(q)
        out.append((_slabs(lip, z - drop + 0.02, z + up - 0.005), WARM))
        glow = q.difference(q.buffer(-0.10, join_style=2))
        out.append((_slabs(glow, z + up - 0.003, z + up - 0.001), WARM))
        # the room's long direction (its tracks run along it)
        mrr = q.minimum_rotated_rectangle
        cs = list(mrr.exterior.coords)[:4]
        e1 = (cs[1][0] - cs[0][0], cs[1][1] - cs[0][1])
        e2 = (cs[2][0] - cs[1][0], cs[2][1] - cs[1][1])
        ax = e1 if _m.hypot(*e1) >= _m.hypot(*e2) else e2
        ang = _m.degrees(_m.atan2(ax[1], ax[0]))
        c = q.centroid
        qr = affinity.rotate(q, -ang, origin=c)
        x0, y0, x1, y1 = qr.bounds
        inner = qr.buffer(-0.25, join_style=2)
        if inner.is_empty:
            continue
        W_ = y1 - y0
        nlines = 2 if W_ > 2.4 else 1
        for k in range(nlines):
            yy = y0 + W_ * (k + 1) / (nlines + 1)
            ln = LineString([(x0, yy), (x1, yy)]).intersection(inner)
            for seg in getattr(ln, "geoms", [ln]):
                if seg.geom_type != "LineString" or seg.length < 0.6:
                    continue
                (sx0, _y), (sx1, _y2) = list(seg.coords)[0], \
                    list(seg.coords)[-1]
                sx0, sx1 = min(sx0, sx1), max(sx0, sx1)

                def rect(a_, b_, w_):
                    r = LineString([(a_, yy), (b_, yy)]).buffer(
                        w_ / 2, cap_style=2, join_style=2)
                    return affinity.rotate(r, ang, origin=c)
                if tracks:
                    out.append((_slabs(rect(sx0, sx1, 0.035), z + up - 0.035,
                                      z + up), TRACK))
                    xx = sx0 + 0.25
                    k_ = 0
                    while xx < sx1 - 0.2:          # spots and linear lights
                        if k_ % 2 == 0:
                            out.append((_slabs(rect(xx - 0.035, xx + 0.035,
                                                   0.07), z + up - 0.15,
                                              z + up - 0.035), TRACK))
                            out.append((_slabs(rect(xx - 0.025, xx + 0.025,
                                                   0.05), z + up - 0.152,
                                              z + up - 0.15), WARM))
                            xx += 0.35
                        else:
                            e_ = min(xx + 0.6, sx1 - 0.2)
                            out.append((_slabs(rect(xx, e_, 0.02),
                                              z + up - 0.037,
                                              z + up - 0.035), LIGHT))
                            xx = e_ + 0.35
                        k_ += 1
                else:                               # recessed slots
                    out.append((_slabs(rect(sx0, sx1, 0.06), z + up - 0.004,
                                      z + up - 0.001), TRACK))
                    out.append((_slabs(rect(sx0 + 0.01, sx1 - 0.01, 0.03),
                                      z + up - 0.006, z + up - 0.004),
                                LIGHT))
    # recessed downlights along the bulkhead
    rp = p.buffer(-bw / 2, join_style=2)
    for rq in getattr(rp, "geoms", [rp]):
        if rq.is_empty or rq.geom_type != "Polygon":
            continue
        ring = rq.exterior
        if ring.length < 1.0:
            continue
        n_ = max(int(ring.length / 1.2), 1)
        for i in range(n_):
            pt = ring.interpolate(i * ring.length / n_)
            out.append((_slabs(Point(pt.x, pt.y).buffer(0.045, 8),
                               z - drop - 0.003, z - drop - 0.001), WARM))
    return out


def _slabs(g, z0, z1) -> list:
    """_slab of every polygon in ``g`` (a polygon or several)."""
    out = []
    for q in getattr(g, "geoms", [g]):
        if q.geom_type == "Polygon" and not q.is_empty and q.area > 1e-6:
            out += _slab(q, z0, z1)
    return out


def _slab(p, z0, z1) -> list:
    from .engine import walls as W
    outer = [tuple(c) for c in list(p.exterior.coords)[:-1]]
    holes = [[tuple(c) for c in list(h.coords)[:-1]] for h in p.interiors]
    return W.solid({"outer": _ccw(outer),
                    "holes": [list(reversed(_ccw(h))) for h in holes]},
                   z0, z1)


def _strips(p, z, step, wid, dep, both=False) -> list:
    """Strips ``wid`` wide, ``dep`` deep, every ``step``, hung from z down
    (along x; and along y too with ``both``): baffles, slats, ribs."""
    from shapely.geometry import box
    x0, y0, x1, y1 = p.bounds
    fs = []

    def put(b):
        g = p.intersection(b)
        for q in getattr(g, "geoms", [g]):
            if q.geom_type == "Polygon" and q.area > 1e-4:
                fs.extend(_slab(q, z - dep, z))
    x = x0 + step / 2
    while x < x1:
        put(box(x - wid / 2, y0, x + wid / 2, y1))
        x += step
    if both:
        y = y0 + step / 2
        while y < y1:
            put(box(x0, y - wid / 2, x1, y + wid / 2))
            y += step
    return fs


def _grid(p, z, step) -> list:
    """Thin strips under the board along x (and y for tiles): the T-grid,
    the panel joints."""
    from shapely.geometry import box
    x0, y0, x1, y1 = p.bounds
    fs = []
    w = 0.012

    def strip(b):
        g = p.intersection(b)
        for q in getattr(g, "geoms", [g]):
            if q.geom_type != "Polygon" or q.area < 1e-4:
                continue
            pts = [tuple(c) for c in list(q.exterior.coords)[:-1]]
            pts = _ccw(pts)
            fs.append({"loop": [(x, y, z - 0.003) for x, y in
                                reversed(pts)], "holes": []})
    x = x0 + step
    while x < x1:
        strip(box(x - w / 2, y0, x + w / 2, y1))
        x += step
    if step >= 0.5:                       # tiles: both ways
        y = y0 + step
        while y < y1:
            strip(box(x0, y - w / 2, x1, y + w / 2))
            y += step
    return fs


def _ccw(loop):
    a = 0.5 * sum(p[0] * q[1] - q[0] * p[1]
                  for p, q in zip(loop, loop[1:] + loop[:1]))
    return list(loop) if a >= 0 else list(reversed(loop))


NO_CEILING = r"BALCON|TERRACE|TERACE|SIT\s*OUT|OPEN|SKY|DUCT|SHAFT|LIFT|" \
    r"ELEV|P\d+\.?CO|VOID|O\.?T\.?S|STAIR"


def _open_air(room, rails) -> bool:
    """A room out in the open (a balcony, a sit-out) or a shaft: no false
    ceiling — by its name, or railed round more than a quarter of it."""
    import re
    if re.search(NO_CEILING, str(room.get("name", "")), re.I):
        return True
    if rails is None or rails.is_empty:
        return False
    try:
        edge = room["poly"].exterior
        return edge.intersection(rails).length > 0.25 * edge.length
    except Exception:  # noqa: BLE001
        return False


def build(doc, z_of, room_key) -> list:
    """[(level id, room name, kind, h, [(faces, colour)])] for every room
    with a ceiling."""
    from shapely.geometry import LineString
    from shapely.ops import unary_union

    from .engine import spaces
    arch = doc["arch"]
    out = []
    order = sorted(z_of, key=lambda k: z_of[k])

    def wells_over(lid):
        """The openings in the floor over ``lid`` (a stair well, a void):
        no ceiling under them."""
        try:
            from . import project as PJ
            i = order.index(lid)
            if i + 1 >= len(order):
                return None
            up = order[i + 1]
            hs = []
            for s_ in PJ._floor_slabs(doc, up):
                for h in s_.get("holes") or []:
                    try:
                        from shapely.geometry import Polygon as _P
                        hs.append(_P(h).buffer(0))
                    except Exception:  # noqa: BLE001
                        continue
            return unary_union(hs) if hs else None
        except Exception:  # noqa: BLE001
            return None
    own_lids = {r["level"] for r in arch.get("rooms") or []
                if r.get("ceiling") in BY}
    own_lids |= {e[0] for e in doc.get("ceil_at") or []}
    for lid in list((doc.get("ceilings") or {}).keys()) + \
            sorted(own_lids - set((doc.get("ceilings") or {}).keys())):
        if lid not in z_of:
            continue
        wells = wells_over(lid)
        try:
            rails = unary_union([_rail_line(w).buffer(0.25)
                                 for w in arch["walls"] if w["level"] == lid
                                 and w.get("rail") and "a" in w]) or None
        except Exception:  # noqa: BLE001
            rails = None
        done_ = []
        stair_feet = []
        for s_ in doc.get("stairs") or []:     # a stair hall the CAD calls
            if s_.get("level") != lid:           # «VOID» / «STAIR»: ceiled
                continue
            try:
                from shapely.geometry import Polygon as _Pg
                stair_feet.append(_Pg([tuple(p[:2]) for p in
                                       s_["corners"]]).buffer(0))
            except Exception:  # noqa: BLE001
                continue
        try:
            gaps = _gap_lines(doc, lid)
        except Exception:  # noqa: BLE001
            from .host import log_error
            log_error("ceilings._gap_lines")
            gaps = []
        try:
            from . import slabedges as SE_
            from .engine import walls as W_
            wall_u = unary_union(SE_.wall_polys(
                [w for w in arch["walls"] if w["level"] == lid and "a" in w
                 and not w.get("rail") and W_.why_not(w) is None]))
            if rails is not None and not rails.is_empty:
                wall_u = unary_union([wall_u, rails.buffer(-0.19)])
        except Exception:  # noqa: BLE001
            wall_u = None
        for room in _split_rooms(spaces.of_level(arch, lid), gaps,
                                 stair_feet, rails, room_key, lid, wall_u):
            if room["area"] < 1.0:
                continue
            rec_ = room.get("rec") or {}
            ov = at_room(doc, lid, room["poly"])
            if ov.get("off"):
                continue
            hall = bool(re.search(r"VOID|STAIR|LOBBY|HALL",
                                  str(room.get("name", "")), re.I)) and \
                any(room["poly"].intersects(f_) for f_ in stair_feet)
            if rec_.get("ceiling") not in BY and not hall and \
                    ov.get("type") not in BY and _open_air(room, rails):
                if rec_.get("ceiling") != "none" and \
                        doc["settings"].get("balcony_ceiling", True) and \
                        re.search(BALCONY, str(room.get("name", "")), re.I) \
                        or (rec_.get("ceiling") != "none" and
                            doc["settings"].get("balcony_ceiling", True) and
                            not re.search(NO_CEILING,
                                          str(room.get("name", "")), re.I)):
                    try:          # a balcony: its ceiling and edge beam
                        b_ = _balcony(doc, lid, room, order, z_of, rails)
                        if b_:
                            if ov.get("color") or ov.get("led"):
                                b_ = b_[:4] + (paint(b_[4], with_face(
                                    rec_, ov)),)
                            out.append(b_ + (room.get("key") or room_key(lid, room),))
                    except Exception:  # noqa: BLE001
                        from .host import log_error
                        log_error("ceilings._balcony")
                done_.append(room["poly"])   # not again as a leftover
                continue
            c = room_ceiling(doc, lid, room.get("key") or room_key(lid, room))
            rec = room.get("rec") or {}
            own = rec.get("ceiling")
            if own == "none":
                c = None
            elif own in BY:
                lvc = (doc.get("ceilings") or {}).get(lid) or {}
                c = {"type": own,
                     "h": float(rec.get("ceiling_h") or lvc.get("h",
                                                              DEFAULT_H))}
            elif c is not None and rec.get("ceiling_h"):
                c = dict(c, h=float(rec["ceiling_h"]))
            if ov.get("type") in BY:          # set for this room by name
                lvc = (doc.get("ceilings") or {}).get(lid) or {}
                c = {"type": ov["type"],
                     "h": float(ov.get("h") or rec.get("ceiling_h")
                                or lvc.get("h", DEFAULT_H))}
            elif c is not None and ov.get("h"):
                c = dict(c, h=float(ov["h"]))
            rec = with_face(rec, ov)
            if c is None:
                continue
            poly = room["poly"]
            if wells is not None and poly.intersects(wells):
                try:
                    poly = poly.difference(wells.buffer(0.05))
                except Exception:  # noqa: BLE001
                    pass
            if poly.is_empty:
                continue
            fs = paint(faces(poly, z_of[lid] + c["h"], c["type"]), rec)
            if fs:
                out.append((lid, room["name"], c["type"], c["h"], fs,
                            room.get("key") or room_key(lid, room)))
                done_.append(poly)
        try:                 # the beams round the stair well over it
            out += _well_beams(doc, lid, order, z_of, wells)
        except Exception:  # noqa: BLE001
            from .host import log_error
            log_error("ceilings._well_beams")
        try:                 # the rest inside the outside walls (a hall,
            out += _rest(doc, lid, z_of, wells, done_, order, rails)   # a
        except Exception:  # noqa: BLE001                  # lobby…)
            from .host import log_error
            log_error("ceilings._rest")
    return out


#: the false ceiling's face colour (Edit ▸ Ceiling colour) and its LED
COLOURS = [("fc_auto", "As the type", None),
           ("fc_white", "White", (0.97, 0.97, 0.97, 1.0)),
           ("fc_offwhite", "Off-white", (0.95, 0.94, 0.90, 1.0)),
           ("fc_ivory", "Ivory", (0.96, 0.92, 0.82, 1.0)),
           ("fc_beige", "Warm beige", (0.88, 0.82, 0.72, 1.0)),
           ("fc_grey", "Light grey", (0.82, 0.83, 0.84, 1.0)),
           ("fc_charcoal", "Charcoal", (0.25, 0.26, 0.28, 1.0)),
           ("fc_walnut", "Walnut wood", (0.42, 0.25, 0.13, 1.0)),
           ("fc_oak", "Light oak", (0.74, 0.60, 0.42, 1.0))]
LEDS = [("led_auto", "As the type", None), ("led_warm", "Warm white", WARM),
        ("led_cool", "Cool white", (0.88, 0.94, 1.0, 1.0)),
        ("led_gold", "Golden", (1.0, 0.75, 0.35, 1.0)),
        ("led_off", "Off (no glow)", None)]
_LIT = {LIGHT, WARM}


def paint(fs, rec) -> list:
    """The ceiling's faces in the room's own colours: its boards
    (``ceil_color``) and its cove / panel light (``ceil_led``); the
    tracks, spots and edge beams as they are."""
    cc = dict((k, c) for k, _l, c in COLOURS).get((rec or {}).get(
        "ceil_color") or "fc_auto")
    led_k = (rec or {}).get("ceil_led") or "led_auto"
    lc = dict((k, c) for k, _l, c in LEDS).get(led_k)
    if cc is None and led_k == "led_auto":
        return fs
    out = []
    for f_, col in fs:
        col4 = tuple(col) if col is not None else None
        if col4 in _LIT:
            if led_k == "led_off":
                col4 = cc or BY["gypsum"][3]
            elif lc is not None:
                col4 = lc
        elif cc is not None and col4 not in (TRACK, BEAM_COLOR):
            col4 = cc
        out.append((f_, col4))
    return out


#: rooms out in the open that still get a false ceiling (under the floor
#: above): balconies, sit-outs, verandahs
BALCONY = r"BALCON|SIT\s*OUT|VERANDA|PORCH|LOGGIA"
#: the beam round a balcony's open sides: 9" wide, hung from the slab
#: above down to the false ceiling
BEAM_W = 0.2286
BEAM_COLOR = (0.93, 0.92, 0.89, 1.0)


def _run_into_walls(open_, WU, reach=0.30):
    """The open edges a beam runs along, each end that stops short of a
    wall carried on into it (the 0.12 m kept off the walls, and the
    wall's thickness half way): the beam meets the wall, no gap."""
    from shapely.geometry import LineString, MultiLineString
    from shapely.ops import linemerge
    if open_ is None or open_.is_empty or WU is None:
        return open_
    try:
        ln = linemerge(open_) if open_.geom_type != "LineString" else open_
    except Exception:  # noqa: BLE001
        ln = open_
    out = []
    for g in getattr(ln, "geoms", [ln]):
        if g.geom_type != "LineString" or g.length < 0.05:
            continue
        cs = [tuple(c[:2]) for c in g.coords]
        for end in (0, -1):
            p = cs[end]
            q = cs[1] if end == 0 else cs[-2]
            L = math.dist(p, q)
            if L < 1e-6:
                continue
            u = ((p[0] - q[0]) / L, (p[1] - q[1]) / L)
            from shapely.geometry import Point
            if WU.distance(Point(p)) > reach:
                continue                  # a free end: as it is
            step = 0.0                    # on till inside the wall
            while step < reach + 0.25:
                step += 0.03
                tip = (p[0] + u[0] * step, p[1] + u[1] * step)
                if WU.buffer(-0.02).contains(Point(tip)):
                    break
            tip = (p[0] + u[0] * step, p[1] + u[1] * step)
            if end == 0:
                cs.insert(0, tip)
            else:
                cs.append(tip)
        out.append(LineString(cs))
    if not out:
        return open_
    return out[0] if len(out) == 1 else MultiLineString(out)


def _rail_line(w):
    """A railing's line (an arc one as a polyline)."""
    from shapely.geometry import LineString
    if w.get("kind", "line") == "line":
        return LineString([w["a"], w["b"]])
    try:
        from .engine import walls as W
        seg = W.centre(w)
        return LineString([tuple(seg.at(k / 16))[:2] for k in range(17)])
    except Exception:  # noqa: BLE001
        return LineString([w["a"], w["b"]])


def _gap_lines(doc, lid) -> list:
    """Lines across the openings with no door between two spaces of a
    level (a wall end facing another wall across a gap, a corridor's
    mouth between two parallel wall ends): where one room's false
    ceiling ends and the next one's begins."""
    from shapely.geometry import LineString, Point
    from shapely.ops import unary_union

    from . import slabedges as SE
    from .engine import walls as W
    arch = doc["arch"]
    ws = [w for w in arch["walls"] if w["level"] == lid and "a" in w
          and not w.get("rail") and w.get("kind", "line") == "line"
          and W.why_not(w) is None and math.dist(w["a"], w["b"]) > 0.05]
    if len(ws) < 2:
        return []
    polys = {}
    for w in ws:
        try:
            g = unary_union(SE.wall_polys([w]))
            if not g.is_empty:
                polys[id(w)] = g
        except Exception:  # noqa: BLE001
            continue

    def U(w):
        a, b = w["a"], w["b"]
        L = math.dist(a, b)
        return ((b[0] - a[0]) / L, (b[1] - a[1]) / L)

    rail_ws = [w for w in arch["walls"] if w["level"] == lid and "a" in w
               and w.get("rail")]
    for w in rail_ws:                   # a railing closes a space too
        try:
            polys[id(w)] = _rail_line(w).buffer(0.06)
        except Exception:  # noqa: BLE001
            continue
    targets = ws + rail_ws
    ends = []                           # (wall, point, out direction)
    for w in ws:
        u = U(w)
        for k, dv in (("a", (-u[0], -u[1])), ("b", u)):
            P = Point(w[k])
            if any(o is not w and id(o) in polys and
                   polys[id(o)].distance(P) < 0.03 for o in targets):
                continue                  # joined to another wall
            ends.append((w, tuple(w[k]), dv))
    out = []
    for w, P, dv in ends:               # a wall end facing a wall
        ray = LineString([P, (P[0] + dv[0] * 2.8, P[1] + dv[1] * 2.8)])
        best = None
        for o in targets:
            if o is w or id(o) not in polys:
                continue
            x = ray.intersection(polys[id(o)])
            if x.is_empty:
                continue
            dd = Point(P).distance(x)
            if 0.45 <= dd and (best is None or dd < best):
                best = dd
        if best is not None:
            out.append(LineString([P, (P[0] + dv[0] * (best + 0.05),
                                       P[1] + dv[1] * (best + 0.05))]))
    free = {(id(w), tuple(P)) for w, P, _d in ends}
    for w in ws:                        # every wall run on a little past
        u = U(w)                        # a free end: the slits between a
        ea = 0.35 if (id(w), tuple(w["a"])) in free else 0.0   # wall end
        eb = 0.35 if (id(w), tuple(w["b"])) in free else 0.0   # and the
        if ea or eb:                                           # next wall
            out.append(LineString([(w["a"][0] - u[0] * ea,     # closed
                                    w["a"][1] - u[1] * ea),
                                   (w["b"][0] + u[0] * eb,
                                    w["b"][1] + u[1] * eb)]))
    with_ops = {o.get("wall") for o in arch["openings"]
                if o.get("kind") in ("door", "void")}
    for w in ws:                        # a wall with a door in it: the
        if w["id"] not in with_ops:     # rooms found through the door
            continue                    # parted along it
        u = U(w)
        out.append(LineString([(w["a"][0] - u[0] * 0.1,
                                w["a"][1] - u[1] * 0.1),
                               (w["b"][0] + u[0] * 0.1,
                                w["b"][1] + u[1] * 0.1)]))
    for i, (w1, P1, d1) in enumerate(ends):   # a corridor's mouth
        for w2, P2, d2 in ends[i + 1:]:
            if w2 is w1:
                continue
            if d1[0] * d2[0] + d1[1] * d2[1] < 0.985:
                continue                  # not pointing the same way
            g = math.dist(P1, P2)
            if not 0.8 <= g <= 3.2:
                continue
            v = ((P2[0] - P1[0]) / g, (P2[1] - P1[1]) / g)
            if abs(v[0] * d1[0] + v[1] * d1[1]) > 0.2:
                continue                  # the ends not level
            n1 = (-d1[1], d1[0])
            ext = max(float(w1["t"]), float(w2["t"])) / 2 + 0.05
            sg = 1 if v[0] * n1[0] + v[1] * n1[1] > 0 else -1
            out.append(LineString([
                (P1[0] - n1[0] * sg * ext, P1[1] - n1[1] * sg * ext),
                (P2[0] + n1[0] * sg * ext, P2[1] + n1[1] * sg * ext)]))
    return out


def _split_rooms(rooms, gaps, stair_feet, rails, room_key, lid,
                 wall_u=None):
    """The level's rooms, each cut where an opening with no door joins it
    to the next space (``gaps``): a ceiling a space — the corridor, the
    stair hall, the lobby, a balcony the walls leave open to a hall."""
    from shapely.geometry import Point
    from shapely.ops import unary_union
    for room in rooms:
        poly = room.get("poly")
        if poly is None or poly.is_empty or not gaps or room["area"] < 6.0:
            yield room
            continue
        cuts = []
        for g in gaps:
            try:
                if g.intersects(poly) and \
                        g.intersection(poly).length >= 0.08:
                    cuts.append(g)
            except Exception:  # noqa: BLE001
                continue
        if not cuts and wall_u is None:
            yield room
            continue
        try:
            cutter = [c.buffer(0.012, cap_style=2) for c in cuts]
            if wall_u is not None and not wall_u.is_empty:
                # the slits under 0.36 m between two walls (or a wall and a
                # railing) closed: where the walls nearly meet, a room ends
                cutter.append(wall_u.buffer(0.18, join_style=2))
            rest = poly.difference(unary_union(cutter))
        except Exception:  # noqa: BLE001
            yield room
            continue
        try:                 # necks under 0.5 m (a wall end short of a
            core = rest.buffer(-0.45, join_style=2).buffer(  # railing)
                0.45, join_style=2).intersection(rest)        # parted too
            left = rest.difference(core.buffer(0.001))
            parts = [g for g in getattr(core, "geoms", [core])
                     if g.geom_type == "Polygon" and g.area > 0.05] + \
                [g for g in getattr(left, "geoms", [left])
                 if g.geom_type == "Polygon" and g.area > 0.05]
        except Exception:  # noqa: BLE001
            parts = [g for g in getattr(rest, "geoms", [rest])
                     if g.geom_type == "Polygon" and g.area > 0.05]
        big = [g for g in parts if g.area >= 2.0 and
               not g.buffer(-0.25).is_empty]
        if len(big) < 2:
            yield room
            continue
        small = [g for g in parts if not any(g is b for b in big)]
        for g in small:                  # slivers to the piece they touch
            j = max(range(len(big)), key=lambda k: big[k].buffer(0.25)
                    .intersection(g).area)
            if big[j].buffer(0.25).intersection(g).area < 1e-4:
                if g.area >= 1.0:
                    big.append(g)        # a space of its own
                continue
            big[j] = unary_union([big[j], g.buffer(0.013)]).buffer(-0.001)
        if wall_u is not None:          # back out to the room's edges
            grown, taken = [], None
            for g in sorted(big, key=lambda q: -q.area):
                g2 = g.buffer(0.2, join_style=2).intersection(poly)
                if taken is not None:
                    g2 = g2.difference(taken)
                g2 = g2.difference(unary_union(
                    [c.buffer(0.012, cap_style=2) for c in cuts])) \
                    if cuts else g2
                pick = [q for q in getattr(g2, "geoms", [g2])
                        if q.geom_type == "Polygon" and q.intersects(g)]
                g2 = unary_union(pick) if pick else g
                grown.append(g2)
                taken = g2 if taken is None else unary_union([taken, g2])
            big = grown
        at = room.get("at")
        lab = Point(at) if at else poly.representative_point()
        key0 = room_key(lid, room)
        big.sort(key=lambda g: (0 if g.buffer(0.02).contains(lab) else 1,
                                -g.area))
        for k, g in enumerate(big):
            if g.geom_type != "Polygon":
                g = max(getattr(g, "geoms", [g]), key=lambda q: q.area)
            name = room["name"]
            if k:
                railed = rails is not None and not rails.is_empty and \
                    g.exterior.intersection(rails).length > \
                    0.2 * g.exterior.length
                if any(g.intersects(f_) for f_ in stair_feet):
                    name = "Stair hall"
                elif railed:
                    name = "BALCONY"
                elif re.search(r"VOID|STAIR|HALL|LOBBY|PASSAGE|CORRIDOR|"
                               r"LOUNGE|FOYER|ENTRANCE", str(room["name"]),
                               re.I):
                    mr = g.minimum_rotated_rectangle
                    cs = list(mr.exterior.coords)
                    s1, s2 = sorted((math.dist(cs[0], cs[1]),
                                     math.dist(cs[1], cs[2])))
                    name = "Corridor" if s1 < 2.2 or s2 > 2.6 * s1 \
                        else "Room"
                else:
                    name = f"{room['name']} {k + 1}"
            r2 = dict(room, poly=g, area=g.area, name=name,
                      key=key0 if not k else f"{key0}#{k}")
            if k:
                r2["rec"] = {}
            yield r2


def _balcony(doc, lid, room, order, z_of, rails):
    """(level, name, kind, h, [(faces, colour)]) of a balcony's false
    ceiling with the periphery beam along its open sides (its railings,
    the edges no wall closes), the beam from the soffit of the slab above
    down to the ceiling — or None when no floor / roof is over it."""
    from shapely.geometry import Polygon
    from shapely.ops import unary_union

    from . import project as PJ
    from . import slabedges as SE
    from .engine import walls as W
    arch = doc["arch"]
    i = order.index(lid) if lid in order else -1
    if i < 0:
        return None
    up = order[i + 1] if i + 1 < len(order) else None
    poly = room["poly"]
    over = []
    roof_slabs = [s_ for s_ in arch["structure"] if s_["type"] == "slab"
                  and s_["level"] == lid and s_.get("roof")]
    for s_ in (PJ._floor_slabs(doc, up) if up else []) + roof_slabs:
        try:
            over.append(Polygon(s_["corners"]).buffer(0))
        except Exception:  # noqa: BLE001
            continue
    if not over and up is None:
        # the top floor with no roof slab drawn yet: under the floor's
        # own outline, as the roof will be cast over it
        for s_ in PJ._floor_slabs(doc, lid):
            try:
                over.append(Polygon(s_["corners"]).buffer(0))
            except Exception:  # noqa: BLE001
                continue
    if not over:
        return None
    cover = poly.intersection(unary_union(over))
    if cover.area < 0.5 * poly.area:
        return None                       # open to the sky
    lvc = (doc.get("ceilings") or {}).get(lid) or {}
    rec = room.get("rec") or {}
    kind = rec.get("ceiling") if rec.get("ceiling") in BY else \
        doc["settings"].get("balcony_ceiling_type") or \
        lvc.get("type", "gypsum")
    if kind not in BY:
        kind = "gypsum"
    h = float(rec.get("ceiling_h") or lvc.get("h", DEFAULT_H))
    z0 = z_of[lid]
    zc = z0 + h
    t_up = 0.15
    try:
        t_up = max(float(s_.get("t", 0.15)) for s_ in (
            PJ._floor_slabs(doc, up) if up else roof_slabs) or
            PJ._floor_slabs(doc, lid))
    except Exception:  # noqa: BLE001
        pass
    if up is not None:
        zs = z_of[up] - t_up              # the soffit of the slab above
    else:
        lv_ = next((v for v in arch["levels"] if v["id"] == lid), {})
        zs = z_of[lid] + float(lv_.get("height") or 3.0) - t_up
    if zs <= zc + 0.02:
        zs = zc + 0.02
    ws = [w for w in arch["walls"] if w["level"] == lid
          and not w.get("rail") and W.why_not(w) is None]
    WU = unary_union(SE.wall_polys(ws)) if ws else None
    cover = cover.buffer(-0.005)
    edge = cover.exterior if cover.geom_type == "Polygon" else \
        unary_union([g.exterior for g in cover.geoms])
    open_ = edge.difference(WU.buffer(0.12)) if WU is not None else edge
    band = None
    if not open_.is_empty:
        run = _run_into_walls(open_, WU)
        clip = cover if WU is None else cover.union(
            WU.intersection(cover.buffer(0.45, join_style=2))) \
            .buffer(0.008, join_style=2).buffer(-0.008, join_style=2)
        band = run.buffer(BEAM_W, cap_style=2, join_style=2) \
            .intersection(clip)
        # the ceiling stays inside the room; the beam's end in the wall
        # is hidden in it
    fs = []
    ceil = cover.difference(band) if band is not None and \
        not band.is_empty else cover
    for g in getattr(ceil, "geoms", [ceil]):
        if g.geom_type == "Polygon" and g.area > 0.1:
            fs += faces(g, zc, kind)
    if band is not None:
        bf = []
        for g in getattr(band, "geoms", [band]):
            if g.geom_type == "Polygon" and g.area > 0.01:
                bf += _slab(g, zc - 0.0125, zs)
        if bf:
            fs.append((bf, BEAM_COLOR))
    if not fs:
        return None
    return (lid, room["name"], kind, h, paint(fs, rec))


def _well_beams(doc, lid, order, z_of, wells) -> list:
    """The edge beams round the stair well in the floor above (as round a
    balcony): 9" wide, hung from the slab's soffit down to the false
    ceiling, along the well's sides no wall closes."""
    if wells is None or wells.is_empty:
        return []
    from shapely.ops import unary_union

    from . import project as PJ
    from . import slabedges as SE
    from .engine import walls as W
    arch = doc["arch"]
    i = order.index(lid) if lid in order else -1
    if i < 0 or i + 1 >= len(order):
        return []
    up = order[i + 1]
    lvc = (doc.get("ceilings") or {}).get(lid) or {}
    h = float(lvc.get("h", DEFAULT_H))
    zc = z_of[lid] + h
    t_up = 0.15
    try:
        t_up = max(float(s_.get("t", 0.15)) for s_ in
                   PJ._floor_slabs(doc, up))
    except Exception:  # noqa: BLE001
        pass
    zs = z_of[up] - t_up
    if zs <= zc + 0.05:
        zc = zs - 0.30                    # no room for a ceiling: a 1' beam
    ws = [w for w in arch["walls"] if w["level"] in (lid, up)
          and not w.get("rail") and W.why_not(w) is None]
    WU = unary_union(SE.wall_polys(ws)) if ws else None
    out = []
    k = 0
    for g in getattr(wells, "geoms", [wells]):
        if g.geom_type != "Polygon" or g.area < 4.0:
            continue                      # a duct / a shaft: no beam
        edge = g.exterior
        open_ = edge.difference(WU.buffer(0.12)) if WU is not None else edge
        if open_.is_empty or open_.length < 0.5:
            continue
        run = _run_into_walls(open_, WU)
        band = run.buffer(BEAM_W, cap_style=2, join_style=2).difference(g)
        if WU is not None:     # not out past the walls round the well
            band = band.intersection(g.buffer(BEAM_W + 0.01,
                                              join_style=2).union(WU))
        fs = []
        for q in getattr(band, "geoms", [band]):
            if q.geom_type == "Polygon" and q.area > 0.01:
                fs += _slab(q, zc - 0.0125, zs)
        if fs:
            k += 1
            out.append((lid, f"Stair well beam {k}", "beam", h,
                        [(fs, BEAM_COLOR)], f"{lid}|wellbeam{k}"))
    return out


def _rest(doc, lid, z_of, wells, done, order=None, rails=None) -> list:
    """The level's ceiling over what its rooms leave inside the outside
    walls (halls and corridors open to one another, a lobby): not over
    the walls, the shafts and wells, nor out on the balconies."""
    lvc = (doc.get("ceilings") or {}).get(lid)
    if not lvc and not any(e[0] == lid for e in doc.get("ceil_at") or []):
        return []
    lvc = lvc or {}
    from shapely.geometry import Polygon
    from shapely.ops import unary_union

    from . import slabedges as SE
    from .engine import walls as W
    arch = doc["arch"]
    ws = [w for w in arch["walls"] if w["level"] == lid
          and not w.get("rail") and W.why_not(w) is None]
    if not ws:
        return []
    WU = unary_union(SE.wall_polys(ws))
    # (a corridor open at its end to a balcony, up to 4 m: inside; the
    # railings close the balconies the CAD left unnamed)
    WR = WU if rails is None or rails.is_empty else unary_union(
        [WU, rails.buffer(-0.2)])
    close = WR.buffer(2.0, join_style=2).buffer(-2.0, join_style=2)
    inside = unary_union([Polygon(g.exterior) for g in getattr(
        close, "geoms", [close]) if g.geom_type == "Polygon"
        and Polygon(g.exterior).area >= 20.0])
    if inside.is_empty:
        return []
    try:                     # never past the floor's own slab
        fl = unary_union([Polygon(s_["corners"]).buffer(0)
                          for s_ in arch["structure"] if s_["type"] == "slab"
                          and s_["level"] == lid and not s_.get("roof")
                          and not s_.get("zone")])
        if not fl.is_empty:
            inside = inside.intersection(fl)
    except Exception:  # noqa: BLE001
        pass
    cut = [WU.buffer(0.005)]
    if done:
        cut.append(unary_union(done).buffer(0.02))
    if wells is not None:
        cut.append(wells.buffer(0.05))
    for s_ in arch["structure"]:          # the shafts through this floor
        if s_["type"] == "slab" and s_["level"] == lid:
            for h in s_.get("shafts") or []:
                try:
                    cut.append(Polygon(h).buffer(0.02))
                except Exception:  # noqa: BLE001
                    continue
        if s_.get("type") == "column" and s_.get("level") == lid:
            try:
                from .engine import structure as S_
                cut.append(Polygon(S_.column_outline(s_, 0.0)).buffer(0.01))
            except Exception:  # noqa: BLE001
                continue
    for m in doc.get("man_shafts") or []:
        if m.get("level") == lid and (m.get("auto") in ("lift",) or re.search(
                r"DUCT|SHAFT|LIFT", str(m.get("note", "")), re.I)):
            cut.append(Polygon(m["pts"]).buffer(0.05))
    rest = inside.difference(unary_union(cut))
    # cut by the walkthrough's corridors / stair halls: one ceiling a
    # space, named as the walkthrough names it
    named = []
    try:
        from . import walk as WK
        named = [(n, p) for n, p in WK.rooms(doc, lid)
                 if re.match(r"(Corridor|Stair hall) \d", n)]
    except Exception:  # noqa: BLE001
        named = []
    pieces = []
    for g in getattr(rest, "geoms", [rest]):
        if g.geom_type != "Polygon":
            continue
        left = g
        for n, p in named:
            try:
                q = g.intersection(p.buffer(0.3, join_style=2))
            except Exception:  # noqa: BLE001
                continue
            for qq in getattr(q, "geoms", [q]):
                if qq.geom_type == "Polygon" and qq.area >= 1.0:
                    pieces.append((n, qq))
            left = left.difference(p.buffer(0.3, join_style=2))
        for qq in getattr(left, "geoms", [left]):
            if qq.geom_type == "Polygon":
                pieces.append((None, qq))
    out = []
    k = 0
    for n, g in pieces:
        if g.area < 1.0 or g.buffer(-0.25).is_empty:
            continue
        ov = at_room(doc, lid, g)
        if ov.get("off"):
            continue
        if order and rails is not None and not rails.is_empty and \
                ov.get("type") not in BY and \
                doc["settings"].get("balcony_ceiling", True):
            try:                 # railed round: a balcony the CAD left
                railed = g.exterior.intersection(rails).length > \
                    0.2 * g.exterior.length               # unnamed
            except Exception:  # noqa: BLE001
                railed = False
            if railed:
                k += 1
                b_ = _balcony(doc, lid, {"poly": g, "name": "BALCONY",
                                         "rec": {}, "area": g.area},
                              order, z_of, rails)
                if b_:
                    out.append(b_ + (f"{lid}|open{k}",))
                continue
        typ = ov["type"] if ov.get("type") in BY else lvc.get("type")
        if typ not in BY:
            continue
        h = float(ov.get("h") or lvc.get("h", DEFAULT_H))
        k += 1
        nm = n or f"Open area {k}"
        fs = paint(faces(g, z_of[lid] + h, typ), with_face({}, ov))
        if fs:
            out.append((lid, nm, typ, h, fs, f"{lid}|open{k}"))
    return out
