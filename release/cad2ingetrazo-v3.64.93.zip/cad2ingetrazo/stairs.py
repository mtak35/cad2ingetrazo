# SPDX-License-Identifier: GPL-3.0-or-later
"""Staircases from the plans, floor to floor, with their wells cut in the
slabs — and terraces and balconies on any floor.

Where a stair is: a closed outline (or the lines) on a stair layer of the
CAD plan, else a room named STAIR… on the level, else the stair of the
floor below (a stair core goes up the building). A long, narrow well
gets one straight flight; a squarer one a dog-leg — two flights side by
side and a half landing. Risers about 175 mm, goings up to 300 mm.

``doc["stairs"]`` = [{"id", "level" (from), "to", "corners" [4 pts],
                       "kind": "straight" | "dogleg", "risers", "rise",
                       "going", "flip": bool}]
"""
from __future__ import annotations

import math
import uuid

RISER = 0.175
GOING_MAX = 0.30
GOING_MIN = 0.22
STAIR_COLOR = (0.74, 0.73, 0.70)


# ---- where -----------------------------------------------------------------------------
def rect_of(pts):
    """(centre, u (long axis), w (across), L (along)) of the smallest
    rectangle round ``pts``."""
    from shapely.geometry import MultiPoint
    r = MultiPoint([tuple(p[:2]) for p in pts]).minimum_rotated_rectangle
    c = list(r.exterior.coords)[:4]
    e0 = (c[1][0] - c[0][0], c[1][1] - c[0][1])
    e1 = (c[2][0] - c[1][0], c[2][1] - c[1][1])
    l0, l1 = math.hypot(*e0), math.hypot(*e1)
    if l0 >= l1:
        u, L, w = (e0[0] / l0, e0[1] / l0), l0, l1
    else:
        u, L, w = (e1[0] / l1, e1[1] / l1), l1, l0
    if u[0] < -1e-9 or (abs(u[0]) < 1e-9 and u[1] < 0):
        u = (-u[0], -u[1])                    # one way round, always
    cx = sum(p[0] for p in c) / 4
    cy = sum(p[1] for p in c) / 4
    return (cx, cy), u, w, L


def corners_of(centre, u, w, L):
    v = (-u[1], u[0])
    cx, cy = centre
    return [[round(cx + a * u[0] * L / 2 + b * v[0] * w / 2, 4),
             round(cy + a * u[1] * L / 2 + b * v[1] * w / 2, 4)]
            for a, b in ((-1, -1), (1, -1), (1, 1), (-1, 1))]


def from_cad(pl, match_stairs) -> list:
    """Stair wells in a placed drawing: closed outlines on the stair
    layers (2–40 m²), else the box round the stair layers' lines."""
    out = []
    for lp in pl["loops"]:
        if match_stairs(lp["layer"]):
            a = _area(lp["pts"])
            if 2.0 <= a <= 40.0:
                out.append(lp["pts"])
    if not out:
        lay = pl["layers"]
        segs = [s for s in pl["segs"] if match_stairs(lay[s[4]])]
        if len(segs) >= 6:
            pts = [(s[0], s[1]) for s in segs] + [(s[2], s[3]) for s in segs]
            _c, _u, w, L = rect_of(pts)
            if 2.0 <= w * L <= 40.0:
                out.append(pts)
    return [corners_of(*rect_of(p)) for p in out]


def from_rooms(arch, lid) -> list:
    """Rooms named STAIR… (STAIRCASE, STAIRS, ESCALERA…) on the level."""
    from .engine import spaces
    out = []
    try:
        rooms = spaces.of_level(arch, lid)
    except Exception:  # noqa: BLE001
        return out
    for r in rooms:
        n = str(r.get("name", "")).upper()
        if any(k in n for k in ("STAIR", "ESCAL", "ESCADA", "TREPP",
                                "SCALA")) and 2.0 <= r["area"] <= 60.0:
            poly = r.get("poly")
            pts = list(poly.exterior.coords)[:-1] if poly is not None else None
            if pts:
                out.append(corners_of(*rect_of(pts)))
    return out


def _area(pts):
    return abs(0.5 * sum(a[0] * b[1] - b[0] * a[1]
                         for a, b in zip(pts, list(pts[1:]) + [pts[0]])))


# ---- how --------------------------------------------------------------------------------
def n_risers(H, riser=RISER) -> int:
    """The number of risers for a storey H with risers no higher than
    ``riser`` (7" by default)."""
    return max(int(math.ceil(H / max(float(riser), 0.10) - 1e-6)), 2)


def design(corners, H, flip=False, riser=RISER, going=None,
           n=None, shape="u") -> dict:
    """Risers, going and kind for a well and a storey height H: risers no
    higher than ``riser``, treads ``going`` deep (11" by default) unless the
    well is too short for them (then as deep as it allows); ``n`` risers
    when given."""
    _c, _u, w, L = rect_of(corners)
    n = int(n) if n else n_risers(H, riser)
    rise = H / n
    want = float(going) if going else None
    straight_run = (n - 1) * (want or GOING_MIN)
    # a U-turn by default (two flights side by side, a half landing at the
    # far end); straight only when asked for and the well is long enough —
    # or too narrow for two flights
    if w < 1.6 or (shape == "straight" and L >= straight_run + 0.9):
        g = (L - 0.9) / (n - 1)
        g = min(want, g) if want else min(GOING_MAX, g)
        return {"kind": "straight", "risers": n, "rise": round(rise, 4),
                "going": round(max(g, 0.15), 4), "flip": flip}
    dl = w / 2                                   # half landing, square
    n1 = int(math.ceil(n / 2))
    g = (L - dl) / max(n1 - 1, 1)
    g = min(want, g) if want else min(GOING_MAX, g)
    return {"kind": "dogleg", "risers": n, "rise": round(rise, 4),
            "going": round(max(g, 0.15), 4), "flip": flip}


def redesign(st, new) -> dict:
    """A stair's new riser / tread / number of risers, as typed in its
    edit dialog: the storey height stays; a new number of risers sets the
    riser height, a new riser height sets the number (risers no higher);
    a designed stair re-lays its flights with the new tread in its well. A
    traced stair (drawn in the CAD) keeps its tread lines."""
    H = float(st.get("rise", 0.175)) * int(st.get("risers", 18))
    out = dict(new)
    n0, n1 = int(st.get("risers", 0)), int(new.get("risers", 0) or 0)
    r0, r1 = float(st.get("rise", 0)), float(new.get("rise", 0) or 0)
    if n1 and n1 != n0:
        n = n1
    elif r1 and abs(r1 - r0) > 1e-4:
        n = n_risers(H, r1)
    else:
        n = n0
    n = max(n, 2)
    out["risers"] = n
    out["rise"] = round(H / n, 4)
    if not st.get("traced") and st.get("corners"):
        d = design(st["corners"], H, st.get("flip", False),
                   going=float(new.get("going") or st.get("going", 0.2794)),
                   n=n, shape="straight" if st.get("kind") == "straight"
                   else "u")
        out.update(kind=d["kind"], going=d["going"])
    else:
        out["going"] = st.get("going")
    return out


def steps(st, z0) -> list:
    """[(name, footprint [4 pts], z bottom, z top)] — the stair as blocks:
    each step from the floor up to its tread (a solid stair), and the
    landing."""
    (cx, cy), u, w, L = rect_of(st["corners"])
    v = (-u[1], u[0])
    if st.get("flip"):
        v = (-v[0], -v[1])
    o = (cx - u[0] * L / 2 - v[0] * w / 2, cy - u[1] * L / 2 - v[1] * w / 2)

    def P(a, b):                     # a along u from the start, b across
        return (o[0] + u[0] * a + v[0] * b, o[1] + u[1] * a + v[1] * b)

    def quad(a0, a1, b0, b1):
        return [P(a0, b0), P(a1, b0), P(a1, b1), P(a0, b1)]
    n, rise, g = st["risers"], st["rise"], st["going"]
    out = []
    if st["kind"] == "straight":
        start = max((L - (n - 1) * g) / 2, 0.0)  # centred in the well
        for k in range(1, n):
            out.append((f"Step {k}", quad(start + (k - 1) * g,
                                          start + k * g, 0.0, w),
                        z0, z0 + k * rise))
        return out
    dl = w / 2
    n1 = int(math.ceil(n / 2))
    n2 = n - n1
    for k in range(1, n1):                       # first flight, side 0…w/2
        out.append((f"Step {k}", quad((k - 1) * g, k * g, 0.0, w / 2 - 0.01),
                    z0, z0 + k * rise))
    out.append(("Landing", quad(L - dl, L, 0.0, w), z0, z0 + n1 * rise))
    for k in range(1, n2):                       # second flight, back
        a1 = L - dl - (k - 1) * g
        out.append((f"Step {n1 + k}", quad(a1 - g, a1, w / 2 + 0.01, w),
                    z0, z0 + (n1 + k) * rise))
    return out


MAX_FLIGHT = 14          # risers in one flight at most: more, a landing


def split_flights(flights, landings, maxn=MAX_FLIGHT):
    """No flight of more than ``maxn`` risers: a longer one is split into
    flights as even as can be, with a landing between them — straight on,
    as deep as the flight is wide (0.9 m at least); the stair above it
    carried on by the landing's depth. (flights, landings, how many
    landings added)."""
    maxn = max(int(maxn or MAX_FLIGHT), 3)
    out_f, out_l = [], []
    lands = [dict(x) for x in landings or []]
    shift = [0.0, 0.0]                      # carried on to all above
    count = 0
    added = 0

    def mv(p):
        return [p[0] + shift[0], p[1] + shift[1]]
    # a landing keeps its place among the risers: moved by what was
    # inserted below it
    land_at = sorted(lands, key=lambda x: x.get("after", 0))
    li = 0
    for f in flights:
        lines = [[list(a), list(b)] for a, b in f["lines"]]
        d = f["d"]
        w = float(f.get("w", 1.0))
        g = float(f.get("g", 0.28))
        n = len(lines)
        k = int(math.ceil(n / maxn)) if n > maxn and not f.get("winder") \
            else 1
        sizes = [n // k + (1 if j < n % k else 0) for j in range(k)]
        pos = 0
        for j, sz in enumerate(sizes):
            # the landings below this run (their «after» within it)
            while li < len(land_at) and land_at[li].get("after", 0) <= count:
                L_ = land_at[li]
                out_l.append(dict(L_, corners=[mv(p) for p in L_["corners"]]))
                li += 1
            chunk = [[mv(a), mv(b)] for a, b in lines[pos:pos + sz]]
            nf = dict(f, lines=chunk)
            out_f.append(nf)
            count += sz
            pos += sz
            if j < k - 1:                    # a landing, then on
                D = max(w, 0.9)
                a, b = chunk[-1]
                pts = [tuple(a), tuple(b), (a[0] + d[0] * D, a[1] + d[1] * D),
                       (b[0] + d[0] * D, b[1] + d[1] * D)]
                out_l.append({"corners": [list(p) for p in _box_along(pts, d)],
                              "after": count})
                shift[0] += d[0] * (D - g)
                shift[1] += d[1] * (D - g)
                added += 1
    while li < len(land_at):
        L_ = land_at[li]
        out_l.append(dict(L_, corners=[mv(p) for p in L_["corners"]]))
        li += 1
    return out_f, out_l, added


def _as_traced(st, fl, lands):
    n = sum(len(f["lines"]) for f in fl)
    out = dict(st)
    out.update({"traced": True, "kind": "traced", "flights": [
        dict({"lines": [[list(a), list(b)] for a, b in f["lines"]],
              "d": list(f["d"]), "w": f["w"], "g": f["g"]},
             **({"winder": True} if f.get("winder") else {})) for f in fl],
        "landings": lands, "risers": n})
    out["corners"] = outline_of(out)
    return out


def extend_landings(st, room, reach=1.5) -> int:
    """The stair's landings carried out to the walls of its stair hall
    (``room``, the hall's inside outline): each landing grows sideways and
    on past the flight that ends at it, as far as the walls (``reach`` at
    most), never over a flight. How many grew."""
    from shapely.geometry import MultiPoint, Point, Polygon
    from shapely.ops import unary_union
    if room is None or room.is_empty or not st.get("landings"):
        return 0
    fl = st.get("flights") or []
    foots = []
    for f in fl:
        pts = [tuple(p[:2]) for ln in f["lines"] for p in ln]
        if not pts:
            continue
        d, g = f["d"], float(f.get("g", 0.28))
        a, b = f["lines"][-1]
        pts += [(a[0] + d[0] * g, a[1] + d[1] * g),
                (b[0] + d[0] * g, b[1] + d[1] * g)]
        foots.append(MultiPoint(pts).convex_hull.buffer(0.005))
    F = unary_union(foots) if foots else Polygon()
    inside = room.buffer(-0.005)
    n = 0
    count = 0
    ends = {}
    for f in fl:
        count += len(f["lines"])
        ends[count] = f
    for lg in st["landings"]:
        if lg.get("arrival") or lg.get("top"):
            continue                 # the floor above's own slab is there
        try:
            L0 = Polygon([tuple(p[:2]) for p in lg["corners"]]).buffer(0)
            if L0.is_empty:
                continue
            f = ends.get(int(lg.get("after", -1)))
            region = inside.intersection(L0.buffer(reach, join_style=2))
            if f is not None:            # not back down the flight it ends
                d = f["d"]
                back = min(p[0] * d[0] + p[1] * d[1]
                           for p in L0.exterior.coords) - 0.005
                c = L0.centroid
                big = 50.0
                u = (-d[1], d[0])
                o = (c.x + d[0] * (back - (c.x * d[0] + c.y * d[1])),
                     c.y + d[1] * (back - (c.x * d[0] + c.y * d[1])))
                half = Polygon([(o[0] - u[0] * big, o[1] - u[1] * big),
                                (o[0] + u[0] * big, o[1] + u[1] * big),
                                (o[0] + u[0] * big + d[0] * big,
                                 o[1] + u[1] * big + d[1] * big),
                                (o[0] - u[0] * big + d[0] * big,
                                 o[1] - u[1] * big + d[1] * big)])
                region = region.intersection(half)
            region = region.difference(F.difference(L0.buffer(0.002)))
            region = unary_union([region, L0])
            comp = next((g_ for g_ in getattr(region, "geoms", [region])
                         if g_.geom_type == "Polygon" and
                         g_.buffer(0.01).contains(L0.representative_point())),
                        None)
            if comp is None or comp.area < L0.area + 0.05:
                continue
            comp = comp.buffer(0.002, join_style=2).buffer(-0.002,
                                                           join_style=2)
            comp = comp.simplify(0.01)
            if comp.geom_type != "Polygon":
                continue
            lg["corners"] = [[round(x, 4), round(y, 4)]
                             for x, y in list(comp.exterior.coords)[:-1]]
            n += 1
        except Exception:  # noqa: BLE001
            continue
    return n


def u_stack(flights, n, mx=MAX_FLIGHT, room=None):
    """A U stair the plan draws (two flights side by side, running
    opposite ways) holding fewer risers than the storey needs: the flights
    go on turning in the same well — up, back, up again… over one another —
    each no longer than the flight drawn there (nor ``mx`` risers), a
    landing at each turn. None when the plan is not such a U (or it holds
    the storey already). (flights, landings)."""
    fs = [f for f in flights if f.get("lines")]
    if len(fs) != 2:
        return None
    d0, d1 = fs[0]["d"], fs[1]["d"]
    if d0[0] * d1[0] + d0[1] * d1[1] > -0.9:
        return None                       # not antiparallel: not a U
    have = sum(len(f["lines"]) for f in fs)
    if room is None and n <= have and all(len(f["lines"]) <= mx
                                          for f in fs):
        return None

    def fit(f, from_end):
        """How many of the flight's risers lie in the stair hall —
        counted from its end (an up flight) or its start (a return)."""
        ls = f["lines"][::-1] if from_end else f["lines"]
        if room is None:
            return len(ls)
        from shapely.geometry import LineString
        R = room.buffer(0.05)
        c = 0
        for a, b in ls:
            if not R.contains(LineString([a, b])):
                break
            c += 1
        return c
    caps = [min(fit(fs[0], True), mx), min(fit(fs[1], False), mx)]
    if room is not None and n <= caps[0] + caps[1] and \
            len(fs[0]["lines"]) <= caps[0] and \
            len(fs[1]["lines"]) <= caps[1]:
        return None                     # it fits the hall as it is
    if min(caps) < 2:
        return None
    k, tot = 0, 0
    while tot < n:
        tot += caps[k % 2]
        k += 1
        if k > 12:
            return None
    # risers shared out over the k flights, as their room allows
    want = [caps[i % 2] for i in range(k)]
    # as even as the hall lets them be (the first ones a riser more)
    sizes = [min(n // k + (1 if i < n % k else 0), want[i])
             for i in range(k)]
    while sum(sizes) < n:
        js = [i for i in range(k) if sizes[i] < want[i]]
        if not js:
            return None
        j = min(js, key=lambda i: (sizes[i], i))
        sizes[j] += 1
    if sum(sizes) != n:
        return None
    out = []
    for i, sz in enumerate(sizes):
        T = fs[i % 2]
        lines = [[list(a), list(b)] for a, b in T["lines"]]
        # the up flight ends at the far landing (its last risers kept);
        # the return flight starts at it (its first risers kept)
        chunk = lines[-sz:] if i % 2 == 0 else lines[:sz]
        out.append(dict(T, lines=chunk))
    lands = []
    count = 0
    for i, f in enumerate(out[:-1]):
        count += len(f["lines"])
        nx = out[i + 1]
        la, lb = f["lines"][-1]
        fa, fb = nx["lines"][0]
        d = f["d"]
        depth = float(f.get("w", 1.0))
        g = float(f.get("g", 0.28))
        la2 = (la[0] + d[0] * g, la[1] + d[1] * g)
        lb2 = (lb[0] + d[0] * g, lb[1] + d[1] * g)
        pts = [tuple(la2), tuple(lb2), tuple(fa), tuple(fb)]
        pts += [(p[0] + d[0] * depth, p[1] + d[1] * depth) for p in pts]
        lands.append({"corners": [list(p) for p in _box_along(pts, d)],
                      "after": count})
    # the arrival: the last step at the floor above, past the last riser
    f = out[-1]
    la, lb = f["lines"][-1]
    d = f["d"]
    depth = float(f.get("g", 0.28) or 0.28)
    g = float(f.get("g", 0.28))
    a2 = (la[0] + d[0] * g, la[1] + d[1] * g)
    b2 = (lb[0] + d[0] * g, lb[1] + d[1] * g)
    pts = [a2, b2, (a2[0] + d[0] * depth, a2[1] + d[1] * depth),
           (b2[0] + d[0] * depth, b2[1] + d[1] * depth)]
    lands.append({"corners": [list(p) for p in _box_along(pts, d)],
                  "after": count + len(f["lines"]), "top": True})
    return out, lands


def refit(r, H, n_need, mx=MAX_FLIGHT, stt0=None, flip=False) -> dict:
    """The stair ``r`` (the floor below's) made for a storey ``H`` high:
    ``n_need`` risers — the last flight lengthened (or shortened) as
    needed —, then no flight of more than ``mx`` risers (a landing between
    the parts)."""
    stt0 = stt0 or {}
    if not r.get("traced"):
        r0 = dict(design(r["corners"], H, r.get("flip", flip),
                         float(stt0.get("stair_riser", 0.1778)),
                         float(stt0.get("stair_going", 0.2794)),
                         shape=stt0.get("stair_shape", "u")),
                  corners=r["corners"])
        f0, l0 = as_flights(r0)
        if any(len(f["lines"]) > mx for f in f0):
            f1, l1, _n = split_flights(f0, l0, mx)
            r0 = _as_traced(r0, f1, l1)
        for k in OWN:
            if r.get(k):
                r0[k] = r[k]
        return r0
    n0 = int(r.get("risers") or 0)
    if n0 == n_need and all(len(f["lines"]) <= mx for f in r["flights"]):
        r["rise"] = round(H / n0, 4)
        return r
    fl = [dict(f, lines=[[list(a), list(b)] for a, b in f["lines"]])
          for f in r["flights"]]
    have = sum(len(f["lines"]) for f in fl)
    if n_need < have:                      # fewer: off the top flight(s)
        cut = have - n_need
        while cut > 0 and fl:
            last = fl[-1]["lines"]
            take = min(cut, len(last) if len(fl) > 1 else len(last) - 2)
            if take <= 0:
                break
            fl[-1]["lines"] = last[:len(last) - take]
            cut -= take
            if not fl[-1]["lines"]:
                fl.pop()
    fl, lands = complete(fl, n_need, None)
    have = sum(len(f["lines"]) for f in fl)
    if n_need > have and fl:               # more: the top flight goes on
        f = fl[-1]
        d, g = f["d"], float(f.get("g", 0.28))
        for _k in range(n_need - have):
            a, b = f["lines"][-1]
            f["lines"].append([[a[0] + d[0] * g, a[1] + d[1] * g],
                               [b[0] + d[0] * g, b[1] + d[1] * g]])
    fl, lands, _n = split_flights(fl, lands, mx)
    out = _as_traced(r, fl, lands)
    out["rise"] = round(H / out["risers"], 4)
    return out


# ---- doing it ---------------------------------------------------------------------------
def landings_for(out):
    """Landings between consecutive flights (a quarter turn: the corner
    square between them; a half turn: the band across both, a flight
    width deep) and the arrival past the last riser."""
    lands, count = [], 0
    for i, f in enumerate(out[:-1]):
        count += len(f["lines"])
        nx = out[i + 1]
        la, lb = f["lines"][-1]
        fa, fb = nx["lines"][0]
        d, d2 = f["d"], nx["d"]
        pts = [tuple(la), tuple(lb), tuple(fa), tuple(fb)]
        if abs(d[0] * d2[0] + d[1] * d2[1]) > 0.5:      # a half turn / on
            depth = float(f.get("w", 1.0))
            g = float(f.get("g", 0.28))
            pts = [(p[0] + d[0] * g, p[1] + d[1] * g) for p in pts[:2]] + \
                pts[2:]
            pts += [(p[0] + d[0] * depth, p[1] + d[1] * depth) for p in pts]
        lands.append({"corners": [list(p) for p in _box_along(pts, d)],
                      "after": count})
    f = out[-1]
    la, lb = f["lines"][-1]
    d = f["d"]
    g = float(f.get("g", 0.28) or 0.28)
    a2 = (la[0] + d[0] * g, la[1] + d[1] * g)
    b2 = (lb[0] + d[0] * g, lb[1] + d[1] * g)
    pts = [a2, b2, (a2[0] + d[0] * g, a2[1] + d[1] * g),
           (b2[0] + d[0] * g, b2[1] + d[1] * g)]
    lands.append({"corners": [list(p) for p in _box_along(pts, d)],
                  "after": count + len(f["lines"]), "top": True})
    return lands


def stacked(doc, lid_below, lid, flights, H):
    """3.64.12: a stair hall stacked over the floor below's: the plan of
    this floor draws the first flights going UP (the last one shows as the
    flight coming up from below, «DN»); the flights still to come turn as
    the stair below turns, in the same place — (flights, landings), or
    None."""
    from shapely.geometry import MultiPoint
    fs = [f for f in flights if f.get("lines")]
    if not fs or lid_below is None:
        return None
    have = sum(len(f["lines"]) for f in fs)
    hull = MultiPoint([tuple(p) for f in fs for ln in f["lines"]
                       for p in ln]).convex_hull.buffer(0.3)
    best = None
    for o in doc.get("stairs") or []:
        if o.get("level") != lid_below or o.get("to") != lid:
            continue
        ofs = [f for f in o.get("flights") or [] if f.get("lines")]
        if len(ofs) <= len(fs):
            continue
        if any(a["d"][0] * b["d"][0] + a["d"][1] * b["d"][1] < 0.9
               for a, b in zip(fs, ofs)):
            continue                     # it turns another way
        ohull = MultiPoint([tuple(p) for f in ofs for ln in f["lines"]
                            for p in ln]).convex_hull
        if ohull.area <= 0 or \
                hull.intersection(ohull).area < 0.6 * ohull.area:
            continue
        extra = ofs[len(fs):]
        n = have + sum(len(f["lines"]) for f in extra)
        if n <= 0 or not 0.14 <= H / n <= 0.2032:
            continue
        # the next flight starts past this floor's last flight drawn
        last = fs[-1]
        e = _mid(last["lines"][-1])
        s0 = _mid(extra[0]["lines"][0])
        dd = (s0[0] - e[0]) * last["d"][0] + (s0[1] - e[1]) * last["d"][1]
        if dd < -0.3:
            continue
        best = (fs, extra)
        break
    if best is None:
        return None
    fs, extra = best
    out = [dict(f, lines=[[list(a), list(b)] for a, b in f["lines"]])
           for f in fs]
    out += [dict(f, lines=[[list(a), list(b)] for a, b in f["lines"]])
            for f in extra]
    return out, landings_for(out)


def auto(doc, cad=None, flip=False) -> dict:
    """Stairs on every floor, as the plans draw them: the tread lines of
    each level's stair layer give the flights (their width, risers, turn
    and landings — completed with a return flight when the plan shows the
    lower flight only); where the plan has no stair lines, a stair well
    (an outline on the stair layer, a room named STAIR…) gets a standard
    stair; a level with neither takes the floor below's. Each stair goes
    up to the next level and cuts its well in that level's slab. Replaces
    the stairs before (and the wells they cut)."""
    from shapely.geometry import Point

    from . import project as PJ
    from .engine import model as M
    from .engine import spaces
    from .engine import structure as S
    arch = doc["arch"]
    stt0 = doc.get("settings") or {}
    _uncut(doc)
    # what each stair set for itself survives a re-make (by where it is)
    kept = {}
    for s0 in doc.get("stairs") or []:
        cs0 = s0.get("corners") or []
        if cs0 and any(s0.get(k) for k in OWN):
            kept[(s0["level"], round(sum(p[0] for p in cs0) / len(cs0), 1),
                  round(sum(p[1] for p in cs0) / len(cs0), 1))] = \
                {k: s0[k] for k in OWN if s0.get(k)}
    relaid = []                 # flights turned by hand: by the stair's foot
    for s0 in doc.get("stairs") or []:
        if s0.get("foot0") and (s0.get("turns") is not None or
                                s0.get("rot")):
            relaid.append((s0["level"], tuple(s0["foot0"]),
                           s0.get("turns"), s0.get("rot", 0.0),
                           s0.get("counts")))
    doc["stairs"] = []
    levels = arch["levels"]
    info = S.levels_info(arch, M.elevations)
    cad = cad if cad is not None else doc.get("stair_cad") or {}
    made, cut, traced_n = 0, 0, 0
    carried = []
    for i, lv in enumerate(levels):
        up = levels[i + 1] if i + 1 < len(levels) else None
        if up is not None and not any(
                w["level"] == up["id"] for w in arch["walls"]) and \
                not any(e["level"] == up["id"] for e in arch["structure"]):
            up = None                       # nothing built up there yet
        if up is None:
            # the top floor (or nothing above yet): its stairs as the plan
            # draws them, one storey high — no well to cut up there
            if str(lv.get("name", "")).strip().lower() == "roof" or \
                    not any(w["level"] == lv["id"] for w in arch["walls"]):
                continue
            H = float(lv.get("height") or 3.0)
        else:
            H = info[up["id"]]["z0"] - info[lv["id"]]["z0"]
        n_need = n_risers(H, float(stt0.get("stair_riser", 0.1778)))
        recs = []
        try:
            chains = PJ.stair_trace(doc, lv["id"])
        except Exception:  # noqa: BLE001
            chains = []
        try:
            rooms = spaces.of_level(arch, lv["id"])
        except Exception:  # noqa: BLE001
            rooms = []
        dn_only = 0
        for flights in chains:
            if sum(len(f["lines"]) for f in flights) < 3:
                continue
            if flights and flights[0].get("_dn_only") and i > 0 and \
                    stt0.get("stair_dn_skip", True):
                dn_only += 1          # the stair from below, going DN
                continue
            if len(flights) == 1 and sum(len(f["lines"])
                                         for f in flights) <= 6 or \
                    max(len(f["lines"]) for f in flights) <= 4:
                # a single short flight (a few steps down into a pit, a
                # trench, a sunken room): steps, not the storey's stair
                continue
            m = _mid(flights[0]["lines"][0])
            room = next((r["poly"] for r in rooms
                         if r["poly"].buffer(0.3).contains(Point(m))), None)
            if room is None and flights:      # its foot outside: the hall
                m2 = _mid(flights[-1]["lines"][-1])   # it climbs into
                room = next((r["poly"] for r in rooms
                             if r["poly"].buffer(0.3).contains(Point(m2))),
                            None)
            # the plan's own risers when they climb the storey at a
            # riser of 8" at most: no return flight invented beside them
            have = sum(len(f["lines"]) for f in flights)
            n_use = have if have and H / have <= 0.2032 else n_need
            diag = flights[0].get("_diag") if flights else None
            mx_ = int(stt0.get("stair_max_flight", MAX_FLIGHT))
            u_ = None
            if stt0.get("stair_shape", "u") == "u" and not diag:
                try:                 # a U drawn: more flights go on in it
                    u_ = u_stack(flights, n_use, mx_)
                except Exception:  # noqa: BLE001
                    from .host import log_error
                    log_error("stairs.u_stack")
                    u_ = None
            if u_ is not None:
                fl, lands = u_
            else:
                try:                 # the walls round it (no hall room)
                    from . import slabedges as _SE
                    from shapely.ops import unary_union as _uu
                    blk_ = _uu(_SE.wall_polys([
                        w_ for w_ in arch["walls"] if w_["level"] == lv["id"]
                        and not w_.get("rail")]))
                except Exception:  # noqa: BLE001
                    blk_ = None
                fl, lands = complete(flights, n_use, room,
                                     n_min=int(math.ceil(H / 0.2032 - 1e-6)),
                                     blocked=blk_)
                if stt0.get("stair_shape", "u") == "u" and \
                        (room is not None and len(fl) == 2 or
                         room is None and len(flights) == 2):
                    # the flights run past the hall: they turn back and
                    # forth in it instead — a U going on up over itself
                    try:
                        u_ = u_stack(fl, n_use, mx_, room)
                        if u_ is None and room is None:
                            # no hall found round it: the U the plan
                            # draws, turning on over itself
                            u_ = u_stack(flights, n_use, mx_)
                    except Exception:  # noqa: BLE001
                        from .host import log_error
                        log_error("stairs.u_stack hall")
                        u_ = None
                    if u_ is not None:
                        fl, lands = u_
                        diag = None
            if diag:
                try:                 # winders drawn on a turning landing
                    fl, lands = winders(fl, lands, diag)
                except Exception:  # noqa: BLE001
                    from .host import log_error
                    log_error("stairs.winders")
            try:                 # the floor below's stair in this hall
                stk_ = stacked(doc, levels[i - 1]["id"] if i > 0 else
                               None, lv["id"], flights, H)
            except Exception:  # noqa: BLE001
                from .host import log_error
                log_error("stairs.stacked")
                stk_ = None
            if stk_ is not None:
                fl, lands = stk_
            if not any(f.get("_ext") for f in fl):
                fl, lands, _nl = split_flights(
                    fl, lands, int(stt0.get("stair_max_flight", MAX_FLIGHT)))
            n = sum(len(f["lines"]) for f in fl)
            st = {"traced": True, "flights": [
                dict({"lines": [[list(a), list(b)] for a, b in f["lines"]],
                      "d": list(f["d"]), "w": f["w"], "g": f["g"]},
                     **({"winder": True} if f.get("winder") else {}))
                for f in fl],
                "landings": lands, "risers": n, "rise": round(H / n, 4),
                "going": round(fl[0]["g"], 4), "kind": "traced"}
            st["corners"] = outline_of(st)
            recs.append(st)
            traced_n += 1
        if not recs and dn_only:      # only the stair from below: none
            carried = []              # climbs on from this floor
            continue
        if not recs and up is not None:   # (the top floor: only as drawn)
            wells = list(cad.get(lv["id"]) or []) or \
                from_rooms(arch, lv["id"])
            for corners in wells:
                r0 = dict(design(
                    corners, H, flip,
                    float(stt0.get("stair_riser", 0.1778)),
                    float(stt0.get("stair_going", 0.2794)),
                    shape=stt0.get("stair_shape", "u")),
                    corners=corners)
                mx = int(stt0.get("stair_max_flight", MAX_FLIGHT))
                f0, l0 = as_flights(r0)
                if any(len(f["lines"]) > mx for f in f0):
                    f1, l1, _nl = split_flights(f0, l0, mx)
                    r0 = _as_traced(r0, f1, l1)
                recs.append(r0)
        if not recs and carried and not (doc.get("imports") or {}).get(
                lv["id"]):                        # the floor below's stair
            # (only on a floor with no plan of its own: one imported that
            # draws no stair has none)
            # (a new floor added over it: the stair made again for this
            # storey's height — its risers no higher than the riser set,
            # no flight longer than the most steps set, a landing between)
            mx = int(stt0.get("stair_max_flight", MAX_FLIGHT))
            recs = []
            for r in carried:
                try:
                    recs.append(refit(dict(r), H, n_need, mx, stt0, flip))
                except Exception:  # noqa: BLE001
                    from .host import log_error
                    log_error("stairs.refit")
                    r = dict(r)
                    if r.get("traced"):
                        r["rise"] = round(H / r["risers"], 4)
                    recs.append(r)
        if recs:
            carried = recs
        for r in recs:
            r = dict(r, id=uuid.uuid4().hex[:8], level=lv["id"],
                     to=up["id"] if up is not None else None)
            # the landings out to the stair hall's walls
            if stt0.get("landing_to_walls", True) and r.get("corners"):
                try:
                    cs_ = r["corners"]
                    cpt = Point(sum(p[0] for p in cs_) / len(cs_),
                                sum(p[1] for p in cs_) / len(cs_))
                    hall = next((q["poly"] for q in rooms
                                 if q["poly"].buffer(0.3).contains(cpt)
                                 and q["area"] < 80.0), None)
                    if hall is not None:
                        if not r.get("traced"):
                            f0, l0 = as_flights(r)
                            if l0:
                                r = dict(_as_traced(r, f0, l0),
                                         rise=r.get("rise"),
                                         going=r.get("going"))
                        extend_landings(r, hall)
                except Exception:  # noqa: BLE001
                    from .host import log_error
                    log_error("stairs.extend_landings")
            cs1 = r.get("corners") or []
            if cs1 and kept:
                r.update(kept.get((lv["id"], round(sum(
                    p[0] for p in cs1) / len(cs1), 1), round(sum(
                        p[1] for p in cs1) / len(cs1), 1)), {}))
            if relaid:
                ft = foot_of(r)
                hit = next((x for x in relaid if x[0] == lv["id"] and ft
                            and math.dist(ft, x[1]) < 0.6), None)
                if hit is not None:
                    try:
                        drop_holes_over(doc, r)   # the CAD's hole there
                        r = relay(r, hit[2], hit[3], hit[4])
                        r["foot0"] = list(hit[1])
                    except Exception:  # noqa: BLE001
                        pass
            doc["stairs"].append(r)
            made += 1
            # the well: only over the steps that need it — 7'-0" clear
            # over every step (the lower steps stay under the slab)
            well = r["corners"]
            wm = stt0.get("stair_well", "railing")
            if wm != "outline" and stt0.get("stair_headroom_cut", True):
                hc = headroom_cut(r, H, float(stt0.get("slab_t", 0.15)),
                                  float(stt0.get("stair_head", HEADROOM)),
                                  wm)
                if hc:
                    well = hc
            if PJ.slab_on_top(doc):
                # the slab over this floor is its own: the well in it
                cut += _cut(arch, lv["id"], well)
            elif up is not None:
                cut += _cut(arch, up["id"], well)
    if not PJ.slab_on_top(doc):   # 3.64.11: the well each floor's plan
        for r_ in doc["stairs"]:      # draws over the stair coming up to it
            try:
                w_ = upper_well(doc, r_)
                if w_:
                    cut += _cut(arch, r_["to"], w_)
            except Exception:  # noqa: BLE001
                from .host import log_error
                log_error("stairs.upper_well")
    if not PJ.slab_on_top(doc):   # 3.64.24: the railing the floor above
        for r_ in doc["stairs"]:      # draws by the stair: its slab up to it
            try:
                cut += apply_cad_split(doc, r_)
            except Exception:  # noqa: BLE001
                from .host import log_error
                log_error("stairs.apply_cad_split")
    try:                       # no terrace railing floating over a flight
        PJ.rails_off_stairs(doc)
    except Exception:  # noqa: BLE001
        from .host import log_error
        log_error("stairs rails_off_stairs")
    try:                      # no sliver of landing run on under a flight
        for st_ in doc["stairs"]:
            clean_landings(st_)
    except Exception:  # noqa: BLE001
        from .host import log_error
        log_error("stairs.clean_landings")
    try:                     # no thin notch of floor left open by the well
        clean_well_holes(doc)
    except Exception:  # noqa: BLE001
        from .host import log_error
        log_error("stairs.clean_well_holes")
    try:             # 3.64.77: the landing where a stair arrives upstairs
        from . import project as PJ_
        PJ_.stair_arrival_slabs(doc)
    except Exception:  # noqa: BLE001
        from .host import log_error
        log_error("stairs.arrival_slabs")
    return {"stairs": made, "cuts": cut, "traced": traced_n}


def _opened(hp, thin=0.30, foot=None):
    """The hole without its thin strips (narrower than ``thin``); with the
    stair's ``foot``, without the thin strips of it beyond the stair (a
    jog of a few cm along the landing's edge)."""
    if foot is not None:
        inside = hp.intersection(foot.buffer(0.02, join_style=2))
        rest = hp.difference(foot.buffer(0.02, join_style=2))
        rest = rest.buffer(-thin / 2, join_style=2).buffer(
            thin / 2, join_style=2)
        q = inside.union(rest).buffer(0.002, join_style=2).buffer(
            -0.002, join_style=2)
    else:
        q = hp.buffer(-thin / 2, join_style=2).buffer(thin / 2,
                                                      join_style=2)
    if q.is_empty:
        return None
    if q.geom_type != "Polygon":
        q = max(getattr(q, "geoms", [q]), key=lambda g: g.area)
    q = q.intersection(hp)
    if q.geom_type != "Polygon":
        q = max(getattr(q, "geoms", [q]), key=lambda g: g.area)
    if q.area < 0.9 * hp.area:
        return None
    return q.simplify(0.01)


def clean_well_holes(doc, thin=0.30) -> int:
    """A stair well's hole in the slab cleaned: the thin notches the cut
    leaves round it (a strip of floor 25 cm wide left open beside the
    landing, a jog where two cuts meet) closed with slab, so the floor
    edge — and the railing on it — runs straight. How many holes."""
    from shapely.geometry import Polygon
    feet = []
    for st in doc.get("stairs") or []:
        try:
            feet.append(Polygon([tuple(p[:2]) for p in st["corners"]]))
        except Exception:  # noqa: BLE001
            continue
    n = 0
    for e in doc["arch"]["structure"]:
        if e["type"] != "slab" or not e.get("holes"):
            continue
        new = []
        for hl in e["holes"]:
            try:
                hp = Polygon([tuple(p[:2]) for p in hl]).buffer(0)
            except Exception:  # noqa: BLE001
                new.append(hl)
                continue
            mine = [f for f in feet if hp.intersects(f) and
                    hp.intersection(f).area > 0.3 * min(hp.area, f.area)]
            if hp.is_empty or len(hl) < 5 or not mine:
                new.append(hl)
                continue
            from shapely.ops import unary_union
            q = _opened(hp, thin, unary_union(mine))
            if q is None or abs(q.area - hp.area) < 1e-3:
                new.append(hl)
                continue
            new.append([[round(x, 4), round(y, 4)]
                        for x, y in list(q.exterior.coords)[:-1]])
            n += 1
        e["holes"] = new
    return n


def clean_landings(st, thin=0.15) -> int:
    """A traced landing's outline cleaned: the thin strips the tracing
    leaves along a flight's first riser (a few cm wide, the landing
    carried on under the steps — a tread stuck out of the riser) are
    cut off. The number of landings cleaned."""
    from shapely.geometry import Polygon
    n = 0
    for lg in st.get("landings") or []:
        cs = lg.get("corners") or []
        if len(cs) < 5:
            continue
        try:
            p = Polygon(cs).buffer(0)
            q = p.buffer(-thin / 2, join_style=2).buffer(thin / 2,
                                                         join_style=2)
            if q.is_empty:
                continue
            if q.geom_type != "Polygon":
                q = max(getattr(q, "geoms", [q]), key=lambda g: g.area)
            q = q.intersection(p)
            if q.geom_type != "Polygon":
                q = max(getattr(q, "geoms", [q]), key=lambda g: g.area)
            if q.area < 0.85 * p.area or abs(q.area - p.area) < 1e-4:
                continue
            q = q.simplify(0.005)
            lg["corners"] = [[round(x, 4), round(y, 4)]
                             for x, y in list(q.exterior.coords)[:-1]]
            n += 1
        except Exception:  # noqa: BLE001
            continue
    return n


def _cut(arch, lid, corners) -> int:
    """The well cut in the level's slab(s) that hold it."""
    from shapely.geometry import Polygon
    from shapely.ops import unary_union as _uu

    def P(pts):
        try:
            g = Polygon([tuple(p[:2]) for p in pts])
            return g if g.is_valid else g.buffer(0)
        except Exception:  # noqa: BLE001
            return Polygon()
    hole = P(corners)
    if hole.is_empty:
        return 0
    n = 0
    for s in arch["structure"]:
        if s["type"] != "slab" or s["level"] != lid:
            continue
        if s.get("roof") or s.get("top"):
            continue           # 3.64.24: the roof over the floor: closed
        outer = P(s["corners"])
        part = outer.buffer(-0.02).intersection(hole)
        if part.is_empty or part.area < 0.5:
            continue
        holes = s.setdefault("holes", [])
        hp = [(h, P(h)) for h in holes]
        if any(g.intersects(part) for _h, g in hp):
            # 3.64.24: an opening there already (the CAD's stair hole): the
            # two as one opening, their own outline (never their hull — a
            # well spilling over the floor beside it)
            keep, mg = [], [part]
            for h, g in hp:
                if not g.is_empty and g.intersects(part):
                    mg.append(g)
                else:
                    keep.append(h)
            part = _uu(mg).intersection(outer.buffer(-0.02))
            holes[:] = keep
        for gpart in getattr(part, "geoms", [part]):
            if gpart.geom_type == "Polygon" and gpart.area >= 0.5:
                holes.append([[round(x, 4), round(y, 4)]
                              for x, y in list(gpart.exterior.coords)[:-1]])
                n += 1
    return n


HEADROOM = 2.1336            # 7'-0" clear over every step


def refit_heights(doc) -> int:
    """Every stair's risers re-spaced to its storey's height now (the
    floors and levels changed): the same steps, the risers taller or
    shorter so the stair still lands on the floor above. How many."""
    from .engine import model as M
    from .engine import structure as S
    arch = doc["arch"]
    info = S.levels_info(arch, M.elevations)
    n = 0
    for st in doc.get("stairs") or []:
        lv = info.get(st.get("level"))
        if lv is None:
            continue
        up = info.get(st.get("to")) if st.get("to") else None
        H = (up["z0"] - lv["z0"]) if up else float(lv["height"])
        k = int(st.get("risers") or 0)
        if k <= 0 or H <= 0:
            continue
        r = round(H / k, 4)
        if abs(r - float(st.get("rise") or 0)) > 1e-4:
            st["rise"] = r
            n += 1
    return n


def cut_well(doc, r) -> int:
    """The well of stair ``r`` cut in the slab over it (as «Stairs» does)."""
    from . import project as PJ
    from .engine import model as M
    from .engine import structure as S
    arch = doc["arch"]
    stt0 = doc.get("settings") or {}
    info = S.levels_info(arch, M.elevations)
    lv = next((x for x in arch["levels"] if x["id"] == r["level"]), None)
    if lv is None:
        return 0
    up = next((x for x in arch["levels"] if x["id"] == r.get("to")), None)
    if up is not None:
        H = info[up["id"]]["z0"] - info[lv["id"]]["z0"]
    else:
        H = float(lv.get("height") or 3.0)
    well = r["corners"]
    wm = stt0.get("stair_well", "railing")
    if wm != "outline" and stt0.get("stair_headroom_cut", True):
        hc = headroom_cut(r, H, float(stt0.get("slab_t", 0.15)),
                          float(stt0.get("stair_head", HEADROOM)), wm)
        if hc:
            well = hc
    if PJ.slab_on_top(doc):
        return _cut(arch, lv["id"], well)
    if up is not None:
        return _cut(arch, up["id"], well)
    return 0


def drop_holes_over(doc, st) -> int:
    """The slab openings over stair ``st``'s outline (its well, a stair hole
    drawn in the CAD merged with it) closed — on its level and the next —
    before the stair is laid out again somewhere else."""
    from shapely.geometry import Polygon
    cs = st.get("corners") or []
    if len(cs) < 3:
        return 0
    o = Polygon(cs).buffer(0.05)
    if not o.is_valid:
        o = o.buffer(0)
    lids = {st.get("level"), st.get("to")}
    n = 0
    for s in doc["arch"]["structure"]:
        if s["type"] != "slab" or s["level"] not in lids:
            continue
        keep = []
        for h in s.get("holes") or []:
            try:
                hp = Polygon(h)
                if not hp.is_valid:
                    hp = hp.buffer(0)
                share = hp.intersection(o).area
            except Exception:  # noqa: BLE001
                keep.append(h)
                continue
            if hp.area >= 0.3 and share >= 0.3 * hp.area:
                n += 1
                continue
            keep.append(h)
        s["holes"] = keep
    return n


def restair(doc, sid, turns, rot, counts) -> dict:
    """Stair ``sid`` laid again by hand: ``counts`` risers in each flight
    (their number the number of flights), ``turns`` how each flight leaves
    the landing before it, the whole stair turned to ``rot`` degrees round
    its foot. The landings follow the turns; the slab's well is cut again.
    Kept through «Stairs» (made again from the CAD) by the stair's foot."""
    st = next((x for x in doc.get("stairs") or [] if x.get("id") == sid),
              None)
    if st is None:
        raise ValueError("stair not found")
    foot0 = st.get("foot0") or foot_of(st)
    d_rot = float(rot or 0.0) - float(st.get("rot") or 0.0)
    new = relay(st, turns, d_rot, counts)
    new["rot"] = float(rot or 0.0)
    new["foot0"] = [round(foot0[0], 4), round(foot0[1], 4)]
    _uncut(doc, [st])
    drop_holes_over(doc, st)               # its old opening, upstairs too
    i = doc["stairs"].index(st)
    doc["stairs"][i] = new
    cut_well(doc, new)
    return new


def unstair(doc, sid) -> bool:
    """The hand turns of stair ``sid`` forgotten (back to the CAD's)."""
    st = next((x for x in doc.get("stairs") or [] if x.get("id") == sid),
              None)
    if st is None:
        return False
    for k in ("turns", "rot", "counts", "foot0"):
        st.pop(k, None)
    return True


WELL_MODES = [("railing", "Following the railing (whole flights that "
                         "need headroom, their landings)"),
              ("headroom", "Only over the steps short of 7'-0\" headroom"),
              ("outline", "The whole stair outline")]


def headroom_cut(st, H, slab_t, head=HEADROOM, mode="headroom"):
    """The part of the stair's outline the slab above must leave open so
    every step and landing keeps ``head`` clear under the slab's soffit:
    the treads (and landings) higher than (H − slab − head) — the lower
    steps, with headroom to spare, stay under the slab. Corners [[x, y]]
    or None (cut the whole outline)."""
    from shapely.geometry import Polygon
    from shapely.ops import unary_union
    try:
        flights, lands = as_flights(st)
        n = int(st.get("risers") or sum(len(f["lines"]) for f in flights))
        rise = float(st.get("rise") or (H / max(n, 1)))
        cut_z = H - float(slab_t) - float(head)
        parts, k = [], 0
        for f in flights:
            d = f["d"]
            g = float(f.get("g") or st.get("going") or 0.28)
            k0 = k
            need = any((k0 + j + 1) * rise >= cut_z - 1e-6
                       for j in range(len(f["lines"])))
            for a, b in f["lines"]:
                k += 1
                ztop = k * rise                  # the tread over riser k
                # «railing»: a flight that needs headroom opened its whole
                # length, so the opening's edge runs along its railing
                if ztop >= cut_z - 1e-6 or (mode == "railing" and need):
                    q = [tuple(a), tuple(b),
                         (b[0] + d[0] * g, b[1] + d[1] * g),
                         (a[0] + d[0] * g, a[1] + d[1] * g)]
                    pg = Polygon(q).buffer(0)
                    if not pg.is_empty:
                        parts.append(pg)
        for ld in lands:
            z = float(ld.get("after", 0)) * rise
            if z >= cut_z - 1e-6 and len(ld.get("corners") or []) >= 3:
                parts.append(Polygon(ld["corners"]).buffer(0))
        if not parts:
            return None
        outline = Polygon(st["corners"]).buffer(0.02)
        u = unary_union([p.buffer(0.03, join_style=2) for p in parts])
        u = u.buffer(0.15, join_style=2).buffer(-0.15, join_style=2)
        u = u.intersection(outline)
        g_ = max(getattr(u, "geoms", [u]), key=lambda x: x.area)
        if g_.geom_type != "Polygon" or g_.area < 0.5:
            return None
        if g_.area > 0.97 * Polygon(st["corners"]).area:
            return None                          # all of it anyway
        return [[round(x, 4), round(y, 4)]
                for x, y in list(g_.simplify(0.01).exterior.coords)[:-1]]
    except Exception:  # noqa: BLE001
        return None


def _uncut(doc, only=None) -> None:
    """The wells the stairs before cut (``only`` those), closed again."""
    from shapely.geometry import Polygon
    arch = doc["arch"]
    olds = [Polygon(st["corners"]) for st in (
        only if only is not None else doc.get("stairs") or [])
        if len(st.get("corners") or []) >= 3]
    for s in arch["structure"]:
        if s["type"] != "slab" or not olds:
            continue
        keep = []
        for h in s.get("holes") or []:
            hp = Polygon(h)
            if any(hp.is_valid and o.is_valid and
                   hp.intersection(o).area >= 0.9 * hp.area and
                   hp.area >= 0.5 for o in olds):
                continue
            keep.append(h)
        s["holes"] = keep


#: what one stair may set for itself (else the panel's defaults)
OWN = ("stype", "rail", "rail_h", "rail_sides", "rail_off", "rail_gap",
       "rail_ext", "fin", "nose_type")
SIDES = ("inner", "outer", "both", "none")


def _own(st, k, stt, sk, dv):
    v = st.get(k)
    return stt.get(sk, dv) if v is None or v == "" else v


def eff(st, stt) -> dict:
    """The stair's own type and railing, or the defaults."""
    return {"stype": st.get("stype") or stt.get("stair_type", "monolithic"),
            "rail": st.get("rail") or stt.get("stair_rail", "ss_bars"),
            "rail_h": float(st.get("rail_h") or stt.get("stair_rail_h",
                                                       0.9144)),
            "rail_sides": st.get("rail_sides")
            or stt.get("stair_rail_sides", "inner"),
            "rail_off": float(_own(st, "rail_off", stt, "stair_rail_off",
                                   0.05)),
            "rail_gap": float(_own(st, "rail_gap", stt, "stair_rail_gap",
                                   0.0)),
            "rail_ext": float(_own(st, "rail_ext", stt, "stair_rail_ext",
                                   0.0)),
            "fin": st.get("fin") or stt.get("stair_fin", "marble"),
            "nose_type": st.get("nose_type") or stt.get("stair_nose_type",
                                                        "square")}


def groups(doc, z_of, layer_of):
    """[(name, stair id, level id, [(faces, colour)…], layer,
    [(faces, colour)…] of its railing)]."""
    stt = doc.get("settings") or {}
    out = []
    roofed = {s_["level"] for s_ in doc["arch"]["structure"]
              if s_["type"] == "slab" and s_.get("roof")}
    for st in doc.get("stairs") or []:
        z0 = z_of.get(st["level"])
        if z0 is None:
            continue
        if not st.get("to") and st["level"] not in roofed and \
                not stt.get("top_stair", False):
            continue        # the top floor's stair, no roof over it: up to
            #                 nothing (it is made when the roof is)
        e = eff(st, stt)
        fin_t = float(stt.get("stair_fin_t", 0.02))
        try:                  # finished floor to finished floor: the floor
            lo, hi = floor_finishes(doc, st)    # finish under its foot and
        except Exception:  # noqa: BLE001      # on the slab it arrives at
            from .host import log_error
            log_error("stairs.floor_finishes")
            lo = hi = 0.0
        drop = 0.0              # a foot outside, lower (verandah, ground)
        try:
            ft = foot_of(st)
            if ft is not None:
                from . import project as PJ
                drop = PJ.floor_top_at(doc, st["level"], ft) - \
                    (z_of[st["level"]] + lo)
                drop = drop if drop < -0.03 else 0.0
        except Exception:  # noqa: BLE001
            drop = 0.0
        if lo or hi or drop:
            n_ = int(st.get("risers") or 1) or 1
            H_ = float(st["rise"]) * n_ + hi - lo - drop
            st = dict(st, rise=H_ / n_)
            z0 += lo + drop
            if hi > 0.001:
                fin_t = hi            # treads / landings: the slab's finish
        parts = build(st, z0, e["stype"], float(stt.get("stair_waist", 0.15)),
                      float(stt.get("stair_nosing", 0.025)),
                      float(stt.get("stair_tread", 0.05)), None,
                      fin=fin_colour(e["fin"]),
                      fin_t=fin_t,
                      fin_rt=float(stt.get("stair_fin_rt", 0.015)),
                      nose_type=e["nose_type"])
        rails = build_rail(st, z0, e["rail"], e["rail_h"], e["rail_sides"],
                           e["rail_off"], e["rail_gap"], e["rail_ext"],
                           _floor_of(parts), _walls_of(doc, st["level"]))
        if e["rail"] and e["rail"] != "none" and e["rail_sides"] != "none":
            try:                         # round the opening, upstairs
                guard = _well_guard(doc, st, z0, e["rail"], e["rail_h"],
                                    e["rail_gap"])
                # 3.64.15: the stair of the floor above going on up in the
                # same hall (shown): the opening is its stair hall — its
                # flights' own railings guard the well, as the plan draws
                # it; no railing round the hall across that floor
                up_ = _upper_stair(doc, st)
                if up_ is not None and up_.get("id") not in _hidden_ids(
                        doc) and (doc.get("rail_cad") or {}).get(
                        st.get("to")) is None:
                    guard = []
            except Exception:  # noqa: BLE001
                guard = []
            skip = {int(k) for k in st.get("rail_skip") or []
                    if str(k).lstrip("-").isdigit()}
            n0 = len(rails)
            rails = rails + [(fs, c) if (n0 + k) not in skip else ([], c)
                             for k, (fs, c) in enumerate(guard)]
        out.append((f"Stair {len(out) + 1}", st["id"], st["level"], parts,
                    layer_of(st["level"]), rails))
    return out


def floor_finishes(doc, st) -> tuple:
    """(below, above): the floor finish's thickness (m) under the stair's
    first step, on its own level, and where it arrives, on the slab above —
    each the finish of that room / slab zone (its own, the slab's, else the
    default); 0 with floor finishes off or «Stair finish follows the floor
    finish» unticked. The stair climbs from finished floor to finished
    floor and its treads and landings take the slab's finish."""
    stt = doc.get("settings") or {}
    if not stt.get("finish_on", True) or not stt.get("stair_fin_follow",
                                                      True):
        return 0.0, 0.0
    from . import project as PJ
    from .engine import spaces
    from shapely.geometry import Point
    flights, _l = as_flights(st)
    if not flights or not flights[0]["lines"]:
        return 0.0, 0.0
    foot = _mid(flights[0]["lines"][0])
    d0 = _nrm(flights[0]["d"])
    foot = (foot[0] - d0[0] * 0.3, foot[1] - d0[1] * 0.3)   # before it
    top_l = flights[-1]["lines"][-1]
    dt = _nrm(flights[-1]["d"])
    g = float(flights[-1].get("g") or 0.28)
    top = _mid(top_l)
    top = (top[0] + dt[0] * (g + 0.3), top[1] + dt[1] * (g + 0.3))

    def at(lid, pt):
        if not lid:
            return None
        rec = None
        try:
            for room in spaces.of_level(doc["arch"], lid):
                if room["poly"].contains(Point(pt)):
                    rec = room.get("rec")
                    break
        except Exception:  # noqa: BLE001
            pass
        try:
            _z, _w, thick = PJ._slab_finish_zones(doc, lid)
        except Exception:  # noqa: BLE001
            thick = []
        return float(PJ._finish_t_at(doc, rec, thick, pt) or 0.0)
    lo = at(st.get("level"), foot) or 0.0
    hi = at(st.get("to"), top)
    if hi is None:
        hi = lo
    return max(lo, 0.0), max(hi, 0.0)


def _flight_zones(st, keep_none=False):
    """Each flight's area in plan (its treads' band), as polygons (with
    ``keep_none``: one entry per flight, None where it makes none)."""
    from shapely.geometry import MultiPoint
    out = []
    fl, _l = as_flights(st)
    for f in fl:
        pts = [tuple(p[:2]) for ln in f.get("lines") or [] for p in ln]
        z = None
        if len(pts) >= 2 and f.get("lines"):
            g = float(f.get("g", 0.28) or 0.28)
            d = f.get("d") or (0.0, 0.0)
            last = f["lines"][-1]
            pts += [(p[0] + d[0] * g, p[1] + d[1] * g) for p in last]
            h_ = MultiPoint(pts).convex_hull
            if h_.geom_type == "Polygon" and h_.area > 1e-4:
                z = h_
        if z is not None or keep_none:
            out.append(z)
    return out


def cad_well(doc, st):
    """The well the plan draws in the stair's hall: the closed outline its
    rail layer draws inside the hall (the railing round the void between
    the flights) — or None."""
    from shapely.geometry import LineString, Polygon
    from shapely.ops import polygonize, unary_union
    lines = (doc.get("rail_cad") or {}).get(st.get("level")) or []
    if not lines:
        return None
    foot = Polygon([tuple(p[:2]) for p in st["corners"]]).buffer(0)
    inner = foot.buffer(0.05, join_style=2)
    segs = [LineString([tuple(a[:2]), tuple(b[:2])]) for a, b in lines
            if inner.contains(LineString([tuple(a[:2]), tuple(b[:2])]))]
    if len(segs) < 3:
        return None
    best = None
    for g in polygonize(unary_union([sg.buffer(0.001).exterior
                                     if False else sg for sg in segs])):
        if g.area < 0.3 or g.area > 0.6 * foot.area:
            continue
        if g.exterior.distance(foot.exterior) < 0.1:
            continue                     # a box at the hall's edge
        if best is None or g.area > best.area:
            best = g
    return best


def well_poly(st, doc=None):
    """The stair's well: as the plan draws it (its rail layer), else its
    hall less its flights and landings — the middle void (None when it has
    none, a straight flight)."""
    from shapely.geometry import Polygon
    from shapely.ops import unary_union
    if doc is not None:
        try:
            cw_ = cad_well(doc, st)
        except Exception:  # noqa: BLE001
            cw_ = None
        if cw_ is not None:
            return cw_
    foot = Polygon([tuple(p[:2]) for p in st["corners"]]).buffer(0)
    _f, lands = as_flights(st)
    solid = _flight_zones(st) + [
        Polygon([tuple(p[:2]) for p in l_["corners"]]).buffer(0)
        for l_ in lands if len(l_.get("corners") or []) >= 3]
    if not solid:
        return None
    rest = foot.difference(unary_union(solid).buffer(0.02, join_style=2))
    best = None
    for g in getattr(rest, "geoms", [rest]):
        if g.geom_type != "Polygon" or g.area < 0.2:
            continue
        if g.exterior.distance(foot.exterior) < 0.05 and \
                g.area < 0.25 * foot.area:
            continue                     # a sliver at the hall's wall
        if best is None or g.area > best.area:
            best = g
    if best is None:
        return None
    # between two flights running opposite ways (a U): the void only as far
    # as they both run — not on into the floor's landing past the shorter
    try:
        fl_, _l2 = as_flights(st)
        zs_ = _flight_zones(st, keep_none=True)
        pairs = []
        for i_, fa in enumerate(fl_):
            for j_, fb in enumerate(fl_):
                if j_ <= i_ or i_ >= len(zs_) or j_ >= len(zs_):
                    continue
                da, db = fa.get("d") or (0, 0), fb.get("d") or (0, 0)
                if da[0] * db[0] + da[1] * db[1] < -0.9 and \
                        zs_[i_] is not None and zs_[j_] is not None:
                    pairs.append((da, zs_[i_], zs_[j_]))
        if pairs:
            da, za, zb = pairs[0]
            nv = (-da[1], da[0])

            def ext(g, v):
                vs = [x * v[0] + y * v[1] for x, y in g.exterior.coords]
                return min(vs), max(vs)
            a0, a1 = ext(za, da)
            b0, b1 = ext(zb, da)
            lo, hi = max(a0, b0), min(a1, b1)
            n0 = min(ext(za, nv)[0], ext(zb, nv)[0])
            n1 = max(ext(za, nv)[1], ext(zb, nv)[1])
            if hi - lo > 0.3:
                def P(t, n):
                    return (da[0] * t + nv[0] * n, da[1] * t + nv[1] * n)
                box = Polygon([P(lo, n0), P(hi, n0), P(hi, n1), P(lo, n1)])
                cut = best.intersection(box)
                cand = max((g for g in getattr(cut, "geoms", [cut])
                            if g.geom_type == "Polygon"),
                           key=lambda g: g.area, default=None)
                if cand is not None and cand.area >= 0.2:
                    best = cand
    except Exception:  # noqa: BLE001
        pass
    best = best.minimum_rotated_rectangle \
        if best.area > 0.7 * best.minimum_rotated_rectangle.area else best
    return best


def _cad_guard(doc, st, ztop, kind, h, gap):
    """3.64.22: the railing the floor above's plan draws round this stair
    (its rail layer, inside the stair's hall), on that floor at the slab's
    edge — less the stair going on up's own (sloping) well railing."""
    from shapely.geometry import LineString, Polygon

    from .engine import railings as RL
    lines = (doc.get("rail_cad") or {}).get(st.get("to")) or []
    if not lines:
        return []
    foot = Polygon([tuple(p[:2]) for p in st["corners"]]).buffer(0)
    hall = foot.buffer(0.3, join_style=2)
    own = None
    up = _upper_stair(doc, st)
    if up is not None and up.get("id") not in _hidden_ids(doc):
        try:
            w2 = well_poly(up, doc)
            own = w2.buffer(0.15, join_style=2) if w2 is not None else None
        except Exception:  # noqa: BLE001
            own = None
    out, used = [], []
    for a, b in lines:
        a, b = tuple(a[:2]), tuple(b[:2])
        if any(min(math.dist(a, u0) + math.dist(b, u1),
                   math.dist(a, u1) + math.dist(b, u0)) < 0.3
               for u0, u1 in used):
            continue
        ln = LineString([a, b])
        if ln.length < 0.3 or not hall.contains(ln):
            continue
        if own is not None and own.contains(ln):
            continue              # the upper stair's well railing (its own)
        used.append((a, b))
        out.append((RL.faces([(a[0], a[1], ztop), (b[0], b[1], ztop)],
                             h, kind, gap=gap), None))
    return out


def _well_edges(doc, st, ztop, kind, h, gap):
    """[(faces, None)] of the guard at the floor above along the well's
    edges with no flight (of this stair, or of the stair going on up)
    beside them; None when no well is found."""
    from shapely.geometry import LineString
    from shapely.ops import unary_union

    from .engine import railings as RL
    well = well_poly(st, doc)
    if well is None:
        return []                 # no well in it: no railing round the hall
    zones = _flight_zones(st)
    up = _upper_stair(doc, st)
    if up is not None and up.get("id") not in _hidden_ids(doc):
        zones += _flight_zones(up)
    fz = unary_union(zones).buffer(0.2) if zones else None
    pts = list(well.exterior.coords)[:-1]
    out = []
    for a, b in zip(pts, pts[1:] + pts[:1]):
        seg = LineString([a, b])
        if seg.length < 0.3:
            continue
        if fz is not None:
            seg = seg.difference(fz)
        for g in getattr(seg, "geoms", [seg]):
            if g.geom_type != "LineString" or g.length < 0.3:
                continue
            c = list(g.coords)
            out.append((RL.faces([(c[0][0], c[0][1], ztop),
                                  (c[-1][0], c[-1][1], ztop)], h, kind,
                                 gap=gap), None))
    return out


def _well_guard(doc, st, z0, kind, h, gap) -> list:
    """[(faces, None)] — a railing round the stair's opening in the floor
    above: along each edge of the slab's hole over the stair, on the slab
    beside it, but where a wall stands and where the stair arrives (its
    last nosing) — each straight edge one piece."""
    from shapely.geometry import LineString, Polygon

    from .engine import railings as RL
    if not st.get("to"):
        return []
    arch = doc["arch"]
    ztop = z0 + int(st["risers"]) * float(st["rise"])
    foot = Polygon([tuple(p[:2]) for p in st["corners"]])
    holes = []
    for e in arch["structure"]:
        if e["type"] != "slab":
            continue
        from . import slabedges as SE
        if SE.floor_level_of({"arch": arch, "settings": doc["settings"]},
                             e) != st["to"]:
            continue
        for hl in e.get("holes") or []:
            try:
                hp = Polygon([tuple(p[:2]) for p in hl])
            except Exception:  # noqa: BLE001
                continue
            if not hp.is_valid:
                hp = hp.buffer(0)
            # 3.64.15: only the opening over this stair's hall (a long
            # hole running on past it — a level zone's gap, a ramp's well
            # joined to it — not railed along its whole length)
            if hp.area > 2.0 * foot.area:
                hp = hp.intersection(foot.buffer(0.6, join_style=2))
                hp = max((g_ for g_ in getattr(hp, "geoms", [hp])
                          if g_.geom_type == "Polygon"),
                         key=lambda g_: g_.area, default=None)
                if hp is None:
                    continue
            if hp.is_valid and hp.intersection(foot).area > 0.3 * min(
                    hp.area, foot.area):
                holes.append(_opened(hp, 0.30, foot) or hp)
    # 3.64.20: the railing at the stair's WELL (the void between its
    # flights, as the plan draws it) — on the floor above, along the well's
    # edges no flight runs beside (the floor's landing between the flight
    # arriving and the one going on up); nothing round the hall
    try:
        cg_ = _cad_guard(doc, st, ztop, kind, h, gap)
        if cg_:
            return cg_
    except Exception:  # noqa: BLE001
        from .host import log_error
        log_error("stairs._cad_guard")
    # (3.64.24: so where the stair goes on up from that floor, in the same
    # hall; at the last floor — nothing going on up — the opening the flights
    # come up through railed along its edges on the floor, but where the
    # stair arrives and where walls stand: the floor enclosed round it)
    try:                      # 3.64.24: the railing that floor's plan
        cs_ = cad_split(doc, st)   # draws by the stair, where it draws it
    except Exception:  # noqa: BLE001
        cs_ = None
    if cs_ is not None or not _slab_over(doc, st, foot):
        if not _slab_over(doc, st, foot):
            return []        # 3.64.25: no floor over it (an outside stair)
        out_ = []
        near_ = foot.buffer(0.35, join_style=2)
        for ln in cs_[2]:
            seg = ln.intersection(near_)
            for g in getattr(seg, "geoms", [seg]):
                if g.geom_type != "LineString" or g.length < 0.3:
                    continue
                c = list(g.coords)
                out_.append((RL.faces([(c[0][0], c[0][1], ztop),
                                       (c[-1][0], c[-1][1], ztop)], h, kind,
                                      gap=gap), None))
        return out_
    up_go = _upper_stair(doc, st)
    if up_go is not None and up_go.get("id") not in _hidden_ids(doc):
        try:
            wg_ = _well_edges(doc, st, ztop, kind, h, gap)
        except Exception:  # noqa: BLE001
            from .host import log_error
            log_error("stairs._well_edges")
            wg_ = None
        if wg_ is not None:
            return wg_
    if not holes:
        return []
    walls = _walls_of(doc, st["to"])
    flights, _l = as_flights(st)
    arr = None
    if flights and flights[-1]["lines"]:
        ln = flights[-1]["lines"][-1]
        arr = LineString([tuple(ln[0][:2]), tuple(ln[1][:2])])
    # the stair of the floor above starting at the edge of this opening:
    # its first tread left open (the way on up)
    starts = []
    for s2 in doc.get("stairs") or []:
        if s2.get("level") != st["to"] or s2 is st:
            continue
        try:
            f2, _l2 = as_flights(s2)
            if f2 and f2[0]["lines"]:
                ln = f2[0]["lines"][0]
                starts.append(LineString([tuple(ln[0][:2]),
                                          tuple(ln[1][:2])]))
        except Exception:  # noqa: BLE001
            continue
    # the stair railings' ends on this floor — the guard joined to them
    anchors = []
    try:
        rs = _runs(st, z0)
        last = max(r[0] for r in rs) if rs else -1
        anchors += [r[3][:2] for r in rs if r[0] == last]
    except Exception:  # noqa: BLE001
        pass
    for s2 in doc.get("stairs") or []:
        if s2.get("level") != st["to"] or s2 is st:
            continue
        try:
            anchors += [r[2][:2] for r in _runs(s2, 0.0) if r[0] == 0]
        except Exception:  # noqa: BLE001
            continue

    def _snap(c):
        # each end near a stair railing's end carried on, straight, to
        # where that railing stops (then the few cm across to it)
        a, b = tuple(c[0][:2]), tuple(c[-1][:2])
        L = math.dist(a, b)
        if L < 1e-6:
            return [a, b]
        u = ((b[0] - a[0]) / L, (b[1] - a[1]) / L)
        head, tail = [], []
        for k, end in ((0, a), (1, b)):
            best = None
            for an in anchors:
                s_ = (an[0] - a[0]) * u[0] + (an[1] - a[1]) * u[1]
                off = abs(-(an[0] - a[0]) * u[1] + (an[1] - a[1]) * u[0])
                near = -s_ if k == 0 else s_ - L
                if off < 0.15 and -0.05 < near < 0.6 and (
                        best is None or abs(near) < best[0]):
                    best = (abs(near), an, s_)
            if best is None:
                continue
            an, s_ = best[1], best[2]
            pj = (a[0] + u[0] * s_, a[1] + u[1] * s_)
            seq = [pj] + ([an] if math.dist(pj, an) > 1e-3 else [])
            if k == 0:
                head = seq[::-1]
            else:
                tail = seq
        if head:
            a = None
        if tail:
            b = None
        return head + [q for q in (a, b) if q is not None] + tail

    out = []
    for hp in holes:
        pts = list(hp.exterior.coords)[:-1]
        ccw = hp.exterior.is_ccw
        for a, b in zip(pts, pts[1:] + pts[:1]):
            L = math.dist(a, b)
            if L < 0.3:
                continue
            u = ((b[0] - a[0]) / L, (b[1] - a[1]) / L)
            out_n = (u[1], -u[0]) if ccw else (-u[1], u[0])  # onto the slab
            o_ = 0.04
            pa = (a[0] + out_n[0] * o_, a[1] + out_n[1] * o_)
            pb = (b[0] + out_n[0] * o_, b[1] + out_n[1] * o_)
            seg = LineString([pa, pb])
            if walls is not None:
                seg = seg.difference(walls.buffer(0.12))
            if arr is not None:
                seg = seg.difference(arr.buffer(0.35))
            for st_ln in starts:
                seg = seg.difference(st_ln.buffer(0.35))
            for g in getattr(seg, "geoms", [seg]):
                if g.geom_type != "LineString" or g.length < 0.3:
                    continue
                c = list(g.coords)
                c = _snap([c[0], c[-1]])
                out.append((RL.faces([(q[0], q[1], ztop) for q in c], h,
                                     kind, gap=gap), None))
    return out


def _runs(st, z0, off=0.05):
    """Each flight's two side lines over the nosings, ``off`` in from its
    edges: [(flight, is-left, (x, y, z) foot, (x, y, z) head)]."""
    flights, _landings = as_flights(st)
    rise = st["rise"]
    runs, count = [], 0
    for f in flights:
        lines = [((ln[0][0], ln[0][1]), (ln[1][0], ln[1][1]))
                 for ln in f["lines"]]
        m = len(lines)
        if m < 2:
            count += m
            continue
        a0, b0 = lines[0]
        d = tuple(f["d"])
        wv = math.dist(a0, b0) or float(f["w"])
        r = ((b0[0] - a0[0]) / wv, (b0[1] - a0[1]) / wv)
        ss = [((ln[0][0] + ln[1][0]) / 2 - (a0[0] + b0[0]) / 2) * d[0] +
              ((ln[0][1] + ln[1][1]) / 2 - (a0[1] + b0[1]) / 2) * d[1]
              for ln in lines]
        zb = z0 + count * rise
        o_ = min(max(float(off), 0.0), wv / 2 - 0.05)
        for tside in (o_, wv - o_):
            p_ = _at(a0, d, r, ss[0], tside)
            q_ = _at(a0, d, r, ss[m - 1], tside)
            runs.append((len(runs) // 2, tside < wv / 2,
                         (p_[0], p_[1], zb + rise), (q_[0], q_[1],
                                                     zb + m * rise)))
        count += m
    return runs


def _floor_of(parts):
    """floor(x, y) → the top of the tread / landing under a point (the
    stair's level faces looking up), or None off the stair."""
    from shapely.geometry import Point, Polygon
    tops = []
    for fs, _c in parts or []:
        for f in fs:
            lp = f["loop"] if isinstance(f, dict) else f
            if len(lp) < 3:
                continue
            zs = [q[2] for q in lp]
            if max(zs) - min(zs) > 1e-4:
                continue
            a = sum(p[0] * q[1] - q[0] * p[1]
                    for p, q in zip(lp, lp[1:] + lp[:1]))
            if a <= 0:                       # looking down: a soffit
                continue
            try:
                tops.append((Polygon([(q[0], q[1]) for q in lp]), zs[0]))
            except Exception:  # noqa: BLE001
                continue

    def floor(x, y):
        pt = Point(x, y)
        hit = [z for pg, z in tops if pg.buffer(0.01).contains(pt)]
        return max(hit) if hit else None
    return floor


def _walls_of(doc, lid):
    """The level's walls on plan (shapely, one union) — a flight's side
    along one needs no railing."""
    try:
        from shapely.ops import unary_union

        from . import slabedges as SE
        ws = [w for w in doc["arch"]["walls"] if w["level"] == lid
              and not w.get("rail")]
        ps = SE.wall_polys(ws)
        return unary_union(ps) if ps else None
    except Exception:  # noqa: BLE001
        return None


def build_rail(st, z0, rail, h=0.9, sides="inner", off=0.05, gap=0.0,
               ext=0.0, floor=None, walls=None) -> list:
    """[(faces, colour)] of the stair's railing alone: its type, height,
    sides (inner / outer / both / none), inset from the flight's edge,
    baluster spacing (0 = the type's) and run-on past the first and the
    last nosing."""
    if not rail or rail == "none" or sides == "none":
        return []
    runs = _runs(st, z0, off)
    out = railing(st, runs, rail, h, sides, gap, ext, off, floor, walls) \
        if runs else []
    # the pieces deleted by hand (right-click ▸ Delete on one): not made
    skip = {int(k) for k in st.get("rail_skip") or []
            if str(k).lstrip("-").isdigit()}
    return [(fs, c) if k not in skip else ([], c)
            for k, (fs, c) in enumerate(out)]

def _ccw(loop):
    a = 0.5 * sum(p[0] * q[1] - q[0] * p[1]
                  for p, q in zip(loop, loop[1:] + loop[:1]))
    return list(loop) if a >= 0 else list(reversed(loop))


# ---- terraces and balconies ----------------------------------------------------------------
def terrace(doc, lid, h=1.0, t=0.15) -> dict:
    """The roof of the floor below that this floor does not cover becomes
    its terrace: this level's slab grows over it, and a parapet runs on
    its open edges (not where this floor's walls stand)."""
    from shapely.geometry import LineString, Polygon
    from shapely.ops import unary_union

    from . import project as PJ
    from .engine import model as M
    from .engine import structure as S
    arch = doc["arch"]
    ids = [lv["id"] for lv in arch["levels"]]
    i = ids.index(lid)
    if i == 0:
        return {"why": "No floor below this one"}
    below = ids[i - 1]
    bw = [w for w in arch["walls"] if w["level"] == below]
    tw = [w for w in arch["walls"] if w["level"] == lid]
    if not bw or not tw:
        return {"why": "This floor and the one below need walls"}
    bo = S.inside_walls(bw, PJ._outer_loop)
    to = S.inside_walls(tw, PJ._outer_loop)
    if not bo or not to:
        return {"why": "No outline"}
    bp, tp = Polygon(bo), Polygon(to)
    region = bp.difference(tp.buffer(0.01, join_style=2))
    parts = [p for p in getattr(region, "geoms", [region])
             if p.geom_type == "Polygon" and p.area >= 1.0]
    if not parts:
        return {"why": "This floor covers the whole floor below — no terrace"}
    slabs = [e for e in arch["structure"]
             if e["type"] == "slab" and e["level"] == lid
             and not (e.get("zone") or e.get("user") or e.get("roof"))]
    if PJ.slab_on_top(doc):
        # the terrace stands on the slab over the floor below — nothing
        # more over it: this level's own slab (over this floor) kept off
        # the terrace
        open_u = unary_union(parts).buffer(0.005, join_style=2)
        for sl in slabs:
            poly = Polygon(sl["corners"]).buffer(0)
            if not poly.intersects(open_u):
                continue
            rest = poly.difference(open_u)
            g = max(getattr(rest, "geoms", [rest]), key=lambda q: q.area,
                    default=None)
            if g is None or g.is_empty or g.geom_type != "Polygon" or \
                    g.area < 1.0:
                continue
            sl["corners"] = [[round(x, 4), round(y, 4)]
                             for x, y in list(g.simplify(0.005)
                                              .exterior.coords)[:-1]]
            sl["holes"] = [h for h in sl.get("holes") or []
                           if g.contains(Polygon(h).buffer(-0.01))]
    else:
        # the slab of this level (at its floor): over both
        full = unary_union([bp, tp]).buffer(0.001, join_style=2)
        if full.geom_type != "Polygon":
            full = max(full.geoms, key=lambda g: g.area)
        holes = [h for s_ in slabs for h in s_.get("holes") or []]
        arch["structure"] = [e for e in arch["structure"] if e not in slabs]
        t_slab = float(slabs[0]["t"]) if slabs else 0.15
        rec = {"type": "slab", "level": lid,
               "corners": [[round(x, 4), round(y, 4)]
                           for x, y in list(full.exterior.coords)[:-1]],
               "holes": holes, "t": t_slab, "offset": 0.0,
               "shafts": [h for s_ in slabs for h in s_.get("shafts") or []]}
        if S.why_not(rec) is None:
            arch["structure"] += M.new_elements(arch["structure"], [rec])
    # the terrace made before on this level: its parapets go
    arch["walls"] = [w for w in arch["walls"] if not (
        w["level"] == lid and str(w.get("name", "")).startswith("Terrace"))]
    recs = parapet_runs(parts, tp, t, h, lid)
    made = M.new_walls(arch["walls"], recs)
    rk = doc["settings"].get("parapet_rail", "solid")
    for k, w in enumerate(made, 1):
        w["name"] = f"Terrace parapet {k}"
        if rk and rk != "solid":
            w["rail"] = rk
    arch["walls"] += made
    area = sum(p.area for p in parts)
    arch["rooms"] = [r for r in arch["rooms"]
                     if not (r["level"] == lid and r["name"] == "Terrace")]
    arch["rooms"] = M._rooms(arch["rooms"] + [{
        "id": "", "level": lid, "name": "Terrace",
        "x": parts[0].representative_point().x,
        "y": parts[0].representative_point().y}], set(ids))
    return {"area": area, "parapets": len(recs)}


def parapet_runs(parts, tp, t, h, lid) -> list:
    """The parapet walls round the terrace ``parts`` on their open edges:
    each run ONE chain of walls sharing their end points (so the corners
    close clean), set in by half its width from the slab's edge, and
    carried up to the face of this floor's walls where it meets them."""
    from shapely.geometry import LineString, Point
    from shapely.ops import linemerge
    out = []
    near = t / 2 + 0.03                       # the run along this floor
    edge = tp.buffer(near, join_style=2)
    for p in parts:
        inset = p.buffer(-t / 2, join_style=2)
        for g in getattr(inset, "geoms", [inset]):
            if g.geom_type != "Polygon" or g.area < 0.05:
                continue
            ring = LineString(list(g.exterior.simplify(0.01).coords))
            rest = ring.difference(edge)
            if rest.is_empty:
                continue
            if rest.geom_type == "MultiLineString":
                rest = linemerge(rest)
            for run in getattr(rest, "geoms", [rest]):
                if run.geom_type != "LineString" or run.length < 0.2:
                    continue
                pts = [tuple(q) for q in run.coords]
                closed = math.dist(pts[0], pts[-1]) < 1e-6
                if not closed:
                    # an end at this floor's walls: on to their face
                    for k, k2 in ((0, 1), (-1, -2)):
                        a_, b_ = pts[k], pts[k2]
                        if tp.distance(Point(a_)) > near + 0.05:
                            continue
                        L = math.dist(a_, b_) or 1.0
                        ux, uy = (a_[0] - b_[0]) / L, (a_[1] - b_[1]) / L
                        d = tp.exterior.distance(Point(a_)) + 0.01
                        pts[k] = (a_[0] + ux * d, a_[1] + uy * d)
                for a_, b_ in zip(pts, pts[1:]):
                    if math.dist(a_, b_) < 0.05:
                        continue
                    out.append({"kind": "line",
                                "a": [round(a_[0], 4), round(a_[1], 4)],
                                "b": [round(b_[0], 4), round(b_[1], 4)],
                                "t": t, "align": "centre", "side": 1,
                                "height": h, "base": 0.0, "level": lid})
    return out


def balcony(doc, wall_id, depth=1.2, width=0.0, pos=None, h=1.0, t=0.10,
            slab_t=0.15) -> dict:
    """A balcony out of a wall: a slab ``depth`` deep, ``width`` long
    (0 = the wall's length; ``pos`` its centre along the wall, else the
    middle), on the wall's outer side, with a railing round it."""
    from shapely.geometry import Point, Polygon

    from . import project as PJ
    from .engine import model as M
    from .engine import structure as S
    from .engine import walls as W
    arch = doc["arch"]
    w = next((x for x in arch["walls"] if x["id"] == wall_id), None)
    if w is None or w.get("kind", "line") != "line":
        return {"why": "Select a straight wall"}
    lid = w["level"]
    cl = W.centre(w)
    a, b = cl.at(0.0), cl.at(1.0)
    L = math.dist(a, b)
    u = ((b[0] - a[0]) / L, (b[1] - a[1]) / L)
    nrm = (-u[1], u[0])
    mine = [x for x in arch["walls"] if x["level"] == lid]
    out = S.inside_walls(mine, PJ._outer_loop)
    poly = Polygon(out) if out else None
    if next((lv["kind"] for lv in arch["levels"] if lv["id"] == lid),
            "floor") != "floor":
        return {"why": "a balcony hangs from an upper floor — select a wall "
                       "of Level 2 or above (its plan: Level list ▸ Plan)"}
    mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
    side_out = []
    for sgn in (1, -1):                     # just past each face
        q = (mid[0] + nrm[0] * sgn * (float(w["t"]) / 2 + 0.06),
             mid[1] + nrm[1] * sgn * (float(w["t"]) / 2 + 0.06))
        side_out.append(poly is None or not poly.buffer(-0.01).contains(
            Point(q)))
    if side_out == [False, False]:
        return {"why": "this wall has rooms on both sides — select an "
                       "outside wall"}
    if not side_out[0]:
        nrm = (-nrm[0], -nrm[1])
    width = L if width <= 0 else min(width, L + 2.0)
    c = L / 2 if pos is None else min(max(pos, 0.0), L)
    face = float(w["t"]) / 2                     # the wall's outer face
    s0, s1 = c - width / 2, c + width / 2
    p = lambda s, d: (a[0] + u[0] * s + nrm[0] * d,  # noqa: E731
                      a[1] + u[1] * s + nrm[1] * d)
    quad = [p(s0, face), p(s1, face), p(s1, face + depth), p(s0, face + depth)]
    rec = {"type": "slab", "level": lid,
           "corners": [[round(x, 4), round(y, 4)] for x, y in quad],
           "holes": [], "t": slab_t, "offset": 0.0}
    why = S.why_not(rec)
    if why:
        return {"why": why}
    arch["structure"] += M.new_elements(arch["structure"], [rec])
    rails = []
    d = depth - t / 2 + face
    for (sa, da), (sb, db) in (((s0 + t / 2, face), (s0 + t / 2, d)),
                               ((s0 + t / 2, d), (s1 - t / 2, d)),
                               ((s1 - t / 2, d), (s1 - t / 2, face))):
        A, B = p(sa, da), p(sb, db)
        rails.append({"kind": "line", "a": [round(A[0], 4), round(A[1], 4)],
                      "b": [round(B[0], 4), round(B[1], 4)], "t": t,
                      "align": "centre", "side": 1, "height": h,
                      "base": 0.0, "level": lid})
    made = M.new_walls(arch["walls"], rails)
    for k, w_ in enumerate(made, 1):
        w_["name"] = f"Balcony railing {k}"
        rk_ = doc["settings"].get("parapet_rail", "solid")
        if rk_ and rk_ != "solid":
            w_["rail"] = rk_
    arch["walls"] += made
    mid = p((s0 + s1) / 2, face + depth / 2)
    arch["rooms"] = M._rooms(arch["rooms"] + [{
        "id": "", "level": lid, "name": "Balcony", "x": mid[0], "y": mid[1]}],
        {lv["id"] for lv in arch["levels"]})
    return {"area": width * depth, "level": lid}


# ---- stairs traced from the plan's tread lines -------------------------------------------
def _unit(a, b):
    L = math.dist(a, b) or 1.0
    return ((b[0] - a[0]) / L, (b[1] - a[1]) / L)


def trace(segs, words=()):
    """Flights from the tread lines of a stair layer (model m):
    [[flight, …] per stair], a flight = {"lines": [(a, b)…] in climbing
    order (a on the left), "d": climbing direction, "w", "g"}. ``words``:
    [(x, y, text)] — UP marks a stair's foot, DN its head."""
    cand = []
    for (a, b) in segs:
        L = math.dist(a, b)
        if 0.5 <= L <= 2.6:
            ang = math.degrees(math.atan2(b[1] - a[1], b[0] - a[0])) % 180
            cand.append((round(ang) % 180, round(L / 0.05), a, b))
    groups = {}
    for ang, lk, a, b in cand:
        # (one flight's treads may be drawn a little longer or shorter —
        # the first ones run to the wall, the rest stop at the stringer:
        # grouped by direction, the lengths kept close in the runs below)
        groups.setdefault((ang, 0), []).append((a, b))
    flights = []
    split = []
    for (ang, lk), lines in groups.items():
        u = (math.cos(math.radians(ang)), math.sin(math.radians(ang)))
        n = (-u[1], u[0])
        # the same tread line drawn twice: once
        uniq = []
        for a, b in lines:
            m = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
            if not any(math.dist(m, q) < 0.01 for q, _l in uniq):
                uniq.append((m, (a, b)))
        # flights side by side (a U-stair's two arms: same length, same
        # direction) apart: by where they sit along the treads
        al = sorted(uniq, key=lambda t: t[0][0] * u[0] + t[0][1] * u[1])
        part = [al[0]]
        for t in al[1:]:
            pa = part[-1][0][0] * u[0] + part[-1][0][1] * u[1]
            if t[0][0] * u[0] + t[0][1] * u[1] - pa > 0.10:
                split.append((ang, lk, [l for _m, l in part]))
                part = []
            part.append(t)
        split.append((ang, lk, [l for _m, l in part]))
    for ang, _lk, lines in split:
        u = (math.cos(math.radians(ang)), math.sin(math.radians(ang)))
        n = (-u[1], u[0])
        rows = sorted(((((a[0] + b[0]) / 2) * n[0] + ((a[1] + b[1]) / 2) * n[1],
                        ((a[0] + b[0]) / 2) * u[0] + ((a[1] + b[1]) / 2) * u[1],
                        a, b) for a, b in lines))
        run = [rows[0]]
        for r in rows[1:] + [None]:
            ok = False
            if r is not None:
                s = r[0] - run[-1][0]
                prev = run[-1][0] - run[-2][0] if len(run) > 1 else s
                ok = 0.18 <= s <= 0.40 and abs(s - prev) < 0.04 and \
                    abs(r[1] - run[-1][1]) < 0.10 and \
                    abs(math.dist(r[2], r[3]) -
                        math.dist(run[-1][2], run[-1][3])) < 0.16
            if ok:
                run.append(r)
                continue
            if len(run) >= 2:
                gs = [run[k + 1][0] - run[k][0] for k in range(len(run) - 1)]
                ls = []
                for _o, _t, a, b in run:
                    if (b[0] - a[0]) * u[0] + (b[1] - a[1]) * u[1] < 0:
                        a, b = b, a
                    ls.append((tuple(a), tuple(b)))
                flights.append({"lines": ls, "d": n,
                                "w": math.dist(*ls[0]),
                                "g": sum(gs) / len(gs)})
            if r is not None:
                run = [r]
    # stairs: flights near each other
    # (every flight within 1.2 m of another one of the stair, whatever
    # order they come in: merged)
    boxes = [_fbox(f) for f in flights]
    root = list(range(len(flights)))

    def find(i):
        while root[i] != i:
            root[i] = root[root[i]]
            i = root[i]
        return i
    for i in range(len(flights)):
        for j in range(i + 1, len(flights)):
            if _boxdist(boxes[i], boxes[j]) < 1.2:
                root[find(i)] = find(j)
    by = {}
    for i, f in enumerate(flights):
        by.setdefault(find(i), []).append(f)
    return [_chain(st, words) for st in by.values()]


def _fbox(f):
    xs = [p[0] for ln in f["lines"] for p in ln]
    ys = [p[1] for ln in f["lines"] for p in ln]
    return min(xs), min(ys), max(xs), max(ys)


def _boxdist(a, b):
    dx = max(0.0, max(a[0], b[0]) - min(a[2], b[2]))
    dy = max(0.0, max(a[1], b[1]) - min(a[3], b[3]))
    return math.hypot(dx, dy)


def _mid(ln):
    return ((ln[0][0] + ln[1][0]) / 2, (ln[0][1] + ln[1][1]) / 2)


def _flip(f):
    lines = [(b, a) for a, b in reversed(f["lines"])]
    return dict(f, lines=lines, d=(-f["d"][0], -f["d"][1]))


def _chain(fl, words):
    """The flights in climbing order, each pointing up."""
    ups = [(x, y) for x, y, t in words if t.strip().upper() == "UP"]
    dns = [(x, y) for x, y, t in words if t.strip().upper() in ("DN", "DOWN")]

    def near(p, pts):
        return min((math.dist(p, q) for q in pts), default=1e9)
    # the foot: the flight end nearest an UP (else farthest from a DN)
    best = None
    for i, f in enumerate(fl):
        for end, ln in ((0, f["lines"][0]), (1, f["lines"][-1])):
            m = _mid(ln)
            score = near(m, ups) if ups else (-near(m, dns) if dns else
                                               (end, i))
            if best is None or score < best[0]:
                best = (score, i, end)
    _s, i, end = best
    first = fl[i] if end == 0 else _flip(fl[i])
    order = [first]
    rest = [f for k, f in enumerate(fl) if k != i]
    while rest:
        top = _mid(order[-1]["lines"][-1])
        k, e = min(((k, e) for k in range(len(rest)) for e in (0, 1)),
                   key=lambda ke: math.dist(top, _mid(
                       rest[ke[0]]["lines"][0 if ke[1] == 0 else -1])))
        f = rest.pop(k)
        order.append(f if e == 0 else _flip(f))
    # a flight marked DN (the one going down to the floor below, drawn
    # on this plan beside the up flights) is not part of this stair
    if dns and ups and len(order) > 1:
        def mid_of(f):
            return _mid(f["lines"][len(f["lines"]) // 2])
        keep = [order[0]]
        for f in order[1:]:
            m = mid_of(f)
            if near(m, dns) < near(m, ups) and near(m, dns) < 2.5:
                continue
            keep.append(f)
        order = keep
    for f in order:                    # every line: a on the climber's left
        d = f["d"]
        f["lines"] = [(a, b) if (b[0] - a[0]) * d[1] - (b[1] - a[1]) * d[0]
                      > 0 else (b, a) for a, b in f["lines"]]
    # marked DN only (no UP by it): the stair from the floor below, seen
    # going down on this plan — not a stair climbing from this floor
    mids = [_mid(ln) for f in fl for ln in f["lines"]]

    def by(pts):
        return [p for p in pts if mids and
                min(math.dist(p, m) for m in mids) < 3.0]
    if order and by(dns) and not by(ups):
        order[0]["_dn_only"] = True
    return order


def complete(flights, n_needed, room=None, n_min=None, blocked=None):
    """The flights drawn, and — when they hold fewer risers than the
    storey needs (a plan shows the lower flight only) — a half landing and
    a return flight beside the last one, on the side the stair room
    leaves free. Returns (flights, landings) with landings as
    {"corners", "after"} (risers climbed before it)."""
    from shapely.geometry import Polygon
    flights = [dict(f) for f in flights]
    landings = []
    count = 0
    for i, f in enumerate(flights[:-1]):
        count += len(f["lines"])
        nx = flights[i + 1]
        la, lb = f["lines"][-1]
        fa, fb = nx["lines"][0]
        d = f["d"]
        depth = f["w"] if d[0] * nx["d"][0] + d[1] * nx["d"][1] < -0.5 else 0.0
        pts = [la, lb, fa, fb]
        pts += [(p[0] + d[0] * depth, p[1] + d[1] * depth) for p in pts]
        # the landing: square to the flight it ends (its last tread line
        # and the next flight's first one, boxed along the flight) — the
        # corner square of an L, the full width of a U's half landing
        landings.append({"corners": _box_along(pts, d), "after": count})
    have = sum(len(f["lines"]) for f in flights)
    # the last flight carried straight on where the stair room leaves it
    # room (a plan cut before the top: the run continues, its last step
    # at the floor above — no landing made up to turn on)
    if n_needed > have and flights and (room is not None or
                                        blocked is not None):
        try:
            f = flights[-1]
            d, w, g = f["d"], float(f["w"]), float(f["g"])
            a, b = f["lines"][-1]
            from shapely.geometry import box as _bx
            others = [_bx(*_fbox(f_)).buffer(-0.02) for f_ in flights[:-1]
                      if len(f_["lines"]) > 1]
            rb_ = room.buffer(0.03) if room is not None else None

            def fits(j):            # j more risers and the top step past
                run = g * (j + 1)
                ext = Polygon([a, b, (b[0] + d[0] * run, b[1] + d[1] * run),
                               (a[0] + d[0] * run, a[1] + d[1] * run)]
                              ).buffer(0)
                if rb_ is not None and not rb_.contains(ext):
                    return False
                if blocked is not None and blocked.intersection(
                        ext).area > 0.002:
                    return False
                return not any(
                    o_.intersects(ext.buffer(-0.02)) for o_ in others)
            k = n_needed - have
            m = next((j for j in range(k, 0, -1) if fits(j)), 0)
            if m and have + m >= (n_min or n_needed):
                f["lines"] = list(f["lines"]) + [
                    ((a[0] + d[0] * g * j, a[1] + d[1] * g * j),
                     (b[0] + d[0] * g * j, b[1] + d[1] * g * j))
                    for j in range(1, m + 1)]
                f["_ext"] = True      # as drawn, carried on: not re-split
                have = n_needed
        except Exception:  # noqa: BLE001
            pass
    if n_needed > have and len(flights) >= 2 and abs(
            flights[-2]["d"][0] * flights[-1]["d"][0] +
            flights[-2]["d"][1] * flights[-1]["d"][1]) < 0.3:
        # an L drawn (the plan cut above it): the stair turns the same way
        # again — a corner landing past the last flight, then the third
        # flight on, as a three-flight U goes
        f, pf = flights[-1], flights[-2]
        d, w, g = f["d"], float(f["w"]), float(f["g"])
        turn = pf["d"][0] * d[1] - pf["d"][1] * d[0]
        nd = (-d[1], d[0]) if turn > 0 else (d[1], -d[0])
        a, b = f["lines"][-1]
        dw = (d[0] * w, d[1] * w)
        land = [a, b, (a[0] + dw[0], a[1] + dw[1]),
                (b[0] + dw[0], b[1] + dw[1])]
        landings.append({"corners": _box_along(land, d), "after": have})
        left = (-d[1], d[0])
        # the landing's side the new flight leaves from
        sa = (a[0] - b[0]) * left[0] + (a[1] - b[1]) * left[1]
        e0 = a if (sa > 0) == (turn > 0) else b
        e1 = (e0[0] + dw[0], e0[1] + dw[1])
        nl = (-nd[1], nd[0])
        if (e1[0] - e0[0]) * nl[0] + (e1[1] - e0[1]) * nl[1] < 0:
            e0, e1 = e1, e0
        k = n_needed - have
        lines = [((e0[0] + nd[0] * g * j, e0[1] + nd[1] * g * j),
                  (e1[0] + nd[0] * g * j, e1[1] + nd[1] * g * j))
                 for j in range(k)]
        flights.append({"lines": lines, "d": nd, "w": w, "g": g})
        have = n_needed
    if n_needed > have and flights:
        f = flights[-1]
        d, w, g = f["d"], f["w"], f["g"]
        a, b = f["lines"][-1]
        left = (-d[1], d[0])           # a is on the left of the climber
        best = None
        for side in (1, -1):
            off = (left[0] * side * (w + 0.10), left[1] * side * (w + 0.10))
            land = [a, b, (a[0] + off[0], a[1] + off[1]),
                    (b[0] + off[0], b[1] + off[1])]
            land += [(p[0] + d[0] * w, p[1] + d[1] * w) for p in land]
            c, u, lw, L = rect_of(land)
            box = corners_of(c, u, lw, L)
            score = Polygon(box).intersection(room).area if room is not None \
                else side
            if best is None or score > best[0]:
                best = (score, side, off, box)
        _s, side, off, box = best
        landings.append({"corners": box, "after": have})
        k = n_needed - have
        # the return flight: beside, coming back down the well
        a2 = (a[0] + off[0], a[1] + off[1])
        b2 = (b[0] + off[0], b[1] + off[1])
        back = (-d[0], -d[1])
        lines = []
        for j in range(k):
            s = g * j
            lines.append(((b2[0] + back[0] * s, b2[1] + back[1] * s),
                          (a2[0] + back[0] * s, a2[1] + back[1] * s)))
        flights.append({"lines": lines, "d": back, "w": w, "g": g})
    # the arrival: the stair's last step at the floor above — one tread
    # past its last riser (no landing: the floor above is there)
    if flights:
        f = flights[-1]
        d, w = f["d"], float(f.get("g", 0.28) or 0.28)
        la, lb = f["lines"][-1]
        pts = [la, lb, (la[0] + d[0] * w, la[1] + d[1] * w),
               (lb[0] + d[0] * w, lb[1] + d[1] * w)]
        landings.append({"corners": _box_along(pts, d),
                         "after": sum(len(x["lines"]) for x in flights),
                         "arrival": True})
    return flights, landings


def winders(flights, lands, diags, tol=0.2):
    """A turning landing the plan splits with a diagonal from corner to
    corner: two winder treads, one riser apart — the landing made two
    triangles (the first by the flight arriving, the second by the one
    leaving, a riser up) and a one-line «flight» on the diagonal between
    them (its riser), the landings and risers after it one higher."""
    from shapely.geometry import Point, Polygon
    out_f, out_l = list(flights), []
    shift = 0
    for lg in sorted(lands, key=lambda g: int(g.get("after", 0))):
        lg = dict(lg, after=int(lg.get("after", 0)) + shift)
        cs = [tuple(p[:2]) for p in lg.get("corners") or []]
        if lg.get("arrival") or len(cs) != 4:
            out_l.append(lg)
            continue
        hit = None
        for a, b in diags:
            ia = min(range(4), key=lambda i: math.dist(cs[i], a))
            ib = min(range(4), key=lambda i: math.dist(cs[i], b))
            if (ia - ib) % 4 == 2 and math.dist(cs[ia], a) < tol and \
                    math.dist(cs[ib], b) < tol:
                hit = (ia, ib)
                break
        if hit is None:
            out_l.append(lg)
            continue
        ia, ib = hit
        t1 = [cs[ia], cs[(ia + 1) % 4], cs[ib]]
        t2 = [cs[ib], cs[(ib + 1) % 4], cs[ia]]
        # the flight arriving here: its last riser on an edge of t1 or t2
        k_in, acc = None, 0
        for i, f in enumerate(out_f):
            acc += len(f["lines"])
            if acc == lg["after"]:
                k_in = i
                break
        if k_in is None:
            out_l.append(lg)
            continue
        m_in = Point(_mid(out_f[k_in]["lines"][-1]))
        if Polygon(t2).distance(m_in) < Polygon(t1).distance(m_in) - 1e-6:
            t1, t2 = t2, t1
        c1 = Polygon(t1).centroid
        c2 = Polygon(t2).centroid
        dd = _nrm((c2.x - c1.x, c2.y - c1.y))
        diag = [list(cs[ia]), list(cs[ib])]
        out_f.insert(k_in + 1, {"lines": [diag], "d": [dd[0], dd[1]],
                                "w": math.dist(cs[ia], cs[ib]),
                                "g": 0.0, "winder": True})
        out_l.append({"corners": [list(p) for p in t1], "after": lg["after"]})
        out_l.append({"corners": [list(p) for p in t2],
                      "after": lg["after"] + 1, "winder_line": diag,
                      "winder_d": [dd[0], dd[1]]})
        shift += 1
    return out_f, out_l


def real_flights(st) -> list:
    """The stair's flights without its winders' one-line «flights»."""
    flights, _l = as_flights(st)
    return [f for f in flights if not f.get("winder")]


def cut_at_foreign(flights, segs):
    """The flights of a traced stair up to the first turn whose landing
    the plan fills with other tread lines (the flight beyond belongs to
    another stair — the one going down to the basement drawn beside it)."""
    from shapely.geometry import Point, Polygon
    if len(flights) < 2:
        return flights
    mine = [((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
            for f in flights for a, b in f["lines"]]
    other = []
    for a, b in segs:
        L = math.dist(a, b)
        if not 0.5 <= L <= 2.6:
            continue
        m = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
        if any(math.dist(m, q) < 0.03 for q in mine):
            continue
        other.append(m)
    if not other:
        return flights
    for i, f in enumerate(flights[:-1]):
        nx = flights[i + 1]
        la, lb = f["lines"][-1]
        fa, fb = nx["lines"][0]
        d = f["d"]
        depth = f["w"] if d[0] * nx["d"][0] + d[1] * nx["d"][1] < -0.5 \
            else 0.0
        pts = [la, lb, fa, fb]
        pts += [(p[0] + d[0] * depth, p[1] + d[1] * depth) for p in pts]
        try:
            box = Polygon(_box_along(pts, d)).buffer(-0.08)
        except Exception:  # noqa: BLE001
            continue
        if box.is_empty:
            continue
        if sum(1 for m in other if box.contains(Point(m))) >= 2:
            return flights[:i + 1]
        # two flights side by side climbing the same way: not one stair
        if d[0] * nx["d"][0] + d[1] * nx["d"][1] > 0.5 and i > 0:
            return flights[:i + 1]
    return flights


def _box_along(pts, d):
    """The box round points, its sides along d and across it."""
    L = math.hypot(d[0], d[1]) or 1.0
    u = (d[0] / L, d[1] / L)
    v = (-u[1], u[0])
    su = [p[0] * u[0] + p[1] * u[1] for p in pts]
    sv = [p[0] * v[0] + p[1] * v[1] for p in pts]
    a0, a1, b0, b1 = min(su), max(su), min(sv), max(sv)

    def P(a, b):
        return [round(u[0] * a + v[0] * b, 4), round(u[1] * a + v[1] * b, 4)]
    return [P(a0, b0), P(a1, b0), P(a1, b1), P(a0, b1)]


def traced_steps(st, z0):
    """Blocks of a traced stair: between each two lines of a flight, and
    the landings, each from the floor up to its level."""
    rise = st["rise"]
    out = []
    count = 0
    for f in st["flights"]:
        lines = f["lines"]
        for j in range(len(lines) - 1):
            (a0, b0), (a1, b1) = lines[j], lines[j + 1]
            out.append((f"Step {count + j + 1}", [a0, b0, b1, a1], z0,
                        z0 + (count + j + 1) * rise))
        count += len(lines)
    for lg in st.get("landings") or []:
        out.append(("Landing", [tuple(p) for p in lg["corners"]], z0,
                    z0 + lg["after"] * rise))
    return out


def outline_of(st):
    """The stair's well: its flights and landings — not its arrival
    landing, which is the floor above's own slab."""
    pts = [p for f in st["flights"] for ln in f["lines"] for p in ln]
    pts += [tuple(p) for lg in st.get("landings") or []
            if not lg.get("arrival") for p in lg["corners"]]
    return corners_of(*rect_of(pts))


def terraces_all(doc, h=1.0, t=0.15) -> list:
    """A terrace on every floor that leaves part of the floor below open:
    [(level name, area)]."""
    out = []
    for lv in doc["arch"]["levels"]:
        if lv["kind"] != "floor" or lv["name"] == "Roof":
            continue
        r = terrace(doc, lv["id"], h, t)
        if not r.get("why"):
            out.append((lv["name"], r["area"]))
    return out


# ---- stair types: how a flight is made ----------------------------------------------------
TYPES = [("monolithic", "Monolithic RCC (waist slab)"),
         ("solid", "Solid / masonry (filled)"),
         ("open", "Open riser — steel / timber on stringers"),
         ("cantilever", "Cantilever (floating treads)")]
CONCRETE = (0.74, 0.73, 0.70, 1.0)
TIMBER = (0.62, 0.45, 0.30, 1.0)
STEEL = (0.25, 0.27, 0.30, 1.0)


def as_flights(st):
    """A standard (designed) stair in the traced form: flights of riser
    lines and landings."""
    if st.get("traced"):
        return st["flights"], st.get("landings") or []
    (cx, cy), u, w, L = rect_of(st["corners"])
    v = (-u[1], u[0])
    if st.get("flip"):
        v = (-v[0], -v[1])
    o = (cx - u[0] * L / 2 - v[0] * w / 2, cy - u[1] * L / 2 - v[1] * w / 2)

    def P(a, b):
        return [o[0] + u[0] * a + v[0] * b, o[1] + u[1] * a + v[1] * b]
    n, g = st["risers"], st["going"]
    if st["kind"] == "straight":
        start = max((L - (n - 1) * g) / 2, 0.0)
        lines = [[P(start + k * g, w), P(start + k * g, 0.0)] for k in range(n)]
        return [{"lines": lines, "d": list(u), "w": w, "g": g}], []
    dl = w / 2
    n1 = int(math.ceil(n / 2))
    n2 = n - n1
    # the first flight's last riser is the half landing's edge (the spare
    # length stays at its foot, on the floor)
    s1 = max(L - dl - (n1 - 1) * g, 0.0)
    f1 = [[P(s1 + k * g, w / 2 - 0.01), P(s1 + k * g, 0.0)]
          for k in range(n1)]
    f2 = [[P(L - dl - k * g, w / 2 + 0.01), P(L - dl - k * g, w)]
          for k in range(n2)]
    land = {"corners": [P(L - dl, 0), P(L, 0), P(L, w), P(L - dl, w)],
            "after": n1}
    return ([{"lines": f1, "d": list(u), "w": w / 2, "g": g},
             {"lines": f2, "d": [-u[0], -u[1]], "w": w / 2, "g": g}],
            [land])


def _prism(profile, o, d, r, t0, t1):
    """A solid from a profile [(s, z)] in the vertical plane along ``d``
    (from ``o``), run across ``r`` from t0 to t1: side faces and the
    faces round its edges."""
    def P(s, t, z):
        return (o[0] + d[0] * s + r[0] * t, o[1] + d[1] * s + r[1] * t, z)
    faces = [[P(s, t0, z) for s, z in profile],
             [P(s, t1, z) for s, z in reversed(profile)]]
    n = len(profile)
    for i in range(n):
        (s0, z0), (s1, z1) = profile[i], profile[(i + 1) % n]
        if abs(s0 - s1) < 1e-9 and abs(z0 - z1) < 1e-9:
            continue
        faces.append([P(s0, t0, z0), P(s0, t1, z0), P(s1, t1, z1),
                      P(s1, t0, z1)])
    # outward, however ``d``, ``r`` and the profile turn: the end face at
    # t0 must look away from the t1 end (else every face turned round)
    area = sum(profile[i][0] * profile[(i + 1) % n][1] -
               profile[(i + 1) % n][0] * profile[i][1] for i in range(n))
    look = (d[1] * r[0] - d[0] * r[1]) * area * (t1 - t0)
    if look > 0:
        faces = [list(reversed(f)) for f in faces]
    return faces


def _clean(profile):
    out = []
    for p in profile:
        if not out or abs(p[0] - out[-1][0]) > 1e-6 or \
                abs(p[1] - out[-1][1]) > 1e-6:
            out.append(p)
    if len(out) > 1 and abs(out[0][0] - out[-1][0]) < 1e-6 and \
            abs(out[0][1] - out[-1][1]) < 1e-6:
        out.pop()
    return out


FINISHES = [("marble", "White marble", (0.92, 0.91, 0.88)),
            ("granite", "Black granite", (0.22, 0.22, 0.23)),
            ("terrazzo", "Terrazzo", (0.84, 0.80, 0.74)),
            ("porcelain", "Porcelain tile (grey)", (0.72, 0.72, 0.70)),
            ("wood", "Timber", (0.62, 0.45, 0.30)),
            ("bare", "No finish (bare concrete)", None)]
NOSINGS = [("square", "Square (projecting)"),
           ("bullnose", "Bullnose (fully rounded)"),
           ("pencil", "Pencil round (small radius)"),
           ("chamfer", "Chamfered"),
           ("flush", "Flush (no projection)"),
           ("strip", "Square with anti-slip metal strip")]
STRIP = (0.70, 0.71, 0.73)


def fin_colour(key):
    return next((c for k, _l, c in FINISHES if k == key), None)


def _box(s0, s1, z0, z1):
    """A rectangle in the (s, z) plane, in the profiles' turning sense."""
    return [(s0, z0), (s0, z1), (s1, z1), (s1, z0)]


def _nose_profile(s_front, s_back, z_top, ft, kind):
    """A tread finish's section: its front edge shaped as the nosing."""
    zb = z_top - ft
    if kind == "bullnose" and ft > 0.004:
        r = ft / 2.0
        cx, cz = s_front + r, z_top - r
        arc = [(cx + r * math.cos(math.radians(a)),
                cz + r * math.sin(math.radians(a)))
               for a in range(270, 89, -20)]
        return arc + [(s_back, z_top), (s_back, zb)]
    if kind == "pencil" and ft > 0.004:
        rr = min(0.006, ft / 2.0)
        cx, cz = s_front + rr, z_top - rr
        arc = [(cx + rr * math.cos(math.radians(a)),
                cz + rr * math.sin(math.radians(a)))
               for a in range(180, 89, -15)]
        return [(s_front, zb)] + arc + [(s_back, z_top), (s_back, zb)]
    if kind == "chamfer":
        c = min(0.01, ft * 0.6)
        return [(s_front, zb), (s_front, z_top - c), (s_front + c, z_top),
                (s_back, z_top), (s_back, zb)]
    return _box(s_front, s_back, zb, z_top)


def build(st, z0, kind="monolithic", waist=0.15, nosing=0.025,
          tread_t=0.05, rail=None, rail_h=0.9, rail_sides="inner",
          rail_off=0.05, rail_gap=0.0, rail_ext=0.0, fin=None, fin_t=0.02,
          fin_rt=0.015, nose_type="square"):
    """[(faces, colour)] of a stair of the chosen type — with its railing
    (``rail``: a railings type; None / "none" = no railing). ``fin`` (a
    colour): a finish on the treads (``fin_t`` thick, its front edge the
    ``nose_type`` nosing, ``nosing`` past the riser), on the risers
    (``fin_rt``) and on the landings — the concrete set down / back by it,
    so the finished risers and goings stay as drawn."""
    from shapely.geometry import Polygon as _Pg
    has_fin = fin is not None and kind in ("monolithic", "solid")
    ft = max(float(fin_t), 0.0) if has_fin else 0.0
    rt = max(float(fin_rt), 0.0) if has_fin else 0.0
    nos_p = 0.0 if nose_type == "flush" else float(nosing)
    land_ext = {}                     # landing «after» → finish run-ons
    from .engine import walls as W
    flights, landings = as_flights(st)
    landings = [_last_step(lg, flights) if lg.get("arrival") else lg
                for lg in landings]
    rise = st["rise"]
    out = []
    count = 0
    runs = []                         # each flight's two side lines, sloped
    for f in flights:
        lines = [((ln[0][0], ln[0][1]), (ln[1][0], ln[1][1]))
                 for ln in f["lines"]]
        m = len(lines)
        if m < 2:
            count += m
            continue
        a0, b0 = lines[0]
        d = tuple(f["d"])
        o = a0
        wv = math.dist(a0, b0) or float(f["w"])
        r = ((b0[0] - a0[0]) / wv, (b0[1] - a0[1]) / wv)
        ss = [((ln[0][0] + ln[1][0]) / 2 - (a0[0] + b0[0]) / 2) * d[0] +
              ((ln[0][1] + ln[1][1]) / 2 - (a0[1] + b0[1]) / 2) * d[1]
              for ln in lines]
        g = (ss[-1] - ss[0]) / (m - 1) if m > 1 else float(f["g"])
        zb = z0 + count * rise
        zk = [zb + k * rise for k in range(m + 1)]
        # the railing's line: over the nosings, from the first to the top
        for tside in (0.05, wv - 0.05):
            p_ = _at(o, d, r, ss[0], tside)
            q_ = _at(o, d, r, ss[m - 1], tside)
            runs.append((len(runs) // 2, tside < wv / 2,
                         (p_[0], p_[1], zb + rise), (q_[0], q_[1], zk[m])))
        tan = rise / g if g > 1e-6 else 1.0
        cos = 1.0 / math.sqrt(1.0 + tan * tan)
        nos = nosing if kind in ("monolithic", "solid") else 0.0
        if has_fin:
            nos = 0.0                   # the finish makes the nosing
        ends_on_ = any(int(lg.get("after", -1)) == count + m
                       for lg in landings)
        if has_fin:
            for j in range(m):          # the risers' finish
                ztop = zk[j + 1] - ft if (j < m - 1 or ends_on_) \
                    else zk[j + 1]
                if rt > 0 and ztop > zk[j] + 1e-4:
                    out.append((_prism(_box(ss[j] - rt, ss[j], zk[j], ztop),
                                       o, d, r, 0.0, wv), fin))
            for k in range(1, m):       # the treads' finish, nosing front
                if ft <= 0:
                    break
                sf = ss[k - 1] - rt - nos_p
                out.append((_prism(_clean(_nose_profile(
                    sf, ss[k], zk[k], ft, nose_type)), o, d, r, 0.0, wv),
                    fin))
                if nose_type == "strip" and wv > 0.2:
                    out.append((_prism(_box(sf + 0.012, sf + 0.052, zk[k],
                                            zk[k] + 0.003), o, d, r, 0.05,
                                       wv - 0.05), STRIP))
            if ends_on_:                # the landing's finish over the
                s_l = ss[m - 1] - rt    # last riser (flush with its finish)
                q = [_at(o, d, r, s_l, 0),
                     _at(o, d, r, ss[m - 1] + 0.01, 0),
                     _at(o, d, r, ss[m - 1] + 0.01, wv),
                     _at(o, d, r, s_l, wv)]
                land_ext.setdefault(count + m, []).append(
                    [(p_[0], p_[1]) for p_ in q])
                # the landing's front edge: a step like the others — the
                # same nosing (and anti-slip strip) over the last riser
                sf = s_l - nos_p
                if ft > 0 and nos_p > 1e-4:
                    out.append((_prism(_clean(_nose_profile(
                        sf, s_l, zk[m], ft, nose_type)), o, d, r, 0.0, wv),
                        fin))
                if ft > 0 and nose_type == "strip" and wv > 0.2:
                    out.append((_prism(_box(sf + 0.012, sf + 0.052, zk[m],
                                            zk[m] + 0.003), o, d, r, 0.05,
                                       wv - 0.05), STRIP))
        if kind == "solid":
            for k in range(1, m):
                q = [_at(o, d, r, ss[k - 1] - nos, 0), _at(o, d, r, ss[k], 0),
                     _at(o, d, r, ss[k], wv), _at(o, d, r, ss[k - 1] - nos, wv)]
                out.append((W.solid({"outer": _ccw(q), "holes": []},
                                    zb, zk[k] - ft), CONCRETE))
        elif kind == "monolithic":
            prof = []

            def root(s):
                return zb + (s - ss[0]) * tan
            off = waist / cos
            T = waist                           # the landing's thickness
            if count and any(lg.get("winder_line") and
                             int(lg.get("after", -1)) == count
                             for lg in landings):
                T = waist + rise      # off winders: their one flat soffit
            if count == 0:                      # from the floor
                s_x = ss[0] + off / tan
                prof.append((ss[0], zb))
            else:                               # from a landing: the soffit
                s_x = None                      # kinks into the landing's
                s_k = ss[0] + max(off - T, 0.0) / tan
                if s_k > ss[0] + 1e-6:
                    prof.append((s_k, zb - T))
                prof.append((ss[0], zb - T))
                prof.append((ss[0], zb))
            for k in range(1, m):
                if has_fin:             # set down under the finish
                    prof += [(ss[k - 1], zk[k] - ft), (ss[k], zk[k] - ft)]
                    continue
                tn = min(0.03, rise / 3)
                prof += [(ss[k - 1], zk[k] - tn), (ss[k - 1] - nos, zk[k] - tn),
                         (ss[k - 1] - nos, zk[k]), (ss[k], zk[k])]
            ends_on = any(int(lg.get("after", -1)) == count + m
                          for lg in landings)
            if not ends_on:                     # no landing: the flight's
                prof.append((ss[m - 1], zk[m]))  # top runs on to the slab
            # into the landing (or the floor) above: the waist runs on
            # under it until its soffit meets the landing's — one clean
            # kink line, no step under the landing's edge
            s_e = ss[m - 1] + (zk[m] - T - (root(ss[m - 1]) - off)) / tan
            if ends_on:
                prof.append((ss[m - 1], zk[m] - T))
            else:
                prof.append((s_e, zk[m]))
            if s_e > ss[m - 1] + 1e-6:
                prof.append((s_e, zk[m] - T))
            if s_x is not None and s_x < s_e:
                prof.append((s_x, zb))
            out.append((_prism(_clean(prof), o, d, r, 0.0, wv), CONCRETE))
        else:                                   # open / cantilever treads
            sw = 0.05 if kind == "open" else 0.0
            for k in range(1, m):
                q = [_at(o, d, r, ss[k - 1] - nosing, sw),
                     _at(o, d, r, ss[k], sw),
                     _at(o, d, r, ss[k], wv - sw),
                     _at(o, d, r, ss[k - 1] - nosing, wv - sw)]
                out.append((W.solid({"outer": _ccw(q), "holes": []},
                                    zk[k] - tread_t, zk[k]), TIMBER))
            if kind == "open":                  # two steel stringers
                D = 0.25

                def top(s):
                    return zb + (s - ss[0]) * tan + rise + 0.05
                s0, s1 = ss[0] - nosing, ss[m - 1]
                prof = [(s0, top(s0)), (s1, top(s1)),
                        (s1, top(s1) - D / cos), (s0, top(s0) - D / cos)]
                if count == 0:
                    prof = [(x, max(z, zb)) for x, z in prof]
                for t0, t1 in ((0.0, sw), (wv - sw, wv)):
                    out.append((_prism(_clean(prof), o, d, r, t0, t1), STEEL))
        count += m
    if rail and rail != "none" and rail_sides != "none" and runs:
        out += build_rail(st, z0, rail, rail_h, rail_sides, rail_off,
                          rail_gap, rail_ext)
    for lg in landings:
        zl = z0 + lg["after"] * rise
        wl = lg.get("winder_line")
        if wl and kind in ("monolithic", "solid"):
            try:                         # the winder's riser and nosing
                a_w, b_w = tuple(wl[0][:2]), tuple(wl[1][:2])
                Lw = math.dist(a_w, b_w)
                rw = ((b_w[0] - a_w[0]) / Lw, (b_w[1] - a_w[1]) / Lw)
                dw = _nrm(lg.get("winder_d") or (-rw[1], rw[0]))
                if has_fin and rt > 0:
                    out.append((_prism(_box(-rt, 0.0, zl - rise, zl - ft),
                                       a_w, dw, rw, 0.0, Lw), fin))
                if has_fin and ft > 0 and nos_p > 1e-4:
                    out.append((_prism(_clean(_nose_profile(
                        -rt - nos_p, 0.0, zl, ft, nose_type)), a_w, dw, rw,
                        0.0, Lw), fin))
                if has_fin and ft > 0 and nose_type == "strip" and Lw > 0.2:
                    sf = -rt - nos_p
                    out.append((_prism(_box(sf + 0.012, sf + 0.052, zl,
                                            zl + 0.003), a_w, dw, rw, 0.05,
                                       Lw - 0.05), STRIP))
            except Exception:  # noqa: BLE001
                pass
        th = {"monolithic": waist, "solid": zl - z0, "open": 0.10,
              "cantilever": 0.15}[kind]
        if wl and kind == "monolithic":
            th = waist + rise         # the winders' soffit: one flat plane
        out.append((W.solid({"outer": _ccw([tuple(p) for p in lg["corners"]]),
                             "holes": []}, zl - max(th, 0.05), zl - ft),
                    CONCRETE if kind in ("monolithic", "solid") else TIMBER))
        if has_fin and ft > 0:          # the landing's finish
            try:
                from shapely.ops import unary_union as _uu
                pg = _Pg([tuple(p[:2]) for p in lg["corners"]]).buffer(0)
                ext = [_Pg(q).buffer(0) for q in
                       land_ext.get(int(lg.get("after", -1)), [])]
                u = _uu([pg] + ext).buffer(1e-4, join_style=2).buffer(
                    -1e-4, join_style=2)
                for g_ in getattr(u, "geoms", [u]):
                    if g_.geom_type == "Polygon" and g_.area > 1e-3:
                        out.append((W.solid({"outer": _ccw(list(
                            g_.exterior.coords)[:-1]), "holes": []},
                            zl - ft, zl), fin))
            except Exception:  # noqa: BLE001
                pass
    return out


def _last_step(lg, flights):
    """The arrival at the floor above as the stair's last step only: one
    going past the last riser (a stair made before 3.52 kept a landing
    there, as deep as the flight is wide)."""
    try:
        from shapely.geometry import Polygon as _Pg
        f = next(f_ for f_ in reversed(flights) if f_.get("lines"))
        d = f["d"]
        g = float(f.get("g", 0.28) or 0.28)
        la, lb = f["lines"][-1]
        s0 = la[0] * d[0] + la[1] * d[1]
        pg = _Pg([tuple(p[:2]) for p in lg["corners"]]).buffer(0)
        u = (-d[1], d[0])
        big = 50.0
        c = (la[0] + d[0] * 0.0, la[1] + d[1] * 0.0)
        strip = _Pg([(c[0] - u[0] * big, c[1] - u[1] * big),
                     (c[0] + u[0] * big, c[1] + u[1] * big),
                     (c[0] + u[0] * big + d[0] * g, c[1] + u[1] * big +
                      d[1] * g),
                     (c[0] - u[0] * big + d[0] * g, c[1] - u[1] * big +
                      d[1] * g)])
        _ = s0
        q = pg.intersection(strip)
        if q.is_empty or q.geom_type != "Polygon" or q.area < 0.01:
            return lg
        return dict(lg, corners=[list(p) for p in
                                 list(q.exterior.coords)[:-1]])
    except Exception:  # noqa: BLE001
        return lg


def _ext(path, ext, at_end):
    """The path run on ``ext`` past its first (or last) point, level."""
    if ext <= 0 or len(path) < 2:
        return path
    if at_end:
        p, q = path[-2], path[-1]
    else:
        p, q = path[1], path[0]
    L = math.hypot(q[0] - p[0], q[1] - p[1])
    if L < 1e-6:
        return path
    e = (q[0] + (q[0] - p[0]) / L * ext, q[1] + (q[1] - p[1]) / L * ext, q[2])
    return path + [e] if at_end else [e] + path


def railing(st, runs, kind, h=0.9, sides="inner", gap=0.0, ext=0.0,
            inset=0.05, floor=None, walls=None) -> list:
    """[(faces, colour)] of the stair's railing: on the inner side of its
    flights (the side by the well, joined across each landing), the outer
    (the wall side), or both. A single straight flight has no well: both
    sides, unless «inner» / «outer» picks one."""
    from .engine import railings as RL
    if sides == "none":
        return []
    nfl = max(r[0] for r in runs) + 1
    cs = st.get("corners") or []
    cx = sum(p[0] for p in cs) / len(cs) if cs else 0.0
    cy = sum(p[1] for p in cs) / len(cs) if cs else 0.0

    def far(r):
        mx, my = (r[2][0] + r[3][0]) / 2, (r[2][1] + r[3][1]) / 2
        return math.hypot(mx - cx, my - cy)
    both = sides == "both" or (nfl == 1 and sides not in ("outer",)
                               and not st.get("rail_sides"))
    out = []
    if both and nfl > 1:
        # both sides of a stair with landings: the well side joined across
        # each landing, and the wall side turning round the landings — the
        # landing's open edges railed too
        return railing(st, runs, kind, h, "inner", gap, ext, inset,
                       floor, walls) + \
            railing(st, runs, kind, h, "outer", gap, ext, inset, floor,
                    walls)
    if both:
        for i in range(nfl):
            for r in (r for r in runs if r[0] == i):
                path = [r[2], r[3]]
                if i == 0:
                    path = _ext(path, ext, False)
                if i == nfl - 1:
                    path = _ext(path, ext, True)
                out += _pieces(path, h, kind, gap, floor)
        return out
    picked = []
    want = _inner_sides(st)            # the well side of each flight, by
    hand = st.get("turns") is not None  # its turns (left / right of climb)
    for i in range(nfl):
        two = [r for r in runs if r[0] == i]
        w_ = want[i] if want and i < len(want) else None
        if nfl > 1 and w_ is not None and len(two) == 2 and not (
                walls is not None and not hand and _walled_one(
                    two, walls, inset)):
            inner = next((r for r in two if r[1] == w_), two[0])
            outer = next((r for r in two if r is not inner), two[-1])
            picked.append(outer if sides == "outer" else inner)
            continue
        if nfl == 1:                   # one flight: inner = its left side
            picked.append(next((r for r in two
                                if r[1] == (sides != "outer")), two[0]))
            continue
        # the inner side: the one towards the flights before and after
        # (the well of a dog-leg, the inside corner of an L) — not the one
        # nearest the stair's middle, which an L's long flight gets wrong
        nb = [_fmid(runs, j) for j in (i - 1, i + 1) if 0 <= j < nfl]
        tx = sum(q[0] for q in nb) / len(nb)
        ty = sum(q[1] for q in nb) / len(nb)

        def near(r, _t=(tx, ty)):
            mx, my = (r[2][0] + r[3][0]) / 2, (r[2][1] + r[3][1]) / 2
            return math.hypot(mx - _t[0], my - _t[1])
        # a side running along a wall needs no railing: the open side
        if walls is not None and len(two) == 2:
            from shapely.geometry import LineString
            walled = [walls.distance(LineString([r[2][:2], r[3][:2]]))
                      < inset + 0.15 for r in two]
            if walled[0] != walled[1]:
                op_ = two[1] if walled[0] else two[0]
                wl_ = two[0] if walled[0] else two[1]
                picked.append(wl_ if sides == "outer" else op_)
                continue
        picked.append(max(two, key=near) if sides == "outer"
                      else min(two, key=near))
    lands = [lg for lg in (as_flights(st)[1] or []) if not lg.get("arrival")]
    # one railing from the bottom to the top, across the landings (the
    # outer one turns round the landing's far corners)
    paths, path = [], []
    for r in picked:
        p, q = r[2], r[3]
        if path and math.hypot(p[0] - path[-1][0], p[1] - path[-1][1]) > \
                (3.0 if sides != "outer" else 8.0):
            paths.append(path)
            path = []
        if path:                      # across the landing, at its level
            last = path[-1]
            if sides == "outer" and lands:
                # round the landing: on along the last flight to its far
                # edge, across it, and back to the next flight
                pl = path[-2]
                L = math.hypot(last[0] - pl[0], last[1] - pl[1]) or 1.0
                u = ((last[0] - pl[0]) / L, (last[1] - pl[1]) / L)
                mid = ((last[0] + p[0]) / 2, (last[1] + p[1]) / 2)
                lg = min(lands, key=lambda g: min(
                    math.hypot(c[0] - mid[0], c[1] - mid[1])
                    for c in g["corners"]))
                k = max((c[0] - last[0]) * u[0] + (c[1] - last[1]) * u[1]
                        for c in lg["corners"]) - inset
                kp = (p[0] - last[0]) * u[0] + (p[1] - last[1]) * u[1]
                if k > 0.05:
                    path.append((last[0] + u[0] * k, last[1] + u[1] * k,
                                 last[2]))
                    if k - kp > 0.05:
                        path.append((p[0] + u[0] * (k - kp),
                                     p[1] + u[1] * (k - kp), last[2]))
            path.append((p[0], p[1], path[-1][2]))
        path += [p, q]
    if len(path) >= 2:
        paths.append(path)
    if paths:
        paths[0] = _ext(paths[0], ext, False)
        paths[-1] = _ext(paths[-1], ext, True)
    paths = [_smooth(pth) for pth in paths]
    out = []
    for pth in paths:
        if len(pth) >= 2:
            out += _pieces(pth, h, kind, gap, floor)
    return out


def _walled_one(two, walls, inset) -> bool:
    """One side of the flight runs along a wall, the other is open."""
    from shapely.geometry import LineString
    w = [walls.distance(LineString([r[2][:2], r[3][:2]])) < inset + 0.15
         for r in two]
    return w[0] != w[1]


def _inner_sides(st) -> list:
    """For each flight (of two risers or more, as ``_runs`` counts them):
    the «is-left» flag of ``_runs`` of its well side — the side it turns
    to at its landing (a left turn or U-turn left: its left), else the
    side the turn before it came from, else the flight before's side. None
    where a stair runs straight all the way."""
    flights, _l = as_flights(st)
    keep = [f for f in flights if len(f["lines"]) >= 2]
    if len(keep) < 2:
        return []
    turns = flight_turns({"traced": True, "flights": keep, "landings": []})

    def side(t):
        return "L" if t in ("left", "uleft") else \
            "R" if t in ("right", "uright") else None
    climb = []
    for i in range(len(keep)):
        s_ = side(turns[i]) if i < len(turns) else None
        if s_ is None and i > 0:
            s_ = side(turns[i - 1])
        climb.append(s_)
    for i in range(1, len(climb)):          # straight on: the side before
        if climb[i] is None:
            climb[i] = climb[i - 1]
    for i in range(len(climb) - 2, -1, -1):
        if climb[i] is None:
            climb[i] = climb[i + 1]
    if all(c is None for c in climb):        # straight all the way: one
        climb = ["L"] * len(climb)           # side, not crossing over
    out = []
    for f, s_ in zip(keep, climb):
        if s_ is None:
            out.append(None)
            continue
        (a, b) = f["lines"][0]
        d = _nrm(f["d"])
        lf = (-d[1], d[0])
        r = (b[0] - a[0], b[1] - a[1])
        a_left = (r[0] * lf[0] + r[1] * lf[1]) < 0   # going a→b goes right
        out.append(a_left if s_ == "L" else not a_left)
    return out


def _pieces(path, h, kind, gap, floor) -> list:
    """[(faces, None)] — the railing along ``path`` in straight pieces
    (each run between two turns, level or sloping, its own piece: one
    component in the model to edit or delete)."""
    from .engine import railings as RL
    pts = [tuple(p) for p in path]
    runs, cur = [], [pts[0]]
    for q in pts[1:]:
        if len(cur) >= 2:
            a, b = cur[-2], cur[-1]
            u = (b[0] - a[0], b[1] - a[1], b[2] - a[2])
            v = (q[0] - b[0], q[1] - b[1], q[2] - b[2])
            Lu = math.sqrt(sum(c * c for c in u)) or 1.0
            Lv = math.sqrt(sum(c * c for c in v)) or 1.0
            cos = sum(x * y for x, y in zip(u, v)) / (Lu * Lv)
            if cos < 0.999:                      # a turn: a new piece
                runs.append(cur)
                cur = [b]
        cur.append(q)
    runs.append(cur)
    out = []
    for r in runs:
        if len(r) >= 2 and math.hypot(r[-1][0] - r[0][0],
                                      r[-1][1] - r[0][1]) > 0.05:
            out.append((RL.faces([r[0], r[-1]], h, kind, gap=gap,
                                 floor=floor), None))
    return out


def _fmid(runs, i):
    """The middle of flight ``i`` on plan (between its two side runs)."""
    rs = [r for r in runs if r[0] == i]
    xs = [p[0] for r in rs for p in (r[2], r[3])]
    ys = [p[1] for r in rs for p in (r[2], r[3])]
    return (sum(xs) / len(xs), sum(ys) / len(ys))


def _smooth(path):
    """A railing path without its jumps: two points on the same spot (the
    landing's level, then the next flight's first nosing) made one — the
    rail runs on into the next flight instead of a step straight up;
    two inner lines meeting at an L landing turned at their corner."""
    out = []
    for p in path:
        if out and math.hypot(p[0] - out[-1][0], p[1] - out[-1][1]) < 0.01:
            out[-1] = (out[-1][0], out[-1][1], max(out[-1][2], p[2]))
            continue
        out.append(tuple(p))
    # an L: the two lines' corner, not a diagonal cut across it
    res = out[:1]
    for k in range(1, len(out)):
        a, b = res[-1], out[k]
        if k >= 2 and k + 1 < len(out):
            pa, nb = res[-2], out[k + 1]
            u = (a[0] - pa[0], a[1] - pa[1])
            v = (nb[0] - b[0], nb[1] - b[1])
            Lu, Lv = math.hypot(*u), math.hypot(*v)
            if Lu > 0.05 and Lv > 0.05:
                u = (u[0] / Lu, u[1] / Lu)
                v = (v[0] / Lv, v[1] / Lv)
                cr = u[0] * v[1] - u[1] * v[0]
                if abs(cr) > 0.7:                # square turn
                    t_ = ((b[0] - a[0]) * v[1] - (b[1] - a[1]) * v[0]) / cr
                    c = (a[0] + u[0] * t_, a[1] + u[1] * t_)
                    if 0 <= t_ <= 1.5 and math.hypot(c[0] - b[0],
                                                    c[1] - b[1]) < 1.5:
                        res.append((c[0], c[1], a[2]))
        res.append(b)
    fin = []
    for p in res:
        if fin and math.dist(p, fin[-1]) < 0.005:
            continue
        fin.append(p)
    return fin


def _at(o, d, r, s, t):
    return (o[0] + d[0] * s + r[0] * t, o[1] + d[1] * s + r[1] * t)


# ---- flights turned by hand: the landings follow ---------------------------------------
TURNS = [("straight", "Straight on"), ("left", "Turn left 90°"),
         ("right", "Turn right 90°"), ("uleft", "U-turn left (180°)"),
         ("uright", "U-turn right (180°)")]
U_GAP = 0.10                 # m between the two flights of a U


def _nrm(v):
    n = math.hypot(v[0], v[1]) or 1.0
    return (v[0] / n, v[1] / n)


def _frame(f):
    """A flight's first riser line as (a, r across, w width, d up, g)."""
    (a, b) = f["lines"][0]
    a, b = (float(a[0]), float(a[1])), (float(b[0]), float(b[1]))
    w = math.dist(a, b) or float(f.get("w") or 1.0)
    r = ((b[0] - a[0]) / w, (b[1] - a[1]) / w)
    d = _nrm(f["d"])
    return a, r, w, d, float(f.get("g") or GOING_MIN)


def _left_of(d):
    return (-d[1], d[0])


def flight_turns(st) -> list:
    """How each flight after the first leaves the landing before it:
    "straight", "left", "right", "uleft", "uright" (seen climbing)."""
    flights = real_flights(st)
    out = []
    for f0, f1 in zip(flights, flights[1:]):
        d0, d1 = _nrm(f0["d"]), _nrm(f1["d"])
        dot = d0[0] * d1[0] + d0[1] * d1[1]
        cr = d0[0] * d1[1] - d0[1] * d1[0]
        if dot > 0.7:
            out.append("straight")
        elif dot < -0.7:
            m0 = _mid(f0["lines"][-1])
            m1 = _mid(f1["lines"][0])
            lf = _left_of(d0)
            side = (m1[0] - m0[0]) * lf[0] + (m1[1] - m0[1]) * lf[1]
            out.append("uleft" if side > 0 else "uright")
        else:
            out.append("left" if cr > 0 else "right")
    return out


def relay(st, turns=None, rot=0.0, counts=None, gap=U_GAP) -> dict:
    """The stair laid again flight by flight: each flight keeps its width
    and tread, ``counts`` its risers, ``turns`` how it leaves the landing
    before it, the whole stair turned ``rot`` degrees round its foot (the
    first riser's middle). Every landing is made again to fit its turn —
    a square for a 90° turn, both flights' width for a U, a flight's width
    on a straight run — and the arrival landing past the last riser. The
    storey height stays (the riser height follows the risers' number)."""
    flights = real_flights(st)
    if not flights:
        return dict(st)
    turns0 = list(turns or flight_turns(st))
    if counts:                     # flights added (like the last) / dropped
        flights = list(flights[:len(counts)])
        while len(flights) < len(counts):
            flights.append(dict(flights[-1]))
    nf = len(flights)
    turns = turns0[:nf - 1]
    turns += ["right"] * (nf - 1 - len(turns))
    cnt = [len(f["lines"]) for f in flights]
    if counts and len(counts) == nf:
        cnt = [max(2, int(c)) for c in counts]
    a, r, w, d, g = _frame(flights[0])
    foot = (a[0] + r[0] * w / 2, a[1] + r[1] * w / 2)
    if rot:
        c, s = math.cos(math.radians(rot)), math.sin(math.radians(rot))

        def R(v):
            return (v[0] * c - v[1] * s, v[0] * s + v[1] * c)
        r, d = R(r), R(d)
        a = (foot[0] - r[0] * w / 2, foot[1] - r[1] * w / 2)

    def P(o, v, k):
        return (o[0] + v[0] * k, o[1] + v[1] * k)

    def L(p):
        return [round(p[0], 4), round(p[1], 4)]
    new_f, new_l = [], []
    climbed = 0
    for k in range(nf):
        m = cnt[k]
        lines = []
        for j in range(m):
            p = P(a, d, j * g)
            lines.append([L(p), L(P(p, r, w))])
        new_f.append({"lines": lines, "d": [round(d[0], 6), round(d[1], 6)],
                      "w": round(w, 4), "g": round(g, 4)})
        climbed += m
        A = P(a, d, (m - 1) * g)          # the last riser's a end
        if k == nf - 1:
            pts = [A, P(A, r, w), P(P(A, r, w), d, w), P(A, d, w)]
            new_l.append({"corners": [L(p) for p in pts],
                          "after": climbed, "arrival": True})
            break
        _a2, _r2, w2, _d2, g2 = _frame(flights[k + 1])
        t = turns[k]
        lf = _left_of(d)
        r_left = (r[0] * lf[0] + r[1] * lf[1]) > 0   # r points left
        if t in ("left", "right"):
            to_r = (t == "left") == r_left           # leaves on r's side
            pts = [A, P(A, r, w), P(P(A, r, w), d, w2), P(A, d, w2)]
            if to_r:
                na = P(P(A, r, w), d, w2)
                nr, nd = (-d[0], -d[1]), r
            else:
                na = A
                nr, nd = d, (-r[0], -r[1])
        elif t in ("uleft", "uright"):
            to_r = (t == "uleft") == r_left
            D = max(w, w2)
            if to_r:
                lo, hi = 0.0, w + gap + w2
                na = P(A, r, w + gap + w2)
            else:
                lo, hi = -(gap + w2), w
                na = P(A, r, -gap)
            nr, nd = (-r[0], -r[1]), (-d[0], -d[1])
            p0, p1 = P(A, r, lo), P(A, r, hi)
            pts = [p0, p1, P(p1, d, D), P(p0, d, D)]
        else:                                        # straight on
            D = max(w, 0.9)
            pts = [A, P(A, r, w), P(P(A, r, w), d, D), P(A, d, D)]
            na, nr, nd = P(A, d, D), r, d
            if abs(w2 - w) > 1e-3:                   # centred on the run
                na = P(na, r, (w - w2) / 2)
        new_l.append({"corners": [L(p) for p in pts], "after": climbed})
        a, r, w, d, g = na, nr, w2, nd, g2
    H = float(st.get("rise", RISER)) * int(st.get("risers", sum(
        len(f["lines"]) for f in flights)) or 1)
    n = sum(len(f["lines"]) for f in new_f)
    out = dict(st, traced=True, kind="traced", flights=new_f,
               landings=new_l, risers=n, rise=round(H / n, 4),
               going=new_f[0]["g"], turns=turns, rot=float(rot or 0.0),
               counts=[len(f["lines"]) for f in new_f])
    out.pop("flip", None)
    out["corners"] = outline_of(out)
    return out


def foot_of(st):
    """The middle of a stair's first riser line."""
    flights, _l = as_flights(st)
    if not flights:
        return None
    return _mid(flights[0]["lines"][0])


def stair_void(doc, st):
    """3.64.22: the room the stair takes through the floor above: its
    flights, its landings and its well (as the plan's railing draws it) —
    the floor above stops at their edge (its floor landing kept)."""
    from shapely.geometry import Polygon as _P
    from shapely.ops import unary_union
    _f, lands = as_flights(st)
    parts = list(_flight_zones(st))
    parts += [_P([tuple(p[:2]) for p in l_["corners"]]).buffer(0)
              for l_ in lands if len(l_.get("corners") or []) >= 3]
    w_ = well_poly(st, doc)
    if w_ is not None:
        parts.append(w_)
    if not parts:
        return None
    foot = _P([tuple(p[:2]) for p in st["corners"]]).buffer(0)
    u = unary_union(parts).buffer(0.06, join_style=2).buffer(
        -0.06, join_style=2).intersection(foot.buffer(0.02, join_style=2))
    best = max((g for g in getattr(u, "geoms", [u])
                if g.geom_type == "Polygon"), key=lambda g: g.area,
               default=None)
    return best


def _slab_over(doc, st, foot) -> bool:
    """Whether the floor above has a slab over the stair's hall at all."""
    from shapely.geometry import Polygon
    a = 0.0
    for e in doc["arch"]["structure"]:
        if e["type"] != "slab" or e.get("level") != st.get("to") or \
                e.get("roof") or e.get("top") or \
                len(e.get("corners") or []) < 3:
            continue
        try:
            g = Polygon([tuple(p[:2]) for p in e["corners"]]).buffer(0)
            a += g.intersection(foot.buffer(0.3, join_style=2)).area
        except Exception:  # noqa: BLE001
            continue
    return a >= 0.15 * foot.area


def cad_split(doc, st):
    """3.64.24: the stair's hall on the floor above split by the railing
    that floor's plan draws by it: (void, floor, rail lines) — the void
    the stair's high flights rise through (opened), the rest floor (the
    slab on up to the railing), the railing as drawn; None without one."""
    from shapely.geometry import LineString, Polygon
    from shapely.ops import split, unary_union
    up = st.get("to")
    lines = (doc.get("rail_cad") or {}).get(up) or []
    if not up or not lines or len(st.get("corners") or []) < 3:
        return None
    foot = Polygon([tuple(p[:2]) for p in st["corners"]]).buffer(0)
    near = foot.buffer(0.35, join_style=2)
    rails = []
    for a, b in lines:
        ln = LineString([tuple(a[:2]), tuple(b[:2])])
        ins = ln.intersection(near)
        if ins.length >= 0.5:
            rails.append(ln)
    if not rails:
        return None
    pieces = [foot.buffer(0.6, join_style=2)]   # (the floor on to its edge)
    for ln in rails:
        (x0, y0), (x1, y1) = ln.coords[0], ln.coords[-1]
        L = ln.length
        ux, uy = (x1 - x0) / L, (y1 - y0) / L
        ext = LineString([(x0 - ux * 1.0, y0 - uy * 1.0),
                          (x1 + ux * 1.0, y1 + uy * 1.0)])
        nxt = []
        for pc in pieces:
            try:
                nxt += [g for g in split(pc, ext).geoms
                        if g.geom_type == "Polygon" and g.area > 0.01]
            except Exception:  # noqa: BLE001
                nxt.append(pc)
        pieces = nxt
    # the flights high enough to want the floor above opened over them
    n = int(st.get("risers") or 0)
    rise = float(st.get("rise") or 0.17) or 0.17
    k0 = max(0, n - int(math.ceil(HEADROOM / rise)))
    fl, _l = as_flights(st)
    zones = _flight_zones(st, keep_none=True)
    high, k = [], 0
    for f, z in zip(fl, zones):
        k += len(f.get("lines") or [])
        if k > k0 and z is not None:
            high.append(z)
    if not high:
        return None
    hz = unary_union(high)
    void = [pc for pc in pieces
            if pc.intersection(hz).area > 0.15 * min(pc.area, hz.area)]
    floor = [pc for pc in pieces if pc not in void]
    if not void:
        return None
    vu = unary_union(void).intersection(foot)
    return vu, (unary_union(floor) if floor else None), rails


def apply_cad_split(doc, st) -> int:
    """The floor above's slab over the stair as its plan draws it: on up
    to the railing (the floor's side), opened on the stair's side."""
    from shapely.geometry import Polygon
    res = cad_split(doc, st)
    if res is None:
        return 0
    void, floor, _r = res
    arch = doc["arch"]
    n = 0
    for e in arch["structure"]:
        if e["type"] != "slab" or e.get("level") != st["to"] or \
                e.get("roof") or e.get("top") or e.get("zone") or \
                len(e.get("corners") or []) < 3:
            continue
        try:
            g = Polygon([tuple(p[:2]) for p in e["corners"]],
                        [[tuple(p[:2]) for p in h]
                         for h in e.get("holes") or [] if len(h) >= 3]
                        ).buffer(0)
        except Exception:  # noqa: BLE001
            continue
        if g.is_empty or g.distance(void) > 0.6:
            continue
        # 3.64.25: the floor's slab as it is (never stretched out over the
        # stair — an outside stair has none over it), opened on the stair's
        # side only
        g2 = g.difference(void)
        if g2.geom_type != "Polygon":
            parts = [x for x in getattr(g2, "geoms", []) if
                     x.geom_type == "Polygon"]
            if not parts:
                continue
            g2 = max(parts, key=lambda x: x.area)
        e["corners"] = [[round(x, 4), round(y, 4)]
                        for x, y in list(g2.exterior.coords)[:-1]]
        e["holes"] = [[[round(x, 4), round(y, 4)]
                       for x, y in list(i.coords)[:-1]]
                      for i in g2.interiors if Polygon(i).area > 0.05]
        n += 1
    return n


def upper_well(doc, st):
    """The hole the stair leaves in the floor above: where its flights,
    landings and well are (3.64.22) — the floor's own landing kept, the
    slab stopping at the stair's railing — or None."""
    if not st.get("to") or len(st.get("corners") or []) < 3:
        return None
    try:
        v = stair_void(doc, st)
    except Exception:  # noqa: BLE001
        v = None
    if v is None or v.area < 0.5:
        return None
    return [list(p) for p in list(v.exterior.coords)[:-1]]


def _upper_stair(doc, st):
    """The stair the floor above draws in ``st``'s hall, or None."""
    from shapely.geometry import Polygon as _P
    if not st.get("to") or len(st.get("corners") or []) < 3:
        return None
    foot = _P([tuple(p[:2]) for p in st["corners"]]).buffer(0)
    for o_ in doc.get("stairs") or []:
        if o_ is st or o_.get("level") != st.get("to") or \
                len(o_.get("corners") or []) < 3:
            continue
        op = _P([tuple(p[:2]) for p in o_["corners"]]).buffer(0)
        if op.intersection(foot).area >= 0.5 * min(op.area, foot.area):
            return o_
    return None


def _hidden_ids(doc) -> set:
    try:
        from . import project as PJ
        return PJ.stairs_hidden(doc)
    except Exception:  # noqa: BLE001
        return set()


def well_of(doc, st):
    """The well a stair cuts (as the import cuts it)."""
    stt = doc.get("settings") or {}
    H = float(st.get("rise", RISER)) * int(st.get("risers", 18))
    well = st["corners"]
    # 3.64.11: the floor above draws the stair well (an outline on its
    # stair layer over this stair): that well, as the plan has it
    try:
        from shapely.geometry import Polygon as _P
        foot = _P([tuple(p[:2]) for p in st["corners"]]).buffer(0)
        for w_ in (doc.get("stair_cad") or {}).get(st.get("to")) or []:
            wp = _P([tuple(p[:2]) for p in w_]).buffer(0)
            if wp.is_valid and wp.intersection(foot).area >= \
                    0.5 * min(wp.area, foot.area):
                return [list(p[:2]) for p in w_]
        up_ = upper_well(doc, st)
        if up_:
            return up_
    except Exception:  # noqa: BLE001
        pass
    wm = stt.get("stair_well", "railing")
    if wm != "outline" and stt.get("stair_headroom_cut", True):
        hc = headroom_cut(st, H, float(stt.get("slab_t", 0.15)),
                          float(stt.get("stair_head", HEADROOM)), wm)
        if hc:
            well = hc
    return well


def recut(doc, old, new) -> int:
    """The well of stair ``old`` closed, ``new``'s cut instead."""
    from shapely.geometry import Polygon

    from . import project as PJ
    arch = doc["arch"]
    o = Polygon(old.get("corners") or [])
    if o.is_valid and o.area > 0:
        for s in arch["structure"]:
            if s["type"] != "slab":
                continue
            keep = []
            for h in s.get("holes") or []:
                hp = Polygon(h)
                if hp.is_valid and hp.area >= 0.5 and \
                        hp.intersection(o).area >= 0.9 * hp.area:
                    continue
                keep.append(h)
            s["holes"] = keep
    well = well_of(doc, new)
    if PJ.slab_on_top(doc):
        return _cut(arch, new["level"], well)
    if new.get("to"):
        return _cut(arch, new["to"], well)
    return 0
