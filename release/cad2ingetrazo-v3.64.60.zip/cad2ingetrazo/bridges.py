# SPDX-License-Identifier: GPL-3.0-or-later
"""Doors and windows the walls alone do not hold.

A plan often draws a door between the ends of two walls that run across
it (a lobby's fins, a row of piers), or a window's glazing from pier to
pier with no wall line along it: the wall there is only implied. Here
every door swing (an arc on the door layers, its leaf from the hinge) and
every window band (glazing lines side by side on the window layers) is
looked for in the walls found; one no wall holds gets a short wall of its
own, exactly as wide as the door / window, holding it. A wall that holds
the symbol but no opening there gets the opening.

The piers drawn as closed boxes on the wall layers (too square to be a
wall) become solid piers (columns), so the bands between them stand
between solids.
"""
from __future__ import annotations

import math

ANG = 4.0             # ° parallel
DOOR_R = (0.45, 1.35)  # m, a leaf's width
WIN_MIN = 0.35        # m, a window band's least length
BAND_MAX = 0.45       # m, a window band's most depth across


def _u(a, b):
    L = math.dist(a, b)
    return ((b[0] - a[0]) / L, (b[1] - a[1]) / L) if L > 1e-9 else (1.0, 0.0)


def _ang(u):
    return math.degrees(math.atan2(u[1], u[0])) % 180.0


def _adiff(a, b):
    d = abs(a - b) % 180.0
    return min(d, 180.0 - d)


# ---- the symbols ------------------------------------------------------------------
def door_symbols(pl, is_door) -> list:
    """[(jamb A, jamb B, leaves)] — each door the swings show: a single
    leaf from its hinge (A) to the closed leaf's end (B); a pair of leaves
    meeting in the middle from hinge to hinge."""
    arcs = [a for a in pl.get("arcs") or () if is_door(a["layer"])
            and DOOR_R[0] <= a["r"] <= DOOR_R[1]]
    lay = pl["layers"]
    leaves = [((s[0], s[1]), (s[2], s[3])) for s in pl["segs"]
              if is_door(lay[s[4]])]
    one = []
    for a in arcs:
        c, r = tuple(a["c"]), a["r"]
        e0, e1 = tuple(a["p0"]), tuple(a["p1"])
        sweep = math.degrees(math.acos(max(-1.0, min(1.0, (
            (e0[0] - c[0]) * (e1[0] - c[0]) + (e0[1] - c[1]) * (e1[1] - c[1]))
            / (r * r)))))
        if not 55.0 <= sweep <= 120.0:
            continue
        # the open leaf: a line from the hinge to one end of the swing; the
        # door's other jamb: the other end (where the closed leaf lies)

        def leaf_at(e):
            for p, q in leaves:
                for x, y in ((p, q), (q, p)):
                    if math.dist(x, c) < 0.06 + 0.05 * r and \
                            math.dist(y, e) < 0.12 + 0.1 * r:
                        return True
            return False
        l0, l1 = leaf_at(e0), leaf_at(e1)
        if l0 and not l1:
            closed = e1
        elif l1 and not l0:
            closed = e0
        else:
            closed = None              # decided by its pair / the walls
        one.append({"c": c, "r": r, "e": (e0, e1), "closed": closed})
    out, used = [], set()
    # pairs: two swings whose closed ends meet (a double door)
    for i, a in enumerate(one):
        if i in used:
            continue
        best = None
        for j, b in enumerate(one):
            if j <= i or j in used or abs(a["r"] - b["r"]) > 0.25 * a["r"]:
                continue
            for ea in a["e"]:
                for eb in b["e"]:
                    d = math.dist(ea, eb)
                    span = math.dist(a["c"], b["c"])
                    if d < 0.12 and abs(span - a["r"] - b["r"]) < 0.15:
                        if best is None or d < best[0]:
                            best = (d, j)
        if best is not None:
            j = best[1]
            used |= {i, j}
            out.append((a["c"], one[j]["c"], 2))
    for i, a in enumerate(one):
        if i in used:
            continue
        cl = a["closed"]
        if cl is None:
            continue
        out.append((a["c"], cl, 1))
    return out


def window_bands(pl, is_win, is_line=None) -> list:
    """[(p, q, depth)] — glazing drawn as lines side by side: the band's
    centre line from end to end and its depth across — with the «line»
    layer's lines lying along it, right beside it (a CNC grille set in the
    same opening: the wall is that much thicker)."""
    lay = pl["layers"]
    ls = []
    for s in pl["segs"]:
        if not is_win(lay[s[4]]):
            continue
        a, b = (s[0], s[1]), (s[2], s[3])
        if math.dist(a, b) < 0.25:
            continue
        ls.append((a, b))
    n = len(ls)
    par = list(range(n))

    def root(k):
        while par[k] != k:
            par[k] = par[par[k]]
            k = par[k]
        return k
    info = []
    for a, b in ls:
        u = _u(a, b)
        if u[0] < -1e-9 or (abs(u[0]) < 1e-9 and u[1] < 0):
            u = (-u[0], -u[1])
        nv = (-u[1], u[0])
        info.append((u, nv, _ang(u)))
    # cells to keep it quick on big plans
    cells: dict = {}
    for i, (a, b) in enumerate(ls):
        m = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
        cells.setdefault((int(m[0] // 3), int(m[1] // 3)), []).append(i)
    for i, (a, b) in enumerate(ls):
        m = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
        cx, cy = int(m[0] // 3), int(m[1] // 3)
        u, nv, ag = info[i]
        s0 = sorted((a[0] * u[0] + a[1] * u[1], b[0] * u[0] + b[1] * u[1]))
        o = m[0] * nv[0] + m[1] * nv[1]
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for j in cells.get((cx + dx, cy + dy), ()):
                    if j <= i or _adiff(info[j][2], ag) > ANG:
                        continue
                    c, d = ls[j]
                    mj = ((c[0] + d[0]) / 2, (c[1] + d[1]) / 2)
                    if abs(mj[0] * nv[0] + mj[1] * nv[1] - o) > BAND_MAX:
                        continue
                    s1 = sorted((c[0] * u[0] + c[1] * u[1],
                                 d[0] * u[0] + d[1] * u[1]))
                    ov = min(s0[1], s1[1]) - max(s0[0], s1[0])
                    if ov >= 0.5 * min(s0[1] - s0[0], s1[1] - s1[0]):
                        par[root(j)] = root(i)
    groups: dict = {}
    for i in range(n):
        groups.setdefault(root(i), []).append(i)
    out = []
    for g in groups.values():
        if len(g) < 2:
            continue
        u, nv, _a = info[g[0]]
        offs, ss = [], []
        for i in g:
            a, b = ls[i]
            offs += [a[0] * nv[0] + a[1] * nv[1], b[0] * nv[0] + b[1] * nv[1]]
            ss += [a[0] * u[0] + a[1] * u[1], b[0] * u[0] + b[1] * u[1]]
        # the band's length: the span most of its lines share (a frame's
        # short returns do not lengthen it)
        lo, hi = min(ss), max(ss)
        if hi - lo < WIN_MIN:
            continue
        if is_line is not None:              # a grille beside the glass
            o0, o1 = min(offs), max(offs)
            for s_ in pl["segs"]:
                if not is_line(lay[s_[4]]):
                    continue
                a, b = (s_[0], s_[1]), (s_[2], s_[3])
                if math.dist(a, b) < 0.3 or _adiff(_ang(_u(a, b)),
                                                   _a) > ANG:
                    continue
                sa = sorted((a[0] * u[0] + a[1] * u[1],
                             b[0] * u[0] + b[1] * u[1]))
                if min(sa[1], hi) - max(sa[0], lo) < 0.6 * min(
                        sa[1] - sa[0], hi - lo):
                    continue
                for x in (a, b):
                    ox = x[0] * nv[0] + x[1] * nv[1]
                    if o0 - 0.2 <= ox <= o1 + 0.2:
                        offs.append(ox)
        o = (min(offs) + max(offs)) / 2
        depth = max(offs) - min(offs)
        if depth < 0.04 or hi - lo > 6.0:
            continue
        p = (u[0] * lo + nv[0] * o, u[1] * lo + nv[1] * o)
        q = (u[0] * hi + nv[0] * o, u[1] * hi + nv[1] * o)
        out.append((p, q, depth))
    return out


def piers(pl, is_wall, walls) -> list:
    """[shapely polygon] — closed boxes on the wall layers (0.15–2.5 m²,
    no longer than twice their width) that no wall found covers."""
    from shapely.geometry import LineString, Polygon
    from shapely.ops import polygonize, unary_union
    lay = pl["layers"]
    segs = [LineString([(s[0], s[1]), (s[2], s[3])]) for s in pl["segs"]
            if is_wall(lay[s[4]])]
    if not segs:
        return []
    polys = list(polygonize(unary_union(segs)))
    polys += [Polygon(lp["pts"]).buffer(0) for lp in pl.get("loops") or ()
              if is_wall(lp["layer"]) and len(lp["pts"]) >= 3]
    wp = []
    for w in walls:
        try:
            wp.append(LineString([w["a"], w["b"]]).buffer(
                float(w["t"]) / 2, cap_style=2))
        except Exception:  # noqa: BLE001
            continue
    W_ = unary_union(wp) if wp else Polygon()
    out = []
    for p in polys:
        if not p.is_valid or p.is_empty:
            continue
        a = p.area
        if not 0.15 <= a <= 2.5:
            continue
        r = p.minimum_rotated_rectangle
        cs = list(r.exterior.coords)
        s1, s2 = math.dist(cs[0], cs[1]), math.dist(cs[1], cs[2])
        if min(s1, s2) < 0.25 or max(s1, s2) > 2.0 * min(s1, s2):
            continue
        if p.area < 0.75 * r.area:
            continue
        if not W_.is_empty and p.intersection(W_).area > 0.4 * a:
            continue
        if any(p.buffer(0.02).contains(q.centroid) and q.area > a
               for q in out):
            continue
        out = [q for q in out if not p.contains(q.centroid)] + [p]
    return out


# ---- placing them -----------------------------------------------------------------
def _host(walls, p, q, depth=0.0):
    """(wall, pos of the middle, along-width) of the wall that holds the
    segment p–q in its band, else None."""
    u = _u(p, q)
    ag = _ang(u)
    m = ((p[0] + q[0]) / 2, (p[1] + q[1]) / 2)
    L = math.dist(p, q)
    best = None
    for w in walls:
        a, b = w["a"], w["b"]
        Lw = math.dist(a, b)
        if Lw < 1e-6:
            continue
        uw = _u(a, b)
        if _adiff(_ang(uw), ag) > ANG * 2:
            continue
        t = float(w["t"])
        nw = (-uw[1], uw[0])
        off = abs((m[0] - a[0]) * nw[0] + (m[1] - a[1]) * nw[1])
        if off > t / 2 + 0.06 + depth / 2:
            continue
        pos = (m[0] - a[0]) * uw[0] + (m[1] - a[1]) * uw[1]
        if not 0.0 <= pos <= Lw:
            continue
        if best is None or off < best[0]:
            best = (off, w, pos)
    if best is None:
        return None
    return best[1], best[2], L


def _covered(openings, wall, pos, w):
    """The opening of ``wall`` already over pos ± w/2, else None."""
    for o in openings:
        if o["wall"] != wall["id"]:
            continue
        if abs(float(o["pos"]) - pos) < (float(o["w"]) + w) / 2 - 0.05:
            return o
    return None


def _near_t(walls, pts, default):
    """The thickness of the wall nearest the points (a door's jambs end
    on the walls round it), else ``default``."""
    best = None
    for w in walls:
        a, b = w["a"], w["b"]
        Lw = math.dist(a, b)
        if Lw < 1e-6:
            continue
        uw = _u(a, b)
        for p in pts:
            s = (p[0] - a[0]) * uw[0] + (p[1] - a[1]) * uw[1]
            s = max(0.0, min(Lw, s))
            x = (a[0] + uw[0] * s, a[1] + uw[1] * s)
            d = math.dist(x, p) - float(w["t"]) / 2
            if best is None or d < best[0]:
                best = (d, float(w["t"]))
    if best is not None and best[0] < 0.35:
        return min(max(best[1], 0.10), 0.35)
    return default


def bridge(arch, lid, pl, is_door, is_win, is_wall, st,
           is_line=None, is_col=None) -> dict:
    """The doors / windows / piers no wall holds placed (see the module):
    walls, openings and piers added to ``arch``; how many of each."""
    from .engine import model as M
    walls = [w for w in arch["walls"] if w["level"] == lid
             and not w.get("rail")]
    ops = [o for o in arch["openings"]]
    rep = {"doors": 0, "windows": 0, "bridges": 0, "piers": 0}
    new_w, new_o = [], []

    def add(p, q, kind, t, leaves=1):
        L = math.dist(p, q)
        if L < 0.3:
            return
        h = _host(walls + new_w, p, q, t)
        if h is not None and kind == "window":
            # glazing over a wall the plan draws whole (no gap): a glass
            # railing on it, a window shown above — not an opening here;
            # but glazing deeper than the wall (a thin sill / jamb line
            # drawn through the window's frame): the window, the wall as
            # thick as its frame
            hit = _covered(ops + new_o, h[0], h[1], h[2])
            deeper = t > float(h[0]["t"]) + 0.03
            if hit is None and deeper:
                h[0]["t"] = round(min(t, 0.46) * 200) / 200
            elif hit is None and 0.3 <= L <= 1.0 and \
                    st.get("vents_over_walls", True):
                # 3.64.40: a small window drawn over a wall the plan
                # draws whole (a bath's / kitchen's ventilator): a high
                # window there
                w_, pos_, wd_ = h
                Lw_ = math.dist(w_["a"], w_["b"])
                wd_ = min(wd_, Lw_ - 0.1)
                if wd_ >= 0.3:
                    pos_ = min(max(pos_, wd_ / 2 + 0.05), Lw_ - wd_ / 2 -
                               0.05)
                    o_ = _op("window", w_["id"], pos_, wd_, 1, st)
                    hv_ = float(st.get("vent_h", 0.4572))
                    o_.update(h=hv_, sill=max(float(st.get(
                        "vent_head", 2.1336)) - hv_, 0.6), vent=True)
                    new_o.append(o_)
                    rep["vents"] = rep.get("vents", 0) + 1
                return
            elif hit is None or hit.get("kind") != "void" or hit.get("hl"):
                return
        if h is None and kind == "window":
            # an implied wall: only between two solids (walls, piers,
            # columns) — glazing standing free is not a window
            from shapely.geometry import Point
            if solids is None or not (solids.contains(Point(p)) and
                                      solids.contains(Point(q))):
                return
        if h is not None:
            w, pos, wd = h
            Lw = math.dist(w["a"], w["b"])
            hit = _covered(ops + new_o, w, pos, wd)
            if hit is not None:
                # a gap read as «nothing drawn» that the swing / glazing
                # says is a door / window: made so
                if hit.get("kind") == "void" and not hit.get("hl"):
                    hit.update({k: v for k, v in _op(
                        kind, w["id"], float(hit["pos"]), float(hit["w"]),
                        leaves, st).items() if k not in ("pos", "w",
                                                         "wall")})
                    rep["doors" if kind == "door" else "windows"] += 1
                    rep.setdefault("typed", []).append(hit)
                return
            wd = min(wd, Lw - 0.24)
            pos = min(max(pos, wd / 2 + 0.11), Lw - wd / 2 - 0.11)
            if wd < 0.3:
                return
            new_o.append(_op(kind, w["id"], pos, wd, leaves, st))
        else:
            u = _u(p, q)
            ext = 0.12                         # into the walls at its ends
            a = (round(p[0] - u[0] * ext, 4), round(p[1] - u[1] * ext, 4))
            b = (round(q[0] + u[0] * ext, 4), round(q[1] + u[1] * ext, 4))
            rec = {"kind": "line", "a": list(a), "b": list(b),
                   "t": round(t * 200) / 200, "align": "centre", "side": 1,
                   "height": "level", "base": 0.0, "level": lid,
                   "bridge": kind}
            w = M.new_walls(arch["walls"] + new_w, [rec])[0]
            new_w.append(w)
            rep["bridges"] += 1
            new_o.append(_op(kind, w["id"], L / 2 + ext, L, leaves, st))
        rep["doors" if kind == "door" else "windows"] += 1

    # the piers first: solids the glazing may stand between
    prs = piers(pl, is_wall, walls)
    solids = None
    try:
        from shapely.geometry import LineString, Polygon
        from shapely.ops import unary_union
        from .engine import structure as S_
        sl = [LineString([w["a"], w["b"]]).buffer(float(w["t"]) / 2,
                                                   cap_style=2)
              for w in walls if math.dist(w["a"], w["b"]) > 1e-6]
        for c in arch["structure"]:
            if c["type"] == "column" and c["level"] == lid:
                try:
                    sl.append(Polygon(S_.column_outline(c)).buffer(0))
                except Exception:  # noqa: BLE001
                    continue
        sl += prs
        # and the plan's own lines on the wall layers (a pier drawn as a
        # few lines, a jamb's return)
        lay = pl["layers"]
        sl += [LineString([(s_[0], s_[1]), (s_[2], s_[3])]).buffer(0.03)
               for s_ in pl["segs"] if (is_wall(lay[s_[4]]) or (
                   is_col is not None and is_col(lay[s_[4]]))) and
               math.dist((s_[0], s_[1]), (s_[2], s_[3])) > 0.05]
        solids = unary_union(sl).buffer(0.25) if sl else None
    except Exception:  # noqa: BLE001
        solids = None
    for a, b, n in door_symbols(pl, is_door):
        t = _near_t(walls, (a, b), 0.115)
        add(a, b, "door", t, n)
    bands_ = list(window_bands(pl, is_win, is_line))
    # 3.64.40: a glazed façade drawn as a row of window units, frame to
    # frame, with no wall line under it (only its ends meet a wall or a
    # column): one wall along the whole row, a window for each unit — not
    # each unit rejected for standing between other units
    done_ = set()
    try:
        done_ = _glazed_rows(bands_, walls + new_w, solids, arch, lid, st,
                             new_w, new_o, rep)
    except Exception:  # noqa: BLE001
        from .host import log_error
        log_error("bridges glazed rows")
    for i_, (p, q, depth) in enumerate(bands_):
        if i_ in done_:
            continue
        t = min(max(depth + 0.02, 0.115), 0.46)
        add(p, q, "window", t)
    arch["walls"] += new_w
    rep["_new"] = new_o                  # the caller types and adds them
    # the piers: solids between the bands
    if prs:
        from .engine import structure as S
        recs = []
        for p in prs:
            c = p.centroid
            pts = [[round(x - c.x, 4), round(y - c.y, 4)]
                   for x, y in list(p.exterior.coords)[:-1]]
            xs = [q[0] for q in pts]
            ys = [q[1] for q in pts]
            recs.append({"type": "column", "level": lid,
                         "x": round(c.x, 4), "y": round(c.y, 4),
                         "shape": "poly", "w": round(max(xs) - min(xs), 3),
                         "d": round(max(ys) - min(ys), 3), "angle": 0.0,
                         "anchor": "centre", "base": 0.0, "pts": pts,
                         "height": "level", "fit": False, "pier": True})
        recs = [r for r in recs if S.why_not(r) is None]
        arch["structure"] += M.new_elements(arch["structure"], recs)
        rep["piers"] = len(recs)
    return rep


def _glazed_rows(bands, walls, solids, arch, lid, st, new_w, new_o,
                 rep) -> set:
    """Rows of window bands on one line, end to end (gaps under ~0.35 m:
    the mullions / frames between units), no wall under them and both ends
    of the row at a solid: a wall along the row, each band its window.
    The indices of the bands so placed."""
    from shapely.geometry import LineString, Point

    from .engine import model as M
    if solids is None or len(bands) < 2:
        return set()
    info = []
    for p, q, d in bands:
        u = _u(p, q)
        if u[0] < -1e-9 or (abs(u[0]) < 1e-9 and u[1] < 0):
            p, q, u = q, p, (-u[0], -u[1])
        info.append((tuple(p), tuple(q), d, u))
    # group: same direction, same line (across offset), touching
    par = list(range(len(info)))

    def find(i):
        while par[i] != i:
            par[i] = par[par[i]]
            i = par[i]
        return i
    for i, (p, q, d, u) in enumerate(info):
        n = (-u[1], u[0])
        for j in range(i + 1, len(info)):
            p2, q2, d2, u2 = info[j]
            if abs(u[0] * u2[0] + u[1] * u2[1]) < 0.999:
                continue
            off = (p2[0] - p[0]) * n[0] + (p2[1] - p[1]) * n[1]
            if abs(off) > 0.05:
                continue
            a0 = 0.0
            a1 = (q[0] - p[0]) * u[0] + (q[1] - p[1]) * u[1]
            b0 = (p2[0] - p[0]) * u[0] + (p2[1] - p[1]) * u[1]
            b1 = (q2[0] - p[0]) * u[0] + (q2[1] - p[1]) * u[1]
            gap = max(b0, a0) - min(b1, a1)          # > 0: apart
            if gap <= 0.35:
                par[find(i)] = find(j)
    groups = {}
    for i in range(len(info)):
        groups.setdefault(find(i), []).append(i)
    done = set()
    hosts = [LineString([w["a"], w["b"]]).buffer(float(w["t"]) / 2 + 0.02,
                                                   cap_style=2)
             for w in walls if math.dist(w["a"], w["b"]) > 1e-6]
    for idx in groups.values():
        if len(idx) < 2:
            continue
        p0, _q0, _d0, u = info[idx[0]]
        ss = []
        for i in idx:
            p, q, d, _u2 = info[i]
            ss.append(((p[0] - p0[0]) * u[0] + (p[1] - p0[1]) * u[1],
                       (q[0] - p0[0]) * u[0] + (q[1] - p0[1]) * u[1], i))
        s0 = min(a for a, _b, _i in ss)
        s1 = max(b for _a, b, _i in ss)
        P0 = (p0[0] + u[0] * s0, p0[1] + u[1] * s0)
        P1 = (p0[0] + u[0] * s1, p0[1] + u[1] * s1)
        if s1 - s0 < 1.0:
            continue
        row = LineString([P0, P1])
        # a wall the plan draws there already: not a façade of glass
        if any(row.intersection(h_).length > 0.5 * row.length
               for h_ in hosts):
            continue
        if not (solids.contains(Point(P0)) and solids.contains(Point(P1))):
            continue
        t = min(max(max(info[i][2] for i in idx) + 0.02, 0.115), 0.46)
        ext = 0.12
        a = (round(P0[0] - u[0] * ext, 4), round(P0[1] - u[1] * ext, 4))
        b = (round(P1[0] + u[0] * ext, 4), round(P1[1] + u[1] * ext, 4))
        rec = {"kind": "line", "a": list(a), "b": list(b),
               "t": round(t * 200) / 200, "align": "centre", "side": 1,
               "height": "level", "base": 0.0, "level": lid,
               "bridge": "window", "glazed_row": True}
        w = M.new_walls(arch["walls"] + new_w, [rec])[0]
        new_w.append(w)
        rep["bridges"] += 1
        L = math.dist(a, b)
        for a_, b_, i in sorted(ss):
            wd = b_ - a_
            pos = (a_ + b_) / 2 - s0 + ext
            if wd < 0.3:
                continue
            pos = min(max(pos, wd / 2 + 0.02), L - wd / 2 - 0.02)
            new_o.append(_op("window", w["id"], pos, wd, 1, st))
            rep["windows"] += 1
            done.add(i)
        rep["glazed_rows"] = rep.get("glazed_rows", 0) + 1
    return done


def _op(kind, wid, pos, w, leaves, st):
    door = kind == "door"
    return {"kind": kind, "wall": wid, "pos": round(pos, 4),
            "w": round(w, 3),
            "h": float(st["door_h"] if door else st["win_h"]),
            "sill": 0.0 if door else float(st["sill"]),
            "swing": "left", "face": 1,
            "style": ("double" if leaves == 2 else "hinged") if door
            else st.get("win_style", "sliding")}


# ---- walls meeting ----------------------------------------------------------------
def close_gaps(arch, lid, pl, is_solid, st, only_extend=False) -> dict:
    """Walls that stop short of one another closed up, as the plan means
    them: a free end facing another wall's free end on the same line —
    across a column, a pier, an arch opening — joined by a wall through
    the gap (its open spans plain openings: the hidden lines then make
    them arches); a free end stopping short of a wall ahead brought into
    it. How many of each."""
    from shapely.geometry import LineString, Point
    from shapely.ops import unary_union

    from .engine import model as M
    from .engine import structure as S_
    rep = {"joined": 0, "extended": 0, "openings": 0}
    walls = [w for w in arch["walls"] if w["level"] == lid
             and not w.get("rail") and w.get("kind", "line") == "line"
             and math.dist(w["a"], w["b"]) > 0.05]
    if not walls:
        return rep

    def poly(w):
        return LineString([w["a"], w["b"]]).buffer(float(w["t"]) / 2,
                                                   cap_style=2)
    polys = {w["id"]: poly(w) for w in walls}
    cols = []
    for c in arch["structure"]:
        if c["type"] == "column" and c["level"] == lid:
            try:
                from shapely.geometry import Polygon
                cols.append(Polygon(S_.column_outline(c)).buffer(0.02))
            except Exception:  # noqa: BLE001
                continue
    lay = pl["layers"]
    solid_l = [LineString([(s[0], s[1]), (s[2], s[3])]).buffer(0.02)
               for s in pl["segs"] if is_solid(lay[s[4]]) and
               math.dist((s[0], s[1]), (s[2], s[3])) > 0.05]
    SOL = unary_union(cols + solid_l) if (cols or solid_l) else None

    def free_ends():
        out = []
        for w in walls:
            for e, o in (("a", "b"), ("b", "a")):
                p = w[e]
                pt = Point(p)
                if any(k != w["id"] and pg.buffer(0.03).contains(pt)
                       for k, pg in polys.items()):
                    continue
                d = _u(w[o], p)              # out of the wall
                out.append((w, e, tuple(p), d))
        return out
    ends = free_ends()
    used = set()
    new_w, new_o = [], []
    # 1. two free ends on one line, facing: joined
    for i, (w, e, p, d) in enumerate(ends):
        if only_extend:
            break
        if (w["id"], e) in used:
            continue
        best = None
        for j, (w2, e2, q, d2) in enumerate(ends):
            if j == i or w2["id"] == w["id"] or (w2["id"], e2) in used:
                continue
            if d[0] * d2[0] + d[1] * d2[1] > -0.985:     # facing ±10°
                continue
            v = (q[0] - p[0], q[1] - p[1])
            ahead = v[0] * d[0] + v[1] * d[1]
            side = abs(v[0] * -d[1] + v[1] * d[0])
            if not 0.02 < ahead <= 8.0:
                continue
            if side > max(float(w["t"]), float(w2["t"])) / 2 + 0.06:
                continue
            if best is None or ahead < best[0]:
                best = (ahead, j)
        if best is None:
            continue
        ahead, j = best
        w2, e2, q, _d2 = ends[j]
        gap = LineString([p, q])
        # the open spans of the gap (no column / pier / wall lines)
        open_ = gap if SOL is None else gap.difference(SOL)
        spans = [g for g in getattr(open_, "geoms", [open_])
                 if g.geom_type == "LineString" and g.length > 0.05]
        if any(g.length > 3.0 for g in spans):
            continue                   # too wide: a real opening, not a gap
        if ahead > 2.0 and SOL is not None and \
                gap.intersection(SOL).length < 0.2:
            continue                   # nothing between: not one wall
        t = min(float(w["t"]), float(w2["t"]))
        rec = {"kind": "line", "a": [round(p[0], 4), round(p[1], 4)],
               "b": [round(q[0], 4), round(q[1], 4)],
               "t": round(t * 200) / 200, "align": "centre", "side": 1,
               "height": "level", "base": 0.0, "level": lid,
               "filler": True}
        # a little into both walls: the plan joins them
        u = _u(p, q)
        rec["a"] = [round(p[0] - u[0] * 0.02, 4), round(p[1] - u[1] * 0.02, 4)]
        rec["b"] = [round(q[0] + u[0] * 0.02, 4), round(q[1] + u[1] * 0.02, 4)]
        nw = M.new_walls(arch["walls"] + new_w, [rec])[0]
        new_w.append(nw)
        used |= {(w["id"], e), (w2["id"], e2)}
        rep["joined"] += 1
        L = math.dist(nw["a"], nw["b"])
        for g in spans:
            if g.length < 0.5:
                continue
            m = g.interpolate(0.5, normalized=True)
            pos = (m.x - nw["a"][0]) * u[0] + (m.y - nw["a"][1]) * u[1]
            wd = min(g.length, L - 0.22)
            pos = min(max(pos, wd / 2 + 0.11), L - wd / 2 - 0.11)
            if wd < 0.4:
                continue
            new_o.append({"kind": "void", "wall": nw["id"],
                          "pos": round(pos, 4), "w": round(wd, 3),
                          "h": float(st.get("door_h", 2.1336)),
                          "sill": 0.0, "swing": "left", "face": 1,
                          "style": ""})
            rep["openings"] += 1
    arch["walls"] += new_w
    walls += new_w
    for w in new_w:
        polys[w["id"]] = poly(w)
    # 2. a free end short of a wall / column ahead: carried into it — up
    # to 0.6 m, or up to 1.0 m where the plan's wall lines run on along
    # both its faces (a piece of wall the reading missed)
    cpolys = []
    for c in arch["structure"]:
        if c["type"] == "column" and c["level"] == lid:
            try:
                from shapely.geometry import Polygon as _Pg
                cpolys.append(_Pg(S_.column_outline(c)).buffer(0))
            except Exception:  # noqa: BLE001
                continue
    WL = unary_union(solid_l) if solid_l else None

    def faced(p, d, t, L):
        """The plan's lines along both faces of the gap ahead."""
        if WL is None or L < 0.02:
            return False
        n_ = (-d[1], d[0])
        for sg in (1, -1):
            o_ = sg * (t / 2)
            r_ = LineString([(p[0] + n_[0] * o_, p[1] + n_[1] * o_),
                             (p[0] + n_[0] * o_ + d[0] * L,
                              p[1] + n_[1] * o_ + d[1] * L)])
            if r_.intersection(WL.buffer(0.03)).length < 0.8 * L:
                return False
        return True
    for w, e, p, d in free_ends():
        if (w["id"], e) in used:
            continue
        if any(cp.buffer(0.01).contains(Point(p)) for cp in cpolys):
            continue                     # in a column already
        ray = LineString([p, (p[0] + d[0] * 1.0, p[1] + d[1] * 1.0)])
        band = ray.buffer(float(w["t"]) * 0.45, cap_style=2)
        best = None
        for k, pg in list(polys.items()) + [(None, cp) for cp in cpolys]:
            if k == w["id"]:
                continue
            x = ray.intersection(pg)
            side = False
            if x.is_empty:
                # the wall's band (not its centre line) running into it: a
                # column / wall beside the end, met by the wall's face
                x = band.intersection(pg)
                if x.is_empty:
                    continue
                side = True
            if side:
                cs_ = []
                for g_ in getattr(x, "geoms", [x]):
                    if g_.geom_type == "Polygon":
                        cs_ += list(g_.exterior.coords)
                    else:
                        cs_ += list(g_.coords)
                dist = min((q[0] - p[0]) * d[0] + (q[1] - p[1]) * d[1]
                           for q in cs_)
                if dist > 0.3:
                    continue
            else:
                dist = Point(p).distance(x)
            if best is None or dist < best[0]:
                best = (dist, k, side)
        if best is None:
            # a column beside the end, running on past it (a corner the
            # plan turns round the column): the wall on, flush with the
            # column's far face
            for cp in cpolys:
                if cp.distance(Point(p)) > 0.15:
                    continue
                ext = max((q[0] - p[0]) * d[0] + (q[1] - p[1]) * d[1]
                          for q in cp.exterior.coords)
                if 0.005 < ext <= 0.4 and (best is None or ext < best[0]):
                    best = (ext - 0.01, None, True)
        if best is None or best[0] < 0.005:
            continue
        if best[0] > 0.6 and not faced(p, d, float(w["t"]), best[0]):
            continue
        if best[1] is None or best[2]:   # a column / a wall's side: to it
            go = best[0] + 0.01
        else:
            o = next(x for x in walls if x["id"] == best[1])
            go = best[0] + float(o["t"]) / 2
        old = list(w[e])
        w[e] = [round(p[0] + d[0] * go, 4), round(p[1] + d[1] * go, 4)]
        if e == "a":                     # openings measured from «a»
            for op in arch["openings"]:
                if op["wall"] == w["id"]:
                    op["pos"] = round(float(op["pos"]) + math.dist(old, w[e]),
                                      4)
        polys[w["id"]] = poly(w)
        rep["extended"] += 1
    rep["_new"] = new_o
    return rep
